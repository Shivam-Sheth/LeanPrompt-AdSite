globalThis.__LEANPROMPT_BUILD__={"supabaseUrl":"https://synuufxjdejpvpbwcypj.supabase.co","supabaseAnonKey":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN5bnV1ZnhqZGVqcHZwYndjeXBqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg2NDc4NTEsImV4cCI6MjA5NDIyMzg1MX0.wwn9NvsCZjCGnJAT6D64XWvBK2vC-IPBcqI2Ki41LZw"};
"use strict";
(() => {
  // src/lib/auth/messagingClient.ts
  async function getCurrentUserFromBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return null;
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_GET_CURRENT_USER" }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve(null);
          return;
        }
        if (!response || response.ok === false) {
          resolve(null);
          return;
        }
        resolve(response.user);
      });
    });
  }
  async function getAuthStateFromBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: true, configured: false, loggedIn: false };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_GET_AUTH_STATE" }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Extension messaging failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response" });
      });
    });
  }
  async function loginThroughBackground(email, password) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: false, error: "Extension messaging unavailable." };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_LOGIN", email, password }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Login failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }
  async function signupThroughBackground(email, password) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: false, error: "Extension messaging unavailable." };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_SIGNUP", email, password }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Signup failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }
  async function googleSignInThroughBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: false, error: "Extension messaging unavailable." };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_GOOGLE_SIGNIN" }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Google sign-in failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }
  async function logoutThroughBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_SIGN_OUT" }, () => {
        chrome.runtime.lastError;
        resolve();
      });
    });
  }
  async function refreshSessionThroughBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_REFRESH_SESSION" }, () => {
        chrome.runtime.lastError;
        resolve();
      });
    });
  }

  // src/lib/billing/plan.ts
  function getUpgradeUrl() {
    return "https://lean-prompt.vercel.app/";
  }

  // src/popup/index.ts
  var STYLES = `
* { box-sizing:border-box; }
.lp-shell { display:flex; flex-direction:column; gap:12px; }
.lp-header { display:flex; align-items:center; justify-content:space-between; gap:8px; }
.lp-brand { display:flex; align-items:center; gap:8px; font-weight:700; font-size:15px; letter-spacing:-0.02em; color:#1e293b; }
.lp-brand-logo {
  width:28px; height:28px; border-radius:8px; flex-shrink:0;
  background:linear-gradient(135deg,#7c3aed,#5b21b6);
  display:flex; align-items:center; justify-content:center;
  font-size:11px; font-weight:900; font-style:italic; color:#fff; letter-spacing:-1px;
}
.lp-tagline { font-size:11px; color:#64748b; line-height:1.35; }
.lp-email { font-size:12px; color:#475569; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.lp-plan-card {
  border:1px solid #e2e8f0; border-radius:12px; padding:13px 14px;
  background:#fff; box-shadow:0 1px 4px rgba(0,0,0,0.06);
}
.lp-plan-badge {
  display:inline-flex; align-items:center; gap:5px;
  padding:3px 10px; border-radius:99px;
  font-size:10px; font-weight:700; letter-spacing:0.05em;
}
.lp-badge-free { background:#faf5ff; color:#7c3aed; border:1px solid #ddd6fe; }
.lp-badge-pro  { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; }
.lp-usage-row {
  display:flex; align-items:baseline; justify-content:space-between;
  margin-top:10px;
}
.lp-usage-count { font-size:22px; font-weight:700; color:#1e293b; font-variant-numeric:tabular-nums; line-height:1; }
.lp-usage-denom { font-size:13px; color:#94a3b8; font-weight:400; margin-left:3px; }
.lp-usage-right { font-size:11px; color:#64748b; }
.lp-usage-right-warn { color:#dc2626; }
.lp-progress { height:4px; background:#e2e8f0; border-radius:99px; overflow:hidden; margin-top:10px; }
.lp-progress-bar { height:100%; border-radius:99px; background:linear-gradient(90deg,#7c3aed,#a78bfa); }
.lp-upgrade-btn {
  width:100%; margin-top:12px; padding:9px 12px;
  border-radius:9px; border:none; cursor:pointer;
  background:linear-gradient(135deg,#7c3aed,#5b21b6);
  color:#fff; font-size:12px; font-weight:600; letter-spacing:0.01em;
  transition:opacity 120ms;
}
.lp-upgrade-btn:hover { opacity:0.9; }
.lp-pro-note { font-size:11px; color:#15803d; margin-top:10px; font-weight:500; }
.lp-footer { display:flex; align-items:center; justify-content:space-between; padding-top:2px; }
.lp-link-btn { font-size:12px; color:#7c3aed; cursor:pointer; background:none; border:none; padding:4px 0; font-family:inherit; }
.lp-link-btn:hover { text-decoration:underline; }
.lp-signout-btn { font-size:12px; color:#94a3b8; cursor:pointer; background:none; border:none; padding:4px 0; font-family:inherit; }
.lp-signout-btn:hover { color:#475569; }
.lp-label { font-size:11px; color:#64748b; margin-bottom:5px; font-weight:500; }
.lp-input {
  width:100%; padding:9px 10px; border-radius:8px;
  border:1px solid #e2e8f0; background:#fff; color:#1e293b; font-size:13px;
  outline:none; transition:border-color 150ms; font-family:inherit;
}
.lp-input:focus { border-color:#a78bfa; box-shadow:0 0 0 2px rgba(139,92,246,0.12); }
.lp-row { display:flex; gap:8px; }
.lp-btn {
  flex:1; padding:9px 12px; border-radius:8px; cursor:pointer;
  font-weight:600; font-size:12px; border:1px solid #e2e8f0;
  background:#f8fafc; color:#475569; transition:background 120ms; font-family:inherit;
}
.lp-btn:hover { background:#f1f5f9; }
.lp-btn-primary {
  background:linear-gradient(135deg,#7c3aed,#5b21b6);
  border-color:transparent; color:#fff;
}
.lp-btn-primary:hover { opacity:0.92; background:linear-gradient(135deg,#7c3aed,#5b21b6); }
.lp-btn-google {
  display:flex; align-items:center; justify-content:center; gap:7px;
  border:1px solid #e2e8f0; background:#fff; color:#374151; flex:unset; width:100%;
}
.lp-muted { font-size:11px; color:#94a3b8; line-height:1.4; }
.lp-error { font-size:12px; color:#dc2626; border:1px solid #fecaca; border-radius:8px; padding:8px; background:#fff5f5; }
.lp-success { font-size:12px; color:#15803d; border:1px solid #bbf7d0; border-radius:8px; padding:8px; background:#f0fdf4; }
.lp-link { color:#7c3aed; font-size:12px; text-decoration:none; }
.lp-link:hover { text-decoration:underline; }
.lp-divider { height:1px; background:#f1f5f9; margin:4px 0; }
.lp-card {
  border:1px solid #e2e8f0; border-radius:12px; padding:13px;
  background:#fff; box-shadow:0 1px 3px rgba(0,0,0,0.05);
}
`;
  function injectPopupStyles() {
    if (document.getElementById("leanprompt-popup-styles")) return;
    const s = document.createElement("style");
    s.id = "leanprompt-popup-styles";
    s.textContent = STYLES;
    document.head.appendChild(s);
  }
  async function renderDevMode() {
    const root = document.getElementById("app");
    if (!root) return;
    root.innerHTML = `
    <div class="lp-shell">
      <div class="lp-header">
        <div class="lp-brand"><div class="lp-brand-logo">lp</div>LeanPrompt</div>
      </div>
      <div class="lp-tagline">Compress AI prompts locally before you send.</div>
      <div class="lp-card">
        <div class="lp-muted"><b>Dev mode:</b> Supabase not configured. Compression works locally; sign-in disabled.</div>
        <div class="lp-divider"></div>
        <div class="lp-muted">Add credentials in <b>Settings</b> to enable auth.</div>
      </div>
      <button class="lp-btn lp-btn-primary" id="openSettingsBtn">Open settings</button>
      <a class="lp-link" href="https://lean-prompt.vercel.app/" target="_blank" rel="noreferrer">LeanPrompt web</a>
    </div>`;
    document.getElementById("openSettingsBtn")?.addEventListener("click", () => chrome.runtime.openOptionsPage());
  }
  async function renderVerify(email) {
    const root = document.getElementById("app");
    if (!root) return;
    root.innerHTML = `
    <div class="lp-shell">
      <div class="lp-header">
        <div class="lp-brand"><div class="lp-brand-logo">lp</div>LeanPrompt</div>
      </div>
      <div class="lp-tagline">Verify your email to continue.</div>
      <div class="lp-success">We sent a link to <b>${email}</b>. After verifying, click refresh.</div>
      <button class="lp-btn lp-btn-primary" id="refreshBtn">I've verified \u2014 refresh</button>
      <button class="lp-btn" id="logoutBtnVerify">Sign out</button>
    </div>`;
    document.getElementById("refreshBtn")?.addEventListener("click", () => render());
    document.getElementById("logoutBtnVerify")?.addEventListener("click", async () => {
      await logoutThroughBackground();
      await renderLogin("");
    });
  }
  async function renderLogin(error, info) {
    const root = document.getElementById("app");
    if (!root) return;
    root.innerHTML = `
    <div class="lp-shell">
      <div class="lp-header">
        <div class="lp-brand"><div class="lp-brand-logo">lp</div>LeanPrompt</div>
      </div>
      <div class="lp-tagline">Sign in to unlock prompt compression on AI chat sites.</div>
      ${error ? `<div class="lp-error">${error}</div>` : ""}
      ${info ? `<div class="lp-success">${info}</div>` : ""}
      <div class="lp-card">
        <div class="lp-label">Email</div>
        <input class="lp-input" id="email" type="email" autocomplete="username" placeholder="you@company.com" />
        <div style="height:9px"></div>
        <div class="lp-label">Password</div>
        <input class="lp-input" id="password" type="password" autocomplete="current-password" placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" />
        <div style="height:11px"></div>
        <div class="lp-row">
          <button class="lp-btn lp-btn-primary" id="loginBtn">Sign in</button>
          <button class="lp-btn" id="signupBtn">Create account</button>
        </div>
        <div style="height:10px"></div>
        <button class="lp-btn lp-btn-google" id="googleBtn">Continue with Google</button>
        <div class="lp-muted" style="margin-top:10px;">
          Prompts compress locally \u2014 only auth &amp; usage metadata sync to our backend.
        </div>
      </div>
    </div>`;
    document.getElementById("loginBtn")?.addEventListener("click", async () => {
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value;
      const result = await loginThroughBackground(email, password);
      if (!result.ok) {
        await renderLogin(result.error);
        return;
      }
      void refreshSessionThroughBackground();
      await render();
    });
    document.getElementById("signupBtn")?.addEventListener("click", async () => {
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value;
      const result = await signupThroughBackground(email, password);
      if (!result.ok) {
        await renderLogin(result.error);
        return;
      }
      if (result.needsVerification) {
        await renderVerify(email);
        return;
      }
      void refreshSessionThroughBackground();
      await render();
    });
    document.getElementById("googleBtn")?.addEventListener("click", async () => {
      const result = await googleSignInThroughBackground();
      if (!result.ok) {
        await renderLogin(result.error);
        return;
      }
      void refreshSessionThroughBackground();
      await render();
    });
  }
  async function renderDashboard(user) {
    void refreshSessionThroughBackground();
    const root = document.getElementById("app");
    if (!root) return;
    const isFree = user.plan !== "pro";
    const FREE_LIMIT = 80;
    const used = user.monthly_usage_count;
    const usagePct = isFree ? Math.min(100, Math.round(used / FREE_LIMIT * 100)) : 0;
    const remaining = isFree ? Math.max(0, FREE_LIMIT - used) : null;
    const isNearLimit = remaining !== null && remaining <= 10;
    const planBadge = isFree ? `<span class="lp-plan-badge lp-badge-free">FREE</span>` : `<span class="lp-plan-badge lp-badge-pro">PRO \u2713</span>`;
    const usageBlock = isFree ? `<div class="lp-usage-row">
        <span class="lp-usage-count">${used}<span class="lp-usage-denom">/ ${FREE_LIMIT}</span></span>
        <span class="lp-usage-right ${isNearLimit ? "lp-usage-right-warn" : ""}">${remaining} left this month</span>
      </div>
      <div class="lp-progress"><div class="lp-progress-bar" style="width:${usagePct}%"></div></div>
      <button class="lp-upgrade-btn" id="upgradeBtn">Upgrade to Pro \u2192</button>` : `<div class="lp-usage-row">
        <span class="lp-usage-count">${used}</span>
        <span class="lp-usage-right">this month</span>
      </div>
      <div class="lp-pro-note">Unlimited optimizations</div>`;
    root.innerHTML = `
    <div class="lp-shell">
      <div class="lp-header">
        <div class="lp-brand">
          <div class="lp-brand-logo">lp</div>
          LeanPrompt
        </div>
      </div>
      <div class="lp-email">${user.email}</div>
      <div class="lp-plan-card">
        ${planBadge}
        ${usageBlock}
      </div>
      <div class="lp-footer">
        <button class="lp-link-btn" id="optsLink">Settings</button>
        <button class="lp-signout-btn" id="logoutBtn">Sign out</button>
      </div>
    </div>`;
    document.getElementById("logoutBtn")?.addEventListener("click", async () => {
      await logoutThroughBackground();
      await renderLogin("");
    });
    document.getElementById("upgradeBtn")?.addEventListener("click", () => {
      chrome.tabs.create({ url: getUpgradeUrl() });
    });
    document.getElementById("optsLink")?.addEventListener("click", () => {
      chrome.runtime.openOptionsPage();
    });
  }
  async function render() {
    injectPopupStyles();
    const authState = await getAuthStateFromBackground();
    if (!authState.ok || !authState.configured) {
      await renderDevMode();
      return;
    }
    if (!authState.loggedIn) {
      await renderLogin("");
      return;
    }
    if (authState.needsEmailVerification) {
      await renderVerify(authState.email ?? "");
      return;
    }
    const user = await getCurrentUserFromBackground();
    if (!user) {
      await renderLogin("");
      return;
    }
    await renderDashboard(user);
  }
  void render();
})();
//# sourceMappingURL=index.js.map
