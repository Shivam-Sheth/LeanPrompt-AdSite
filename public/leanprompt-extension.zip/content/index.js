globalThis.__LEANPROMPT_BUILD__={"supabaseUrl":"https://synuufxjdejpvpbwcypj.supabase.co","supabaseAnonKey":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN5bnV1ZnhqZGVqcHZwYndjeXBqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg2NDc4NTEsImV4cCI6MjA5NDIyMzg1MX0.wwn9NvsCZjCGnJAT6D64XWvBK2vC-IPBcqI2Ki41LZw","updateManifestUrl":""};
"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/is-buffer/index.js
  var require_is_buffer = __commonJS({
    "node_modules/is-buffer/index.js"(exports, module) {
      module.exports = function isBuffer(obj) {
        return obj != null && obj.constructor != null && typeof obj.constructor.isBuffer === "function" && obj.constructor.isBuffer(obj);
      };
    }
  });

  // node_modules/nspell/lib/util/rule-codes.js
  var require_rule_codes = __commonJS({
    "node_modules/nspell/lib/util/rule-codes.js"(exports, module) {
      "use strict";
      module.exports = ruleCodes;
      var NO_CODES = [];
      function ruleCodes(flags, value) {
        var index = 0;
        var result;
        if (!value) return NO_CODES;
        if (flags.FLAG === "long") {
          result = new Array(Math.ceil(value.length / 2));
          while (index < value.length) {
            result[index / 2] = value.slice(index, index + 2);
            index += 2;
          }
          return result;
        }
        return value.split(flags.FLAG === "num" ? "," : "");
      }
    }
  });

  // node_modules/nspell/lib/util/affix.js
  var require_affix = __commonJS({
    "node_modules/nspell/lib/util/affix.js"(exports, module) {
      "use strict";
      var parse = require_rule_codes();
      module.exports = affix;
      var push = [].push;
      var alphabet = "etaoinshrdlcumwfgypbvkjxqz".split("");
      var whiteSpaceExpression = /\s+/;
      var defaultKeyboardLayout = [
        "qwertzuop",
        "yxcvbnm",
        "qaw",
        "say",
        "wse",
        "dsx",
        "sy",
        "edr",
        "fdc",
        "dx",
        "rft",
        "gfv",
        "fc",
        "tgz",
        "hgb",
        "gv",
        "zhu",
        "jhn",
        "hb",
        "uji",
        "kjm",
        "jn",
        "iko",
        "lkm"
      ];
      function affix(doc) {
        var rules = /* @__PURE__ */ Object.create(null);
        var compoundRuleCodes = /* @__PURE__ */ Object.create(null);
        var flags = /* @__PURE__ */ Object.create(null);
        var replacementTable = [];
        var conversion = { in: [], out: [] };
        var compoundRules = [];
        var aff = doc.toString("utf8");
        var lines = [];
        var last = 0;
        var index = aff.indexOf("\n");
        var parts;
        var line;
        var ruleType;
        var count;
        var remove;
        var add;
        var source;
        var entry;
        var position;
        var rule;
        var value;
        var offset;
        var character;
        flags.KEY = [];
        while (index > -1) {
          pushLine(aff.slice(last, index));
          last = index + 1;
          index = aff.indexOf("\n", last);
        }
        pushLine(aff.slice(last));
        index = -1;
        while (++index < lines.length) {
          line = lines[index];
          parts = line.split(whiteSpaceExpression);
          ruleType = parts[0];
          if (ruleType === "REP") {
            count = index + parseInt(parts[1], 10);
            while (++index <= count) {
              parts = lines[index].split(whiteSpaceExpression);
              replacementTable.push([parts[1], parts[2]]);
            }
            index--;
          } else if (ruleType === "ICONV" || ruleType === "OCONV") {
            count = index + parseInt(parts[1], 10);
            entry = conversion[ruleType === "ICONV" ? "in" : "out"];
            while (++index <= count) {
              parts = lines[index].split(whiteSpaceExpression);
              entry.push([new RegExp(parts[1], "g"), parts[2]]);
            }
            index--;
          } else if (ruleType === "COMPOUNDRULE") {
            count = index + parseInt(parts[1], 10);
            while (++index <= count) {
              rule = lines[index].split(whiteSpaceExpression)[1];
              position = -1;
              compoundRules.push(rule);
              while (++position < rule.length) {
                compoundRuleCodes[rule.charAt(position)] = [];
              }
            }
            index--;
          } else if (ruleType === "PFX" || ruleType === "SFX") {
            count = index + parseInt(parts[3], 10);
            rule = {
              type: ruleType,
              combineable: parts[2] === "Y",
              entries: []
            };
            rules[parts[1]] = rule;
            while (++index <= count) {
              parts = lines[index].split(whiteSpaceExpression);
              remove = parts[2];
              add = parts[3].split("/");
              source = parts[4];
              entry = {
                add: "",
                remove: "",
                match: "",
                continuation: parse(flags, add[1])
              };
              if (add && add[0] !== "0") {
                entry.add = add[0];
              }
              try {
                if (remove !== "0") {
                  entry.remove = ruleType === "SFX" ? end(remove) : remove;
                }
                if (source && source !== ".") {
                  entry.match = ruleType === "SFX" ? end(source) : start(source);
                }
              } catch (_) {
                entry = null;
              }
              if (entry) {
                rule.entries.push(entry);
              }
            }
            index--;
          } else if (ruleType === "TRY") {
            source = parts[1];
            offset = -1;
            value = [];
            while (++offset < source.length) {
              character = source.charAt(offset);
              if (character.toLowerCase() === character) {
                value.push(character);
              }
            }
            offset = -1;
            while (++offset < alphabet.length) {
              if (source.indexOf(alphabet[offset]) < 0) {
                value.push(alphabet[offset]);
              }
            }
            flags[ruleType] = value;
          } else if (ruleType === "KEY") {
            push.apply(flags[ruleType], parts[1].split("|"));
          } else if (ruleType === "COMPOUNDMIN") {
            flags[ruleType] = Number(parts[1]);
          } else if (ruleType === "ONLYINCOMPOUND") {
            flags[ruleType] = parts[1];
            compoundRuleCodes[parts[1]] = [];
          } else if (ruleType === "FLAG" || ruleType === "KEEPCASE" || ruleType === "NOSUGGEST" || ruleType === "WORDCHARS") {
            flags[ruleType] = parts[1];
          } else {
            flags[ruleType] = parts[1];
          }
        }
        if (isNaN(flags.COMPOUNDMIN)) {
          flags.COMPOUNDMIN = 3;
        }
        if (!flags.KEY.length) {
          flags.KEY = defaultKeyboardLayout;
        }
        if (!flags.TRY) {
          flags.TRY = alphabet.concat();
        }
        if (!flags.KEEPCASE) {
          flags.KEEPCASE = false;
        }
        return {
          compoundRuleCodes,
          replacementTable,
          conversion,
          compoundRules,
          rules,
          flags
        };
        function pushLine(line2) {
          line2 = line2.trim();
          if (line2 && line2.charCodeAt(0) !== 35) {
            lines.push(line2);
          }
        }
      }
      function end(source) {
        return new RegExp(source + "$");
      }
      function start(source) {
        return new RegExp("^" + source);
      }
    }
  });

  // node_modules/nspell/lib/util/normalize.js
  var require_normalize = __commonJS({
    "node_modules/nspell/lib/util/normalize.js"(exports, module) {
      "use strict";
      module.exports = normalize2;
      function normalize2(value, patterns) {
        var index = -1;
        while (++index < patterns.length) {
          value = value.replace(patterns[index][0], patterns[index][1]);
        }
        return value;
      }
    }
  });

  // node_modules/nspell/lib/util/flag.js
  var require_flag = __commonJS({
    "node_modules/nspell/lib/util/flag.js"(exports, module) {
      "use strict";
      module.exports = flag;
      function flag(values, value, flags) {
        return flags && value in values && flags.indexOf(values[value]) > -1;
      }
    }
  });

  // node_modules/nspell/lib/util/exact.js
  var require_exact = __commonJS({
    "node_modules/nspell/lib/util/exact.js"(exports, module) {
      "use strict";
      var flag = require_flag();
      module.exports = exact;
      function exact(context, value) {
        var index = -1;
        if (context.data[value]) {
          return !flag(context.flags, "ONLYINCOMPOUND", context.data[value]);
        }
        if (value.length >= context.flags.COMPOUNDMIN) {
          while (++index < context.compoundRules.length) {
            if (context.compoundRules[index].test(value)) {
              return true;
            }
          }
        }
        return false;
      }
    }
  });

  // node_modules/nspell/lib/util/form.js
  var require_form = __commonJS({
    "node_modules/nspell/lib/util/form.js"(exports, module) {
      "use strict";
      var normalize2 = require_normalize();
      var exact = require_exact();
      var flag = require_flag();
      module.exports = form;
      function form(context, value, all) {
        var normal = value.trim();
        var alternative;
        if (!normal) {
          return null;
        }
        normal = normalize2(normal, context.conversion.in);
        if (exact(context, normal)) {
          if (!all && flag(context.flags, "FORBIDDENWORD", context.data[normal])) {
            return null;
          }
          return normal;
        }
        if (normal.toUpperCase() === normal) {
          alternative = normal.charAt(0) + normal.slice(1).toLowerCase();
          if (ignore(context.flags, context.data[alternative], all)) {
            return null;
          }
          if (exact(context, alternative)) {
            return alternative;
          }
        }
        alternative = normal.toLowerCase();
        if (alternative !== normal) {
          if (ignore(context.flags, context.data[alternative], all)) {
            return null;
          }
          if (exact(context, alternative)) {
            return alternative;
          }
        }
        return null;
      }
      function ignore(flags, dict, all) {
        return flag(flags, "KEEPCASE", dict) || all || flag(flags, "FORBIDDENWORD", dict);
      }
    }
  });

  // node_modules/nspell/lib/correct.js
  var require_correct = __commonJS({
    "node_modules/nspell/lib/correct.js"(exports, module) {
      "use strict";
      var form = require_form();
      module.exports = correct;
      function correct(value) {
        return Boolean(form(this, value));
      }
    }
  });

  // node_modules/nspell/lib/util/casing.js
  var require_casing = __commonJS({
    "node_modules/nspell/lib/util/casing.js"(exports, module) {
      "use strict";
      module.exports = casing;
      function casing(value) {
        var head = exact(value.charAt(0));
        var rest = value.slice(1);
        if (!rest) {
          return head;
        }
        rest = exact(rest);
        if (head === rest) {
          return head;
        }
        if (head === "u" && rest === "l") {
          return "s";
        }
        return null;
      }
      function exact(value) {
        return value === value.toLowerCase() ? "l" : value === value.toUpperCase() ? "u" : null;
      }
    }
  });

  // node_modules/nspell/lib/suggest.js
  var require_suggest = __commonJS({
    "node_modules/nspell/lib/suggest.js"(exports, module) {
      "use strict";
      var casing = require_casing();
      var normalize2 = require_normalize();
      var flag = require_flag();
      var form = require_form();
      module.exports = suggest;
      var push = [].push;
      function suggest(value) {
        var self = this;
        var charAdded = {};
        var suggestions = [];
        var weighted = {};
        var memory2;
        var replacement;
        var edits = [];
        var values;
        var index;
        var offset;
        var position;
        var count;
        var otherOffset;
        var otherCharacter;
        var character;
        var group;
        var before;
        var after;
        var upper;
        var insensitive;
        var firstLevel;
        var previous;
        var next;
        var nextCharacter;
        var max;
        var distance;
        var size;
        var normalized;
        var suggestion;
        var currentCase;
        value = normalize2(value.trim(), self.conversion.in);
        if (!value || self.correct(value)) {
          return [];
        }
        currentCase = casing(value);
        index = -1;
        while (++index < self.replacementTable.length) {
          replacement = self.replacementTable[index];
          offset = value.indexOf(replacement[0]);
          while (offset > -1) {
            edits.push(value.replace(replacement[0], replacement[1]));
            offset = value.indexOf(replacement[0], offset + 1);
          }
        }
        index = -1;
        while (++index < value.length) {
          character = value.charAt(index);
          before = value.slice(0, index);
          after = value.slice(index + 1);
          insensitive = character.toLowerCase();
          upper = insensitive !== character;
          charAdded = {};
          offset = -1;
          while (++offset < self.flags.KEY.length) {
            group = self.flags.KEY[offset];
            position = group.indexOf(insensitive);
            if (position < 0) {
              continue;
            }
            otherOffset = -1;
            while (++otherOffset < group.length) {
              if (otherOffset !== position) {
                otherCharacter = group.charAt(otherOffset);
                if (charAdded[otherCharacter]) {
                  continue;
                }
                charAdded[otherCharacter] = true;
                if (upper) {
                  otherCharacter = otherCharacter.toUpperCase();
                }
                edits.push(before + otherCharacter + after);
              }
            }
          }
        }
        index = -1;
        nextCharacter = value.charAt(0);
        values = [""];
        max = 1;
        distance = 0;
        while (++index < value.length) {
          character = nextCharacter;
          nextCharacter = value.charAt(index + 1);
          before = value.slice(0, index);
          replacement = character === nextCharacter ? "" : character + character;
          offset = -1;
          count = values.length;
          while (++offset < count) {
            if (offset <= max) {
              values.push(values[offset] + replacement);
            }
            values[offset] += character;
          }
          if (++distance < 3) {
            max = values.length;
          }
        }
        push.apply(edits, values);
        values = [value];
        replacement = value.toLowerCase();
        if (value === replacement || currentCase === null) {
          values.push(value.charAt(0).toUpperCase() + replacement.slice(1));
        }
        replacement = value.toUpperCase();
        if (value !== replacement) {
          values.push(replacement);
        }
        memory2 = {
          state: {},
          weighted,
          suggestions
        };
        firstLevel = generate(self, memory2, values, edits);
        previous = 0;
        max = Math.min(firstLevel.length, Math.pow(Math.max(15 - value.length, 3), 3));
        size = Math.max(Math.pow(10 - value.length, 3), 1);
        while (!suggestions.length && previous < max) {
          next = previous + size;
          generate(self, memory2, firstLevel.slice(previous, next));
          previous = next;
        }
        suggestions.sort(sort);
        values = [];
        normalized = [];
        index = -1;
        while (++index < suggestions.length) {
          suggestion = normalize2(suggestions[index], self.conversion.out);
          replacement = suggestion.toLowerCase();
          if (normalized.indexOf(replacement) < 0) {
            values.push(suggestion);
            normalized.push(replacement);
          }
        }
        return values;
        function sort(a, b) {
          return sortWeight(a, b) || sortCasing(a, b) || sortAlpha(a, b);
        }
        function sortWeight(a, b) {
          return weighted[a] === weighted[b] ? 0 : weighted[a] > weighted[b] ? -1 : 1;
        }
        function sortCasing(a, b) {
          var leftCasing = casing(a);
          var rightCasing = casing(b);
          return leftCasing === rightCasing ? 0 : leftCasing === currentCase ? -1 : rightCasing === currentCase ? 1 : void 0;
        }
        function sortAlpha(a, b) {
          return a.localeCompare(b);
        }
      }
      function generate(context, memory2, words, edits) {
        var characters = context.flags.TRY;
        var data = context.data;
        var flags = context.flags;
        var result = [];
        var index = -1;
        var word;
        var before;
        var character;
        var nextCharacter;
        var nextAfter;
        var nextNextAfter;
        var nextUpper;
        var currentCase;
        var position;
        var after;
        var upper;
        var inject;
        var offset;
        if (edits) {
          while (++index < edits.length) {
            check(edits[index], true);
          }
        }
        index = -1;
        while (++index < words.length) {
          word = words[index];
          before = "";
          character = "";
          nextCharacter = word.charAt(0);
          nextAfter = word;
          nextNextAfter = word.slice(1);
          nextUpper = nextCharacter.toLowerCase() !== nextCharacter;
          currentCase = casing(word);
          position = -1;
          while (++position <= word.length) {
            before += character;
            after = nextAfter;
            nextAfter = nextNextAfter;
            nextNextAfter = nextAfter.slice(1);
            character = nextCharacter;
            nextCharacter = word.charAt(position + 1);
            upper = nextUpper;
            if (nextCharacter) {
              nextUpper = nextCharacter.toLowerCase() !== nextCharacter;
            }
            if (nextAfter && upper !== nextUpper) {
              check(before + switchCase(nextAfter));
              check(
                before + switchCase(nextCharacter) + switchCase(character) + nextNextAfter
              );
            }
            check(before + nextAfter);
            if (nextAfter) {
              check(before + nextCharacter + character + nextNextAfter);
            }
            offset = -1;
            while (++offset < characters.length) {
              inject = characters[offset];
              if (upper && inject !== inject.toUpperCase()) {
                if (currentCase !== "s") {
                  check(before + inject + after);
                  check(before + inject + nextAfter);
                }
                inject = inject.toUpperCase();
                check(before + inject + after);
                check(before + inject + nextAfter);
              } else {
                check(before + inject + after);
                check(before + inject + nextAfter);
              }
            }
          }
        }
        return result;
        function check(value, double) {
          var state = memory2.state[value];
          var corrected;
          if (state !== Boolean(state)) {
            result.push(value);
            corrected = form(context, value);
            state = corrected && !flag(flags, "NOSUGGEST", data[corrected]);
            memory2.state[value] = state;
            if (state) {
              memory2.weighted[value] = double ? 10 : 0;
              memory2.suggestions.push(value);
            }
          }
          if (state) {
            memory2.weighted[value]++;
          }
        }
        function switchCase(fragment) {
          var first = fragment.charAt(0);
          return (first.toLowerCase() === first ? first.toUpperCase() : first.toLowerCase()) + fragment.slice(1);
        }
      }
    }
  });

  // node_modules/nspell/lib/spell.js
  var require_spell = __commonJS({
    "node_modules/nspell/lib/spell.js"(exports, module) {
      "use strict";
      var form = require_form();
      var flag = require_flag();
      module.exports = spell;
      function spell(word) {
        var self = this;
        var value = form(self, word, true);
        return {
          correct: self.correct(word),
          forbidden: Boolean(
            value && flag(self.flags, "FORBIDDENWORD", self.data[value])
          ),
          warn: Boolean(value && flag(self.flags, "WARN", self.data[value]))
        };
      }
    }
  });

  // node_modules/nspell/lib/util/apply.js
  var require_apply = __commonJS({
    "node_modules/nspell/lib/util/apply.js"(exports, module) {
      "use strict";
      module.exports = apply;
      function apply(value, rule, rules, words) {
        var index = -1;
        var entry;
        var next;
        var continuationRule;
        var continuation;
        var position;
        while (++index < rule.entries.length) {
          entry = rule.entries[index];
          continuation = entry.continuation;
          position = -1;
          if (!entry.match || entry.match.test(value)) {
            next = entry.remove ? value.replace(entry.remove, "") : value;
            next = rule.type === "SFX" ? next + entry.add : entry.add + next;
            words.push(next);
            if (continuation && continuation.length) {
              while (++position < continuation.length) {
                continuationRule = rules[continuation[position]];
                if (continuationRule) {
                  apply(next, continuationRule, rules, words);
                }
              }
            }
          }
        }
        return words;
      }
    }
  });

  // node_modules/nspell/lib/util/add.js
  var require_add = __commonJS({
    "node_modules/nspell/lib/util/add.js"(exports, module) {
      "use strict";
      var apply = require_apply();
      module.exports = add;
      var push = [].push;
      var NO_RULES = [];
      function addRules(dict, word, rules) {
        var curr = dict[word];
        if (word in dict) {
          if (curr === NO_RULES) {
            dict[word] = rules.concat();
          } else {
            push.apply(curr, rules);
          }
        } else {
          dict[word] = rules.concat();
        }
      }
      function add(dict, word, codes, options) {
        var position = -1;
        var rule;
        var offset;
        var subposition;
        var suboffset;
        var combined;
        var newWords;
        var otherNewWords;
        if (!("NEEDAFFIX" in options.flags) || codes.indexOf(options.flags.NEEDAFFIX) < 0) {
          addRules(dict, word, codes);
        }
        while (++position < codes.length) {
          rule = options.rules[codes[position]];
          if (codes[position] in options.compoundRuleCodes) {
            options.compoundRuleCodes[codes[position]].push(word);
          }
          if (rule) {
            newWords = apply(word, rule, options.rules, []);
            offset = -1;
            while (++offset < newWords.length) {
              if (!(newWords[offset] in dict)) {
                dict[newWords[offset]] = NO_RULES;
              }
              if (rule.combineable) {
                subposition = position;
                while (++subposition < codes.length) {
                  combined = options.rules[codes[subposition]];
                  if (combined && combined.combineable && rule.type !== combined.type) {
                    otherNewWords = apply(
                      newWords[offset],
                      combined,
                      options.rules,
                      []
                    );
                    suboffset = -1;
                    while (++suboffset < otherNewWords.length) {
                      if (!(otherNewWords[suboffset] in dict)) {
                        dict[otherNewWords[suboffset]] = NO_RULES;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  });

  // node_modules/nspell/lib/add.js
  var require_add2 = __commonJS({
    "node_modules/nspell/lib/add.js"(exports, module) {
      "use strict";
      var push = require_add();
      module.exports = add;
      var NO_CODES = [];
      function add(value, model) {
        var self = this;
        push(self.data, value, self.data[model] || NO_CODES, self);
        return self;
      }
    }
  });

  // node_modules/nspell/lib/remove.js
  var require_remove = __commonJS({
    "node_modules/nspell/lib/remove.js"(exports, module) {
      "use strict";
      module.exports = remove;
      function remove(value) {
        var self = this;
        delete self.data[value];
        return self;
      }
    }
  });

  // node_modules/nspell/lib/word-characters.js
  var require_word_characters = __commonJS({
    "node_modules/nspell/lib/word-characters.js"(exports, module) {
      "use strict";
      module.exports = wordCharacters;
      function wordCharacters() {
        return this.flags.WORDCHARS || null;
      }
    }
  });

  // node_modules/nspell/lib/util/dictionary.js
  var require_dictionary = __commonJS({
    "node_modules/nspell/lib/util/dictionary.js"(exports, module) {
      "use strict";
      var parseCodes = require_rule_codes();
      var add = require_add();
      module.exports = parse;
      var whiteSpaceExpression = /\s/g;
      function parse(buf, options, dict) {
        var value = buf.toString("utf8");
        var last = value.indexOf("\n") + 1;
        var index = value.indexOf("\n", last);
        while (index > -1) {
          if (value.charCodeAt(last) !== 9) {
            parseLine(value.slice(last, index), options, dict);
          }
          last = index + 1;
          index = value.indexOf("\n", last);
        }
        parseLine(value.slice(last), options, dict);
      }
      function parseLine(line, options, dict) {
        var slashOffset = line.indexOf("/");
        var hashOffset = line.indexOf("#");
        var codes = "";
        var word;
        var result;
        while (slashOffset > -1 && line.charCodeAt(slashOffset - 1) === 92) {
          line = line.slice(0, slashOffset - 1) + line.slice(slashOffset);
          slashOffset = line.indexOf("/", slashOffset);
        }
        if (hashOffset > -1) {
          if (slashOffset > -1 && slashOffset < hashOffset) {
            word = line.slice(0, slashOffset);
            whiteSpaceExpression.lastIndex = slashOffset + 1;
            result = whiteSpaceExpression.exec(line);
            codes = line.slice(slashOffset + 1, result ? result.index : void 0);
          } else {
            word = line.slice(0, hashOffset);
          }
        } else if (slashOffset > -1) {
          word = line.slice(0, slashOffset);
          codes = line.slice(slashOffset + 1);
        } else {
          word = line;
        }
        word = word.trim();
        if (word) {
          add(dict, word, parseCodes(options.flags, codes.trim()), options);
        }
      }
    }
  });

  // node_modules/nspell/lib/dictionary.js
  var require_dictionary2 = __commonJS({
    "node_modules/nspell/lib/dictionary.js"(exports, module) {
      "use strict";
      var parse = require_dictionary();
      module.exports = add;
      function add(buf) {
        var self = this;
        var index = -1;
        var rule;
        var source;
        var character;
        var offset;
        parse(buf, self, self.data);
        while (++index < self.compoundRules.length) {
          rule = self.compoundRules[index];
          source = "";
          offset = -1;
          while (++offset < rule.length) {
            character = rule.charAt(offset);
            source += self.compoundRuleCodes[character].length ? "(?:" + self.compoundRuleCodes[character].join("|") + ")" : character;
          }
          self.compoundRules[index] = new RegExp(source, "i");
        }
        return self;
      }
    }
  });

  // node_modules/nspell/lib/personal.js
  var require_personal = __commonJS({
    "node_modules/nspell/lib/personal.js"(exports, module) {
      "use strict";
      module.exports = add;
      function add(buf) {
        var self = this;
        var lines = buf.toString("utf8").split("\n");
        var index = -1;
        var line;
        var forbidden;
        var word;
        var flag;
        if (self.flags.FORBIDDENWORD === void 0) self.flags.FORBIDDENWORD = false;
        flag = self.flags.FORBIDDENWORD;
        while (++index < lines.length) {
          line = lines[index].trim();
          if (!line) {
            continue;
          }
          line = line.split("/");
          word = line[0];
          forbidden = word.charAt(0) === "*";
          if (forbidden) {
            word = word.slice(1);
          }
          self.add(word, line[1]);
          if (forbidden) {
            self.data[word].push(flag);
          }
        }
        return self;
      }
    }
  });

  // node_modules/nspell/lib/index.js
  var require_lib = __commonJS({
    "node_modules/nspell/lib/index.js"(exports, module) {
      "use strict";
      var buffer = require_is_buffer();
      var affix = require_affix();
      module.exports = NSpell;
      var proto = NSpell.prototype;
      proto.correct = require_correct();
      proto.suggest = require_suggest();
      proto.spell = require_spell();
      proto.add = require_add2();
      proto.remove = require_remove();
      proto.wordCharacters = require_word_characters();
      proto.dictionary = require_dictionary2();
      proto.personal = require_personal();
      function NSpell(aff, dic) {
        var index = -1;
        var dictionaries;
        if (!(this instanceof NSpell)) {
          return new NSpell(aff, dic);
        }
        if (typeof aff === "string" || buffer(aff)) {
          if (typeof dic === "string" || buffer(dic)) {
            dictionaries = [{ dic }];
          }
        } else if (aff) {
          if ("length" in aff) {
            dictionaries = aff;
            aff = aff[0] && aff[0].aff;
          } else {
            if (aff.dic) {
              dictionaries = [aff];
            }
            aff = aff.aff;
          }
        }
        if (!aff) {
          throw new Error("Missing `aff` in dictionary");
        }
        aff = affix(aff);
        this.data = /* @__PURE__ */ Object.create(null);
        this.compoundRuleCodes = aff.compoundRuleCodes;
        this.replacementTable = aff.replacementTable;
        this.conversion = aff.conversion;
        this.compoundRules = aff.compoundRules;
        this.rules = aff.rules;
        this.flags = aff.flags;
        if (dictionaries) {
          while (++index < dictionaries.length) {
            if (dictionaries[index].dic) {
              this.dictionary(dictionaries[index].dic);
            }
          }
        }
      }
    }
  });

  // src/lib/auth/messagingClient.ts
  function sendMessageWithRetry(payload, mapResponse, retries = 1) {
    return new Promise((resolve) => {
      const attempt = (left) => {
        chrome.runtime.sendMessage(payload, (response) => {
          const err = chrome.runtime.lastError;
          if (err && left > 0) {
            window.setTimeout(() => attempt(left - 1), 120);
            return;
          }
          if (err) {
            resolve(null);
            return;
          }
          resolve(mapResponse(response));
        });
      };
      attempt(retries);
    });
  }
  async function getAuthContextFromBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { state: { ok: true, configured: false, loggedIn: false }, user: null };
    }
    const response = await sendMessageWithRetry(
      { type: "LEANPROMPT_GET_AUTH_CONTEXT" },
      (r) => r ?? null,
      2
    );
    if (!response || response.ok === false) {
      return null;
    }
    return { state: response.state, user: response.user };
  }
  async function getAuthStateFromBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: true, configured: false, loggedIn: false };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_GET_AUTH_STATE" }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Extension messaging failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response" });
      });
    });
  }
  async function loginThroughBackground(email, password) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: false, error: "Extension messaging unavailable." };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_LOGIN", email, password }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Login failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }
  async function signupThroughBackground(email, password) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: false, error: "Extension messaging unavailable." };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_SIGNUP", email, password }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Signup failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }
  async function resetPasswordThroughBackground(email) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: false, error: "Extension messaging unavailable." };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_RESET_PASSWORD", email }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Reset failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }
  async function googleSignInThroughBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: false, error: "Extension messaging unavailable." };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_GOOGLE_SIGNIN" }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Google sign-in failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }
  async function geminiCompressThroughBackground(prompt) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: false, error: "Extension messaging unavailable." };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_GEMINI_COMPRESS", prompt }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Gemini compress failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }
  async function checkUpdateThroughBackground(force = false) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return { ok: true, configured: false, available: false, currentVersion: "0.0.0" };
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_CHECK_UPDATE", force }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          resolve({ ok: false, error: err.message ?? "Update check failed." });
          return;
        }
        resolve(response ?? { ok: false, error: "No response from extension." });
      });
    });
  }

  // src/lib/compression/compressionStyleGuide.ts
  var SYMBOL_COMPACTION_REPLACEMENTS = [
    [/\bplease\b(?!\s+(?:simply|briefly|concisely|clearly)\b)/gi, ""],
    [/\bcan you\b/gi, ""],
    [/\bcould you\b/gi, ""],
    [/\bi want you to\b/gi, ""],
    [/\bi need you to\b/gi, ""],
    [/\bin order to\b/gi, "to"],
    [/\bas well as\b/gi, "+"],
    [/\balong with\b/gi, "+"],
    [/\btogether with\b/gi, "+"],
    [/\bsuch as\b/gi, ":"],
    [/\bfor example\b/gi, "e.g."],
    [/\bversus\b/gi, "vs"],
    [/\band also\b/gi, "+"],
    [/\b,\s*and\b/gi, " +"],
    [/\bthat is\b/gi, "i.e."]
  ];

  // src/lib/compression/geminiCompress.ts
  function selectBestCompression(offlineText, offlineScore, geminiResult, options = {}) {
    if (!geminiResult || "error" in geminiResult) {
      return { text: offlineText, source: "offline" };
    }
    const geminiText = geminiResult.text;
    const preferGemini = options.preferGemini !== false;
    if (!geminiText || geminiText.length >= offlineText.length) {
      return { text: offlineText, source: "offline" };
    }
    if (preferGemini) {
      return { text: geminiText, source: "gemini" };
    }
    if (offlineScore >= 0.85) {
      const geminiShorterBy = (offlineText.length - geminiText.length) / offlineText.length;
      if (geminiShorterBy < 0.15) return { text: offlineText, source: "offline" };
    }
    return { text: geminiText, source: "gemini" };
  }

  // src/lib/compression/compressionSignature.ts
  function baseNormalize(input, replaceNumbers) {
    let s = input.toLowerCase().replace(/[''`]/g, "'").replace(/\bi'm\b/g, "im").replace(/\bi am\b/g, "im").replace(/"[^"]+"/g, '"<quote>"').replace(/'[^']+'/g, "'<quote>'");
    if (replaceNumbers) {
      s = s.replace(/\b\d+(?:\.\d+)?\b/g, "<num>");
    }
    return s.replace(/\b(?:please|pls|kindly|thanks|thank you)\b/g, "").replace(/[?!.,;:]+$/g, "").replace(/\s+/g, " ").trim();
  }
  function normalizeCompressionSignature(input) {
    return baseNormalize(input, true);
  }
  function normalizeFastModelSignature(input) {
    return baseNormalize(input, false);
  }

  // src/lib/compression/geminiLearnedStore.ts
  var GEMINI_LEARNED_STORAGE_KEY = "leanprompt_gemini_learned_v1";
  var MAX_ENTRIES = 2500;
  var memory = /* @__PURE__ */ new Map();
  var hydrated = false;
  function storeKey(intent, prompt) {
    return `${intent}::${normalizeCompressionSignature(prompt)}`;
  }
  function trimStore(entries) {
    const keys = Object.keys(entries);
    if (keys.length <= MAX_ENTRIES) return entries;
    const sorted = keys.sort(
      (a, b) => new Date(entries[b].learnedAt).getTime() - new Date(entries[a].learnedAt).getTime()
    );
    const keep = new Set(sorted.slice(0, MAX_ENTRIES));
    const out = {};
    for (const k of keep) out[k] = entries[k];
    return out;
  }
  function hydrateMemory(store) {
    memory.clear();
    for (const [key, entry] of Object.entries(store)) {
      if (entry?.text?.trim()) memory.set(key, entry);
    }
    hydrated = true;
  }
  async function readPersisted() {
    if (typeof chrome === "undefined" || !chrome.storage?.local) return {};
    try {
      const item = await chrome.storage.local.get(GEMINI_LEARNED_STORAGE_KEY);
      const raw = item[GEMINI_LEARNED_STORAGE_KEY];
      return raw && typeof raw === "object" ? raw : {};
    } catch {
      return {};
    }
  }
  async function writePersisted(store) {
    if (typeof chrome === "undefined" || !chrome.storage?.local) return;
    try {
      await chrome.storage.local.set({ [GEMINI_LEARNED_STORAGE_KEY]: trimStore(store) });
    } catch {
    }
  }
  async function preloadGeminiLearnedStore() {
    if (hydrated) return;
    hydrateMemory(await readPersisted());
  }
  function getLearnedGeminiCompression(prompt, intent) {
    const key = storeKey(intent, prompt);
    const hit = memory.get(key);
    if (!hit?.text?.trim()) return null;
    hit.hits += 1;
    return hit.text.trim();
  }
  function learnFromGeminiCompression(prompt, intent, compressedText) {
    const original = prompt.trim();
    const text = compressedText.trim();
    if (!original || !text || text.length >= original.length) return;
    const key = storeKey(intent, original);
    memory.set(key, {
      intent,
      text,
      learnedAt: (/* @__PURE__ */ new Date()).toISOString(),
      hits: memory.get(key)?.hits ?? 0
    });
    void (async () => {
      const store = await readPersisted();
      store[key] = memory.get(key);
      await writePersisted(store);
    })();
  }

  // src/lib/metrics/estimation.ts
  var DEFAULT_COST_PER_1K_TOKENS = 2e-3;
  var DEFAULT_CARBON_GRAMS_PER_1K_TOKENS = 0.05;
  function estimateTokens(text) {
    const words = text.trim().split(/\s+/).filter(Boolean).length;
    return Math.max(1, Math.round(words * 1.3));
  }
  function estimateCost(tokens, per1k = DEFAULT_COST_PER_1K_TOKENS) {
    return Number((tokens / 1e3 * per1k).toFixed(6));
  }
  function estimateCarbon(tokens, gramsPer1k = DEFAULT_CARBON_GRAMS_PER_1K_TOKENS) {
    return Number((tokens / 1e3 * gramsPer1k).toFixed(6));
  }

  // src/lib/validation/validateCompression.ts
  var TECH_TOKEN_RE = /\b(react|vue|angular|svelte|next\.?js|nuxt|typescript|javascript|python|java\b|go\b|golang|rust|swift|kotlin|django|flask|fastapi|express|rails|laravel|spring|postgresql|mysql|mongodb|redis|sqlite|firebase|supabase|prisma|docker|kubernetes|aws|gcp|azure|vercel|netlify|tensorflow|pytorch|pandas|numpy|graphql|redux|zustand)\b/gi;
  var ROLE_PREAMBLE_RE = /\bI(?:'m|\s+am)\s+an?\s+([\w][\w\s\-]{0,30}?)(?=\s*[,;]|\s+(?:and|trying|looking|who)|\s*$)/i;
  var NEGATION_SIGNAL_RE = /\b(?:not|without|no|don'?t|never|avoid|except)\s+(?:too\s+)?\w+/gi;
  var VS_SIGNAL_RE = /\bvs\.?\s+|\bversus\b|\bdifference\s+between\b/i;
  var VAGUE_PHRASES = /* @__PURE__ */ new Set([
    "startup advice",
    "coding help",
    "fitness plan",
    "general advice",
    "some tips",
    "some help",
    "some info",
    "some ideas",
    "general tips",
    "a guide",
    "an explanation",
    "some examples"
  ]);
  function isVagueOutput(compressed, originalTokenCount) {
    if (originalTokenCount < 12) return false;
    const lower = compressed.toLowerCase().trim();
    if (VAGUE_PHRASES.has(lower)) return true;
    const sigTokens = lower.split(/\s+/).filter((w) => w.length > 3);
    return sigTokens.length <= 2 && originalTokenCount > 15;
  }
  var STOPWORDS = /* @__PURE__ */ new Set([
    "a",
    "an",
    "the",
    "and",
    "or",
    "to",
    "of",
    "for",
    "in",
    "on",
    "at",
    "with",
    "that",
    "this",
    "it",
    "is",
    "are",
    "be",
    "as",
    "by",
    "from"
  ]);
  function normalizeForContainment(text) {
    return ` ${text.toLowerCase().replace(/[^\w\s]/g, " ").replace(/\s+/g, " ").trim()} `;
  }
  function includesAny(text, values) {
    const normalized = text.toLowerCase();
    return values.filter((v) => normalized.includes(v.toLowerCase()));
  }
  function significantTokens(text) {
    return new Set(
      text.toLowerCase().split(/[^a-z0-9]+/).filter((token) => token.length > 2 && !STOPWORDS.has(token))
    );
  }
  var intentAnchorMap = {
    summarization: ["summar", "main", "key"],
    classification: ["classif", "label", "categor"],
    extraction: ["extract", "identif"],
    rewriting_paraphrasing: ["rewrite", "paraphrase", "rephrase"],
    code_debugging: ["debug", "bug", "fix"],
    code_explanation: ["explain", "code", "logic"],
    code_generation: ["generat", "implement", "code", "function", "class"],
    email_drafting: ["email", "draft"],
    brainstorming: ["brainstorm", "idea"],
    question_answering: [],
    translation: ["translat", "language"],
    creative_writing: ["story", "write", "craft", "poem", "essay", "narrative"],
    analysis: ["analys", "compare", "evaluat", "contrast"],
    general_instruction: []
  };
  function intentAnchors(intent) {
    return intentAnchorMap[intent] ?? [];
  }
  function extractQuotedSpans(text) {
    const out = [];
    for (const m of text.matchAll(/["“”]([^"“”]{2,})["“”]/g)) {
      const span = (m[1] ?? "").trim();
      if (span.length >= 2) out.push(span);
    }
    return out;
  }
  function extractNumberTokens(text) {
    return [...new Set((text.match(/\b\d+(?:[.,:/-]\d+)*(?:%|k|m|b)?\b/gi) ?? []).map((m) => m.trim()))];
  }
  var LIKELY_SENTENCE_START = /* @__PURE__ */ new Set([
    "how",
    "what",
    "when",
    "why",
    "where",
    "which",
    "who",
    "whom",
    "whose",
    "can",
    "could",
    "would",
    "should",
    "will",
    "shall",
    "may",
    "might",
    "must",
    "did",
    "does",
    "do",
    "is",
    "are",
    "was",
    "were",
    "been",
    "being",
    "have",
    "has",
    "had",
    "if",
    "tell",
    "give",
    "write",
    "please",
    "explain",
    "summarize",
    "draft",
    "brainstorm",
    "analyze",
    "translate",
    "extract",
    "rewrite",
    "compare",
    "describe",
    "list",
    "create",
    "generate",
    "help",
    "make",
    "show",
    "send",
    "find",
    "choose",
    "buy",
    "get",
    "plan",
    "learn",
    "think",
    "imagine",
    "say",
    "just",
    "also",
    "even",
    "only",
    "not",
    // Possessives and articles used at sentence starts — not proper nouns
    "my",
    "your",
    "our",
    "their",
    "its"
  ]);
  var SENTENCE_START_PREPS = /* @__PURE__ */ new Set(["in", "on", "at", "from", "for", "with", "by", "via"]);
  function extractProperNounSpans(text) {
    const spans = [];
    const matches = text.match(/\b(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2}|[A-Z]{2,}(?:\s+[A-Z]{2,})*)\b/g) ?? [];
    for (const raw of matches) {
      const token = raw.trim();
      if (token.length < 2) continue;
      const lower = token.toLowerCase();
      if (STOPWORDS.has(lower)) continue;
      if (LIKELY_SENTENCE_START.has(lower)) continue;
      if (/^(I|Please|Draft|Write|Explain|Summarize|Extract)$/i.test(token)) continue;
      const firstWordLower = lower.split(/\s+/)[0] ?? "";
      if (SENTENCE_START_PREPS.has(firstWordLower) && token.includes(" ")) continue;
      spans.push(token);
    }
    return [...new Set(spans)];
  }
  function collectProtectedEntities(original) {
    return [.../* @__PURE__ */ new Set([
      ...extractQuotedSpans(original),
      ...extractNumberTokens(original),
      ...extractProperNounSpans(original)
    ])];
  }
  function missingProtectedEntities(original, compressed) {
    const compressedNorm = normalizeForContainment(compressed);
    return collectProtectedEntities(original).filter((entity) => {
      const normalizedEntity = normalizeForContainment(entity);
      return !compressedNorm.includes(normalizedEntity);
    });
  }
  function validateCompression(original, compressed, intent, constraints) {
    const reasons = [];
    let score = 1;
    const anchors = intentAnchors(intent.primary_intent);
    const compressedLower = compressed.toLowerCase();
    if (anchors.length > 0 && !anchors.some((anchor) => compressedLower.includes(anchor))) {
      score -= 0.15;
      reasons.push("Intent signal may be weakened.");
    }
    const originalTokens = significantTokens(original);
    const compressedTokens = significantTokens(compressed);
    const hasExplicitConstraints = constraints.explicit.length > 0;
    const isDeliberateExtraction = !hasExplicitConstraints && compressedTokens.size <= 8 && originalTokens.size >= 6 && compressedTokens.size <= originalTokens.size * 0.5;
    if (originalTokens.size > 0) {
      let overlapCount = 0;
      const [smaller, larger] = originalTokens.size <= compressedTokens.size ? [originalTokens, compressedTokens] : [compressedTokens, originalTokens];
      for (const token of smaller) {
        if (larger.has(token)) overlapCount++;
      }
      const overlapRatio = overlapCount / originalTokens.size;
      const lowThreshold = isDeliberateExtraction ? 0.12 : 0.4;
      const midThreshold = isDeliberateExtraction ? 0.25 : 0.55;
      if (overlapRatio < lowThreshold) {
        score -= 0.25;
        reasons.push("Too much core information may have been removed.");
      } else if (overlapRatio < midThreshold) {
        score -= 0.08;
      }
    }
    const quotedSpans = extractQuotedSpans(original);
    const hasQuotedSpans = quotedSpans.length > 0;
    const missingEntities = isDeliberateExtraction && !hasQuotedSpans ? [] : missingProtectedEntities(original, compressed);
    if (missingEntities.length) {
      score -= Math.min(0.45, 0.12 * missingEntities.length);
      reasons.push(`Potential semantic drift: missing protected entities (${missingEntities.slice(0, 3).join(", ")}${missingEntities.length > 3 ? ", \u2026" : ""}).`);
    }
    {
      TECH_TOKEN_RE.lastIndex = 0;
      const originalTech = /* @__PURE__ */ new Set();
      let tm;
      while ((tm = TECH_TOKEN_RE.exec(original)) !== null) originalTech.add(tm[0].toLowerCase());
      if (originalTech.size > 0) {
        const compressedTechLower = compressedLower;
        const droppedTech = [...originalTech].filter((t) => !compressedTechLower.includes(t));
        if (droppedTech.length > 0) {
          score -= Math.min(0.3, 0.12 * droppedTech.length);
          reasons.push(`Tech stack may have been dropped (${droppedTech.slice(0, 2).join(", ")}).`);
        }
      }
    }
    {
      ROLE_PREAMBLE_RE.lastIndex = 0;
      const roleM = ROLE_PREAMBLE_RE.exec(original);
      if (roleM) {
        const role = roleM[1].trim().toLowerCase();
        const trivialRoles = /* @__PURE__ */ new Set(["person", "user", "human", "someone", "somebody"]);
        const firstWord = role.split(/\s+/)[0];
        if (!trivialRoles.has(firstWord)) {
          const roleTokens = role.split(/\s+/).filter((w) => w.length > 3);
          const anyRoleTokenInCompressed = roleTokens.some((w) => compressedLower.includes(w));
          if (!anyRoleTokenInCompressed) {
            score -= 0.12;
            reasons.push(`Role context may have been dropped (${role}).`);
          }
        }
      }
    }
    {
      NEGATION_SIGNAL_RE.lastIndex = 0;
      const negations = [];
      let nm;
      while ((nm = NEGATION_SIGNAL_RE.exec(original)) !== null) negations.push(nm[0].toLowerCase());
      if (negations.length > 0) {
        const dropped = negations.filter((n) => !compressedLower.includes(n.split(/\s+/)[1] ?? ""));
        if (dropped.length > negations.length / 2) {
          score -= 0.1;
          reasons.push("Negation constraint may have been dropped.");
        }
      }
    }
    if (VS_SIGNAL_RE.test(original)) {
      if (!/[/+]|\bvs\b|\bversus\b/i.test(compressed)) {
        score -= 0.1;
        reasons.push("Comparison may have lost one side.");
      }
    }
    const originalWordCount = original.trim().split(/\s+/).length;
    if (isVagueOutput(compressed, originalWordCount)) {
      score -= 0.25;
      reasons.push("Compressed output is too vague relative to the specific original.");
    }
    const required = [...constraints.labels, ...constraints.explicit];
    if (required.length > 0) {
      const preservedConstraints = includesAny(compressed, required);
      const droppedConstraints = required.filter((x) => !preservedConstraints.includes(x));
      if (droppedConstraints.length) {
        score -= Math.min(0.4, droppedConstraints.length * 0.1);
        reasons.push("Some explicit constraints may be missing.");
      }
      const valid2 = score >= 0.7 && missingEntities.length === 0;
      if (!valid2 && reasons.length === 0) reasons.push("Validation confidence too low.");
      return {
        valid: valid2,
        score: Number(Math.max(0, Math.min(1, score)).toFixed(2)),
        reasons,
        preservedConstraints,
        droppedConstraints
      };
    }
    const originalQuestions = (original.match(/\?/g) ?? []).length;
    const compressedQuestions = (compressed.match(/\?/g) ?? []).length;
    if (originalQuestions >= 5 && compressedQuestions < originalQuestions * 0.75) {
      score -= 0.25;
      reasons.push("Too many question marks lost \u2014 structured prompt may have been over-compressed.");
    }
    const originalNewlines = (original.match(/\n/g) ?? []).length;
    const compressedNewlines = (compressed.match(/\n/g) ?? []).length;
    if (originalNewlines >= 8 && compressedNewlines < 2) {
      score -= 0.2;
      reasons.push("Section structure lost \u2014 newlines collapsed in a structured prompt.");
    }
    if (compressed.length >= original.length) {
      if (original.length > 30) {
        score -= 0.1;
        reasons.push("Compression did not reduce size.");
      }
    } else if (missingEntities.length === 0 && compressed.length <= original.length * 0.65 && /[+:?[\]]|\bvs\b/.test(compressed)) {
      score = Math.min(1, score + 0.03);
    }
    if (original.includes("```") && !compressed.includes("```")) {
      score -= 0.2;
      reasons.push("Code block markers may have been removed.");
    }
    const valid = score >= 0.7 && missingEntities.length === 0;
    if (!valid && reasons.length === 0) reasons.push("Validation confidence too low.");
    return {
      valid,
      score: Number(Math.max(0, Math.min(1, score)).toFixed(2)),
      reasons,
      preservedConstraints: [],
      droppedConstraints: []
    };
  }

  // src/lib/compression/apiAssist.ts
  function offlineOutputForTrace(offline) {
    if (offline.instructionSourceText?.trim()) {
      const match = offline.optimizedText.match(/^([\s\S]*?)\n\nContext:\n/i);
      return (match?.[1]?.trim() ?? offline.instructionSourceText).trim();
    }
    return offline.optimizedText;
  }
  function buildTrace(offline, geminiOutput, source, geminiModel, geminiLatencyMs) {
    return {
      offlineOutput: offlineOutputForTrace(offline),
      geminiOutput,
      sourceModel: source,
      geminiModel: geminiModel ?? null,
      geminiLatencyMs: geminiLatencyMs ?? null
    };
  }
  function mergeInstructionWithContext(instruction, context) {
    if (!context?.trim()) return instruction.trim();
    return `${instruction.trim()}

Context:
${context.trim()}`.trim();
  }
  function finalizeResult(offline, instructionCompressed, trace, matchedRuleId) {
    const originalText = offline.originalText;
    const optimizedText = mergeInstructionWithContext(
      instructionCompressed,
      offline.instructionContextText
    );
    const tokenEstimateBefore = offline.tokenEstimateBefore;
    const tokenEstimateAfter = estimateTokens(optimizedText);
    if (tokenEstimateAfter >= tokenEstimateBefore) {
      return { ...offline, compressionTrace: buildTrace(offline, trace.geminiOutput ?? null, "offline") };
    }
    const validation = validateCompression(
      originalText,
      optimizedText,
      offline.intent,
      offline.constraints
    );
    const rawReduction = (tokenEstimateBefore - tokenEstimateAfter) / tokenEstimateBefore * 100;
    return {
      ...offline,
      optimizedText,
      tokenEstimateAfter,
      reductionPercent: Math.max(0, Number(rawReduction.toFixed(1))),
      costSavingsEstimate: Math.max(
        0,
        Number((estimateCost(tokenEstimateBefore) - estimateCost(tokenEstimateAfter)).toFixed(6))
      ),
      carbonSavingsEstimate: Math.max(
        0,
        Number((estimateCarbon(tokenEstimateBefore) - estimateCarbon(tokenEstimateAfter)).toFixed(6))
      ),
      validation,
      matchedRuleId: trace.sourceModel === "gemini" ? "gemini_teacher" : matchedRuleId,
      compressionTrace: trace
    };
  }
  async function enhanceWithApiAssist(offline, apiAssistEnabled) {
    const baseTrace = buildTrace(offline, null, "offline");
    if (!apiAssistEnabled) {
      return { ...offline, compressionTrace: baseTrace };
    }
    const geminiInput = offline.instructionSourceText?.trim() || offline.originalText;
    if (geminiInput.length > 12e3) {
      return { ...offline, compressionTrace: { ...buildTrace(offline, null, "offline"), geminiError: "Prompt too long for cloud compression (>12k chars)" } };
    }
    const offlineScore = offline.validation.score;
    const intentName = offline.intent.primary_intent;
    const inputCommas = (geminiInput.match(/,/g) ?? []).length;
    const hasEnumeratedList = inputCommas >= 3;
    const cached = hasEnumeratedList ? null : getLearnedGeminiCompression(geminiInput, intentName);
    if (cached) {
      const inputTokens = estimateTokens(geminiInput);
      const cachedTokens = estimateTokens(cached);
      const meetsFloor = cachedTokens < inputTokens && cachedTokens >= Math.max(3, inputTokens * 0.2);
      if (meetsFloor) {
        const trace2 = buildTrace(offline, cached, "gemini", "learned_cache", 0);
        return finalizeResult(offline, cached, trace2, "gemini_learned");
      }
    }
    if (offline.matchedRuleId === "gemini_learned") {
      return { ...offline, compressionTrace: buildTrace(offline, offline.optimizedText, "gemini", "learned_cache", 0) };
    }
    const geminiRes = await geminiCompressThroughBackground(geminiInput);
    if (!geminiRes.ok || !geminiRes.text?.trim()) {
      const errMsg = !geminiRes.ok ? geminiRes.error : "empty response";
      console.warn("LeanPrompt: Gemini assist unavailable \u2014", errMsg);
      return { ...offline, compressionTrace: { ...baseTrace, geminiError: errMsg } };
    }
    const geminiInstruction = geminiRes.text.trim();
    if (geminiInstruction.length >= geminiInput.trim().length) {
      console.warn("LeanPrompt: Gemini output not shorter than instruction \u2014 keeping offline.");
      return {
        ...offline,
        compressionTrace: buildTrace(offline, geminiInstruction, "offline", geminiRes.model, geminiRes.latencyMs)
      };
    }
    const geminiPayload = {
      text: geminiInstruction,
      model: geminiRes.model,
      latencyMs: geminiRes.latencyMs
    };
    const offlineInstruction = offline.instructionSourceText != null ? offline.optimizedText.match(/^([\s\S]*?)\n\nContext:\n/i)?.[1]?.trim() ?? offline.optimizedText : offline.optimizedText;
    learnFromGeminiCompression(geminiInput, intentName, geminiInstruction);
    const picked = selectBestCompression(offlineInstruction, offlineScore, geminiPayload, {
      preferGemini: true
    });
    const trace = buildTrace(
      offline,
      geminiPayload.text,
      picked.source,
      geminiPayload.model,
      geminiPayload.latencyMs
    );
    return finalizeResult(offline, picked.text, trace, offline.matchedRuleId);
  }

  // src/lib/constraints/extractConstraints.ts
  var outputFormatPatterns = [
    ["bullet_points", /bullet[- ]?points?|bulleted|(?:^|\s)-\s/i],
    ["json", /\bjson\b/i],
    ["table", /\b(?:in|as|return|output|format(?:ted)?)\s+(?:(?:a|the)\s+)?table\b|\btable\s+format\b/i],
    ["one_sentence", /one sentence/i],
    ["email", /\bemail\b/i],
    ["concise", /\b(?:concise|brief)\b/i],
    // Only treat as a format request when NOT part of "step by step plan for [topic]"
    ["step_by_step", /\bstep[- ]by[- ]step\b(?!\s+plan\s+for\b)/i],
    ["numbered_list", /\bnumbered list\b|\blist (?:each|them|all)\b/i],
    ["code_block", /\bcode block\b|\bformatted as code\b/i],
    ["markdown", /\bmarkdown\b/i]
  ];
  var tonePatterns = [
    ["professional", /professional/i],
    ["polite", /\bpolite\b/i],
    ["beginner_friendly", /beginner[- ]friendly|simple terms?|easy to (?:understand|follow)/i],
    ["detailed", /\b(?:detailed|in[- ]depth|comprehensive|thorough)\b/i],
    ["brief", /\b(?:brief|short|quick)\b/i],
    ["technical", /\btechnical\b/i],
    ["formal", /\bformal\b/i],
    ["casual", /\b(?:casual|informal|conversational)\b/i],
    ["engaging", /\b(?:engaging|interesting|captivating)\b/i]
  ];
  var labelPatterns = [
    /true\s*[,/]\s*false\s*[,/]\s*misleading/i,
    /positive\s*[,/]\s*negative\s*[,/]\s*neutral/i,
    /(?:yes|no)\s*[,/]\s*(?:no|yes)/i
  ];
  var explicitPatterns = [
    /under \d+ words?/i,
    /(?:at (?:least|most)|minimum|maximum) \d+/i,
    /\bdo not omit\b/i,
    /\bpreserve examples?\b/i,
    /\binclude comments?\b/i,
    /\bexplain reasoning\b/i,
    /\bno (?:more than|fewer than)\b/i,
    /\bin \d+ (?:words?|sentences?|paragraphs?|bullet points?)\b/i,
    /\bwith examples?\b/i,
    /\bwithout (?:using|any)\b/i
  ];
  function extractConstraints(prompt) {
    const outputFormat = [];
    for (const [key, pattern] of outputFormatPatterns) {
      if (pattern.test(prompt)) outputFormat.push(key);
    }
    const tone = [];
    for (const [key, pattern] of tonePatterns) {
      if (pattern.test(prompt)) tone.push(key);
    }
    const labels = [];
    for (const pattern of labelPatterns) {
      const m = prompt.match(pattern);
      if (m) labels.push(m[0]);
    }
    const explicit = [];
    for (const pattern of explicitPatterns) {
      const m = prompt.match(pattern);
      if (m) explicit.push(m[0]);
    }
    return { outputFormat, tone, labels, explicit };
  }

  // src/lib/compression/removeFillerPhrases.ts
  var FILLER_PATTERNS = [
    // ── Polite modal wrappers ──────────────────────────────────────────────────
    /\bdo\s+you\s+think\s+you\s+could\s+/gi,
    /\bwould\s+you\s+mind\s+/gi,
    /\bat\s+your\s+earliest\s+convenience[,\s]*/gi,
    /\bwhen\s+you\s+get\s+a\s+chance[,\s]*/gi,
    /\bif\s+you\s+don'?t\s+mind[,\s]*/gi,
    /\bif\s+it'?s?\s+(?:possible|okay|ok|alright|fine)[,\s]*/gi,
    /\bcould\s+you\s+please\s+/gi,
    /\bwould\s+you\s+please\s+/gi,
    /\bcan\s+you\s+please\s+/gi,
    /\bplease\b\s*/gi,
    /\bkindly\b\s*/gi,
    /\bif\s+possible[,\s]*/gi,
    // ── User-centric request frames ────────────────────────────────────────────
    /\bi\s+(?:would|'d)\s+(?:love|appreciate\s+it)\s+if\s+you\s+(?:could\s*)?/gi,
    /\bi\s+would\s+like\s+you\s+to\s+/gi,
    /\bi\s+need\s+you\s+to\s+/gi,
    /\bi\s+want\s+you\s+to\s+/gi,
    /\bhelp\s+me\s+/gi,
    /\btell\s+me\s+/gi,
    /\btake\s+a\s+look\s+at\s+/gi,
    /\bfor\s+me\s+please\b[,\s]*/gi,
    /\bfor\s+me\b[,\s]*/gi,
    // ── Rhetorical softeners ───────────────────────────────────────────────────
    /\bi\s+was\s+just\s+wondering[,\s]*/gi,
    /\bjust\s+want(?:ed)?\s+to\s+(?:ask|know|check|understand)[,\s]*/gi,
    /\bi'?m\s+just\s+curious[,\s]*/gi,
    /\bout\s+of\s+curiosity[,\s]*/gi,
    /\bi'?m\s+(?:not\s+sure|unsure)\s+if\s+(?:you\s+can|this\s+is\s+right|you\s+know)[,\s]*/gi,
    /\bsorry\s+(?:to\s+bother\s+you|if\s+this\s+is\s+obvious)[,\s]*/gi,
    /\bhope\s+(?:this\s+makes\s+sense|you\s+can\s+help)[,\s]*/gi,
    // ── Discourse markers / verbosity reducers ─────────────────────────────────
    /\bas\s+you\s+(?:may\s+)?know[,\s]*/gi,
    /\bas\s+you\s+can\s+see[,\s]*/gi,
    /\bas\s+i\s+mentioned[,\s]*/gi,
    /\bjust\s+to\s+clarify[,\s]*/gi,
    /\bplease\s+(?:note|be\s+advised)\s+that\s+/gi,
    /\bfeel\s+free\s+to\s+/gi,
    /\bdon'?t\s+hesitate\s+to\s+/gi,
    /\bgo\s+ahead\s+and\s+/gi,
    /\bmake\s+sure\s+(?:to\s*)?/gi,
    /\bin\s+other\s+words[,\s]*/gi,
    /\bessentially\b[,\s]*/gi,
    /\bbasically\b[,\s]*/gi,
    // ── Greetings ──────────────────────────────────────────────────────────────
    /\b(?:hi|hello|hey)\b[,!\s]*/gi
  ];
  function removeFillerPhrases(prompt) {
    let text = prompt;
    for (const pattern of FILLER_PATTERNS) {
      text = text.replace(pattern, " ");
    }
    return text.replace(/\s+/g, " ").replace(/\s([,.!?;:])/g, "$1").trim();
  }

  // src/lib/compression/rules/helpers.ts
  function sc(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
  }
  var LANG_MAP = {
    javascript: "JavaScript",
    typescript: "TypeScript",
    golang: "Go",
    go: "Go",
    "c++": "C++",
    sql: "SQL",
    css: "CSS",
    html: "HTML",
    react: "React",
    vue: "Vue",
    angular: "Angular"
  };
  var LANG_RE = /\bin\s+(python|java(?:script)?|typescript|go\b|golang|rust|c\+\+|swift|kotlin|ruby|php|sql|bash|css|html|react|vue|angular)\b/i;
  function cleanTopic(s) {
    return s.replace(/\s+(?:for|to|by)\s+me\b/gi, "").replace(/\s+at\s+(?:home|work)\b/gi, "").replace(/\bthe (?:following|given|below)\b\s*/gi, "").replace(/\s+(?:it|that|this|things?)\s+works?\s*$/gi, "").replace(/[\?\.]+$/, "").replace(/^(?:a|an|the|some|any|this|that)\s+/i, "").replace(/\s+(?:I got|that I|which I)\s+.*$/gi, "").replace(/\s+while\s+it\s+was\s+.*$/gi, "").replace(/\s+(?:rn|tbh|tbf|imo|fwiw|ngl|lol|lmk)\s*$/gi, "").replace(/\s{2,}/g, " ").trim();
  }
  function trimContext(s) {
    s = s.replace(/\s+(?:I got|that I|which I|while it was|when it was)\s+.*$/gi, "");
    const words = s.trim().split(/\s+/);
    return words.length > 5 ? words.slice(0, 4).join(" ") : s.trim();
  }
  function stripArticle(s) {
    return s.replace(/^(?:a|an|the)\s+/i, "").trim();
  }
  function langify(raw) {
    const m = raw.toLowerCase();
    return LANG_MAP[m] ?? raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
  }
  function codeTopic(s) {
    const langMatch = LANG_RE.exec(s);
    const lang = langMatch ? langify(langMatch[1]) : null;
    let core = s;
    if (langMatch) core = s.slice(0, langMatch.index);
    core = core.replace(/\b(?:elements?|items?|numbers?|values?|strings?)\b\s*/gi, "");
    core = core.replace(/\busing\s+(?:\w+\s+)+(?:technique|method|approach|algorithm)\b\s*/gi, "");
    core = core.replace(/\busing\s+\w+\b\s*/gi, "");
    core = cleanTopic(core).replace(/\.$/, "");
    return lang ? `${sc(core.toLowerCase())} in ${lang}?` : `${sc(core.toLowerCase())}?`;
  }
  function recipeCompress(topic) {
    const base = topic.replace(/\s+with\s+.*$/i, "").replace(/^(?:a|an|the)\s+/i, "").trim();
    const withMatch = /\bwith\s+(\w+)/i.exec(topic);
    const SKIP = /* @__PURE__ */ new Set(["a", "an", "the", "some", "any", "other", "various", "many", "multiple", "good"]);
    if (withMatch && !SKIP.has(withMatch[1].toLowerCase())) {
      let mod = withMatch[1].toLowerCase();
      if (mod.endsWith("s") && !mod.endsWith("ss")) mod = mod.slice(0, -1);
      return `${sc(mod)} ${base.toLowerCase()} recipe?`;
    }
    return `${titleCaseSubject(base)} recipe?`;
  }
  function symptomLabel(raw) {
    const r = raw.toLowerCase();
    if (r.includes("side effect")) return "side effects";
    if (r.includes("symptom")) return "symptoms";
    if (r.includes("sign")) return "signs";
    if (r.includes("benefit")) return "benefits";
    if (r.includes("cause")) return "causes";
    return "symptoms";
  }
  function compactTopic(topic) {
    const cleaned = cleanTopic(topic);
    const acronymMap = {
      api: "API",
      csv: "CSV",
      dns: "DNS",
      html: "HTML",
      http: "HTTP",
      https: "HTTPS",
      json: "JSON",
      sql: "SQL",
      ui: "UI",
      ux: "UX"
    };
    const acronym = acronymMap[cleaned.toLowerCase()];
    if (acronym) return acronym;
    if (/^[A-Z0-9]{2,}(?:\s+[A-Z0-9]{2,})*$/.test(cleaned)) return cleaned;
    if (/^[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+$/.test(cleaned)) return cleaned;
    return sc(cleaned.toLowerCase());
  }
  function briefQuestion(topic) {
    return `${compactTopic(topic)}? Briefly.`;
  }
  function conciseSubjectQuestion(subject, noun) {
    return `${compactTopic(subject)} ${noun.toLowerCase()}? Briefly.`;
  }
  function learningTopic(raw) {
    let topic = raw.trim();
    const maybeMatch = /\bmaybe\s+(.+)$/i.exec(topic);
    if (maybeMatch) topic = maybeMatch[1];
    return cleanTopic(topic).replace(/^like\s+/i, "").replace(/^(?:a|an|the)\s+new\s+(?:sport|hobby|skill|language)\s+/i, "").replace(/^(?:new\s+)?(?:sport|hobby|skill|language)\s+/i, "").replace(/^like\s+/i, "").trim();
  }
  function possessiveRelation(raw) {
    let relation = cleanTopic(raw).replace(/^(?:my|his|her|their|our|your)\s+/i, "").replace(/\s+(?:him|her|them)$/i, "").trim();
    if (!relation) return "recipient's";
    relation = relation.replace(/\bfriends\s+(\d+(?:st|nd|rd|th))\s+birthday\b/i, "friend's $1 birthday");
    relation = relation.replace(/\bfriends\s+(\d+(?:st|nd|rd|th))\b/i, "friend's $1");
    if (/'s$/i.test(relation)) return relation;
    if (relation.endsWith("s") && !relation.endsWith("ss")) return `${relation.slice(0, -1)}'s`;
    if (relation.endsWith("s")) return `${relation}'`;
    return `${relation}'s`;
  }
  function sentenceCasePhrase(raw) {
    return compactTopic(raw).replace(/\s{2,}/g, " ").trim();
  }
  var TITLE_KEEP_UPPER = /* @__PURE__ */ new Set(["ai", "api", "css", "csv", "dns", "html", "http", "json", "seo", "sql", "ui", "ux"]);
  function titleCaseSubject(raw) {
    return cleanTopic(raw).replace(/^["']|["']$/g, "").split(/\s+/).filter(Boolean).map((word) => {
      const lower = word.toLowerCase();
      const acronym = TITLE_KEEP_UPPER.has(lower) ? lower.toUpperCase() : null;
      if (acronym) return acronym;
      if (/^\d+(?:st|nd|rd|th)$/i.test(word)) return lower;
      if (/^\d+[a-z]+$/i.test(word)) return word.toUpperCase();
      if (/^[A-Za-z]+s$/i.test(word) && word.length <= 4) return word.toUpperCase();
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    }).join(" ").replace(/\b4CS\b/g, "4Cs").replace(/\biPhone\b/i, "iPhone").trim();
  }
  function artifactLabel(raw) {
    const lower = cleanTopic(raw).toLowerCase();
    const map = {
      essay: "Essay",
      report: "Report",
      article: "Article",
      "blog post": "Blog post",
      paragraph: "Paragraph",
      review: "Review",
      story: "Story",
      analysis: "Analysis",
      summary: "Summary",
      poem: "Poem",
      script: "Script",
      narrative: "Narrative",
      song: "Song",
      haiku: "Haiku"
    };
    return map[lower] ?? sc(lower);
  }
  function writingTopic(raw) {
    const trimmed = cleanTopic(raw).trim();
    const quoted = trimmed.match(/^["'](.+?)["']$/);
    if (quoted) return quoted[1].trim();
    return trimmed.toLowerCase().replace(/\b(?:ai|api|css|csv|dns|html|json|seo|sql|ui|ux)\b/g, (m) => m.toUpperCase()).replace(/\biphone\b/g, "iPhone").trim();
  }
  function styleLabel(raw) {
    const cleaned = cleanTopic(raw).replace(/\b(?:make|write|keep|it|this|that|please)\b/gi, "").replace(/\b(?:would|should|could)\s+(?:type|write|say|sound)\s*(?:it)?\b/gi, "").replace(/\b(?:sound|sounds|written|wrote)\s+(?:like|by)?\b/gi, "").replace(/\b(?:a|an|the)\b/gi, "").replace(/\s{2,}/g, " ").trim().toLowerCase();
    if (!cleaned) return "natural style";
    if (/\bhigh school\b/.test(cleaned)) return cleaned.includes("level") ? "high school level" : "high school writing style";
    if (/\bstudent\b/.test(cleaned)) return "student writing style";
    if (/\bjournalist\b|\bnews\b/.test(cleaned)) return "journalist writing style";
    if (/\bacademic\b|\bcollege\b|\buniversity\b/.test(cleaned)) return "academic writing style";
    if (/\bcasual\b|\bfriendly\b|\bconversational\b/.test(cleaned)) return "casual friendly style";
    if (/\bpersuasive\b/.test(cleaned)) return "persuasive style";
    if (/\buser\b|\bauthentic\b|\breal person\b/.test(cleaned)) return "authentic user writing style";
    if (/\bchild\b|\bkid\b/.test(cleaned)) return "child writing style";
    if (/\bliterature\b|\bprofessor\b/.test(cleaned)) return "academic literature style";
    if (/\bbrief\b|\bconcise\b|\bshort\b/.test(cleaned)) return "concise style";
    return `${cleaned.replace(/\s+style$/i, "")} style`;
  }
  function compactFactualSubject(raw) {
    return titleCaseSubject(raw).replace(/\bUsa\b/g, "USA").replace(/\bUk\b/g, "UK").replace(/\bCovid\b/g, "COVID-19").replace(/\bCovid-19\b/g, "COVID-19");
  }
  function singularizeNoun(raw) {
    const cleaned = cleanTopic(raw).toLowerCase();
    if (cleaned === "calories") return "calorie";
    if (cleaned === "carbs") return "carb";
    if (cleaned.endsWith("ies")) return `${cleaned.slice(0, -3)}y`;
    if (cleaned.endsWith("s") && !cleaned.endsWith("ss")) return cleaned.slice(0, -1);
    return cleaned;
  }
  function hobbyOverview(raw) {
    return `${compactFactualSubject(raw)} overview`;
  }
  function numberWordToDigits(raw) {
    const map = {
      one: "1",
      two: "2",
      three: "3",
      four: "4",
      five: "5",
      six: "6",
      seven: "7",
      eight: "8",
      nine: "9",
      ten: "10"
    };
    return map[raw.toLowerCase()] ?? raw;
  }
  function compactGoal(goal) {
    const g = goal.replace(/\s+/g, " ").replace(/\b(?:please|too|also|maybe)\b/gi, "").trim();
    const giftForMatch = g.match(/^(?:get|buy|find|choose)\s+(?:a\s+)?gift\s+for\s+(?:his|her|their|my|our|your)?\s*(.+)$/i);
    if (giftForMatch) {
      const recipient = cleanTopic(giftForMatch[1]);
      const occasionMatch = recipient.match(/^(.+?)\s+((?:\d+(?:st|nd|rd|th)\s+)?(?:birthday|anniversary|graduation|wedding|holiday|christmas))$/i);
      if (occasionMatch) {
        return `Gift ideas for ${possessiveRelation(occasionMatch[1])} ${occasionMatch[2].toLowerCase()}`;
      }
      return `Gift ideas for ${possessiveRelation(recipient)}`;
    }
    const giftMatch = g.match(/^(?:gift|buy|get)\s+(.+?)\s+something\s+for\s+(?:his|her|their|my|our|your)?\s*(.+)$/i);
    if (giftMatch) {
      return `Gift ideas for ${possessiveRelation(giftMatch[1])} ${cleanTopic(giftMatch[2]).toLowerCase()}`;
    }
    const buyForMatch = g.match(/^(?:buy|get|find|choose)\s+(.+?)\s+for\s+(.+)$/i);
    if (buyForMatch) {
      const item = cleanTopic(buyForMatch[1]).toLowerCase();
      const context = cleanTopic(buyForMatch[2]).toLowerCase();
      if (item.includes("laptop")) return `${sc(context)} laptop recommendations`;
      return `${sentenceCasePhrase(item)} for ${context}`;
    }
    const planForMatch = g.match(/^plan\s+(.+?)\s+for\s+(.+)$/i);
    if (planForMatch) {
      return `${sentenceCasePhrase(planForMatch[1])} ideas for ${cleanTopic(planForMatch[2]).replace(/^(?:my|his|her|their)\s+/i, "").toLowerCase()}`;
    }
    const chooseForMatch = g.match(/^choose\s+(.+?)\s+for\s+(.+)$/i);
    if (chooseForMatch) {
      return `${sentenceCasePhrase(chooseForMatch[2])} ${cleanTopic(chooseForMatch[1]).toLowerCase()} recommendations`;
    }
    return sentenceCasePhrase(g);
  }
  function deriveConstraintLabel(constraint) {
    const c = constraint.toLowerCase();
    if (/practical/.test(c)) return "practical";
    if (/beginner[- ]friendly|simple terms?|easy to follow/.test(c)) return "beginner-friendly";
    if (/can actually follow/.test(c)) return "practical plan";
    if (/(\d+)\s*min/.test(c)) {
      const n = c.match(/(\d+)\s*min/)?.[1];
      return n ? `${n} min/day` : "";
    }
    if (/tomorrow|asap/.test(c)) return "needed tomorrow";
    if (/don'?t have.*experience|no experience/.test(c)) return "beginner";
    if (/on a budget|can'?t afford|cheap/.test(c)) return "budget";
    if (/examples?\s+if\s+possible|with\s+examples?/.test(c)) return "examples";
    if (/short|brief|concise/.test(c)) return "short";
    if (/simpl[ey]/.test(c)) return "simple";
    if (/waste\s+money|save\s+money|budget/i.test(c)) return "budget";
    if (/stuck/.test(c)) return "practical";
    if (/realistic/.test(c)) return "realistic";
    return "";
  }
  function extractDirectiveSuffix(text) {
    const suffixes = [];
    const lower = text.toLowerCase();
    const hasAmazonLinks = /\b(?:amazon)\b/.test(lower) && /\b(?:links?|products?)\b/.test(lower);
    if (hasAmazonLinks) {
      suffixes.push("Include Amazon links.");
    } else if (/\b(?:amazon)\b/.test(lower)) {
      suffixes.push("Include Amazon options.");
    }
    if (!hasAmazonLinks && /\b(?:give|include|with|show|send)\b.*\b(?:links?|products?)\b/.test(lower)) {
      suffixes.push("Include product links.");
    }
    if (/\b(?:cheap|budget|affordable|low-cost)\b/.test(lower)) {
      suffixes.push("Include budget options.");
    }
    if (/\bexamples?\b/.test(lower)) {
      suffixes.push("Include examples.");
    }
    if (/\b(?:pros and cons|tradeoffs?)\b/.test(lower)) {
      suffixes.push("Include pros and cons.");
    }
    if (/\b(?:step by step|steps?)\b/.test(lower)) {
      suffixes.push("Give steps.");
    }
    return [...new Set(suffixes)].join(" ");
  }

  // src/lib/compression/rules/patterns.ts
  var COMPRESSION_RULES = [
    // ── ELITE CONCEPT TEMPLATES (priority 300) ──────────────────────────────────
    {
      id: "elite.behavioral_interview_stories",
      intent: "question_answering",
      pattern: /\bbehavioral interview stor(?:y|ies)\b/i,
      build: () => "Prepare STAR stories: leadership/conflict/failure/teamwork.",
      priority: 300,
      examples: [{ input: "behavioral interview stories", output: "Prepare STAR stories: leadership/conflict/failure/teamwork." }],
      source: "seed"
    },
    {
      id: "elite.swe_intern_interview",
      intent: "question_answering",
      pattern: /\b(?:software engineering|swe)\s+intern interview\b/i,
      build: () => "SWE intern prep: DSA, projects, behavioral, system basics.",
      priority: 300,
      examples: [{ input: "SWE intern interview prep", output: "SWE intern prep: DSA, projects, behavioral, system basics." }],
      source: "seed"
    },
    {
      id: "elite.ds_intern_interview",
      intent: "question_answering",
      pattern: /\bdata science intern interview\b|\bds intern interview\b/i,
      build: () => "DS intern prep: stats/Python/SQL/ML, projects, mocks, 7-day plan.",
      priority: 300,
      examples: [{ input: "data science intern interview prep", output: "DS intern prep: stats/Python/SQL/ML, projects, mocks, 7-day plan." }],
      source: "seed"
    },
    {
      id: "elite.sql_interview",
      intent: "question_answering",
      pattern: /\bsql interview\b|\bsql practice (?:for )?interviews?\b/i,
      build: () => "SQL interview plan: topics, patterns, practice.",
      priority: 300,
      examples: [{ input: "SQL interview practice", output: "SQL interview plan: topics, patterns, practice." }],
      source: "seed"
    },
    {
      id: "elite.ml_interview_questions",
      intent: "question_answering",
      pattern: /\bmachine learning interview questions?\b|\bml interview (?:q&a|questions?)\b/i,
      build: () => "ML interview Q&A with examples + pitfalls.",
      priority: 300,
      examples: [{ input: "machine learning interview questions", output: "ML interview Q&A with examples + pitfalls." }],
      source: "seed"
    },
    {
      id: "elite.project_interview",
      intent: "question_answering",
      pattern: /\bproject explanation (?:for|in) interviews?\b/i,
      build: () => "Frame project answer: problem, architecture, tradeoffs, impact.",
      priority: 300,
      examples: [{ input: "project explanation for interviews", output: "Frame project answer: problem, architecture, tradeoffs, impact." }],
      source: "seed"
    },
    {
      id: "elite.career_fair_pitch",
      intent: "creative_writing",
      pattern: /\bcareer[- ]fair (?:elevator )?pitch\b/i,
      build: () => "Create MS CS career-fair pitch.",
      priority: 300,
      examples: [{ input: "career fair elevator pitch for MS CS", output: "Create MS CS career-fair pitch." }],
      source: "seed"
    },
    {
      id: "elite.swe_resume_bullets",
      intent: "rewriting_paraphrasing",
      pattern: /\b(?:resume bullets? for swe|swe resume bullets?)\b/i,
      build: () => "Improve SWE resume bullets: impact, ownership, metrics.",
      priority: 300,
      examples: [{ input: "SWE resume bullets", output: "Improve SWE resume bullets: impact, ownership, metrics." }],
      source: "seed"
    },
    {
      id: "elite.ds_intern_resume",
      intent: "rewriting_paraphrasing",
      pattern: /\b(?:resume (?:for )?(?:a )?data science internship|ds intern resume|data science intern resume)\b/i,
      build: () => "Improve DS intern resume: metrics, projects, ATS keywords.",
      priority: 300,
      examples: [{ input: "data science internship resume", output: "Improve DS intern resume: metrics, projects, ATS keywords." }],
      source: "seed"
    },
    {
      id: "elite.ds_portfolio_project",
      intent: "brainstorming",
      pattern: /\b(?:ds|data science) portfolio project\b|\bportfolio project (?:for )?data science\b/i,
      build: () => "Suggest DS portfolio project: data, model, eval, deploy.",
      priority: 300,
      examples: [{ input: "data science portfolio project ideas", output: "Suggest DS portfolio project: data, model, eval, deploy." }],
      source: "seed"
    },
    {
      id: "elite.ds_recruiter_linkedin",
      intent: "email_drafting",
      pattern: /\b(?:ds recruiter|data science recruiter).*(?:linkedin|outreach|message)|\blinkedin (?:message|outreach).*(?:ds|data science)\b/i,
      build: () => "Draft DS recruiter LinkedIn outreach.",
      priority: 300,
      examples: [{ input: "LinkedIn outreach message for data science recruiter", output: "Draft DS recruiter LinkedIn outreach." }],
      source: "seed"
    },
    {
      id: "elite.leetcode_intern_plan",
      intent: "question_answering",
      pattern: /\bleetcode plan (?:for )?internships?\b|\bleetcode intern plan\b/i,
      build: () => "LeetCode intern plan: patterns, progression, daily targets.",
      priority: 300,
      examples: [{ input: "LeetCode plan for internships", output: "LeetCode intern plan: patterns, progression, daily targets." }],
      source: "seed"
    },
    {
      id: "elite.api_rate_limit",
      intent: "code_debugging",
      pattern: /\bapi rate limit(?:s| errors?)?\b/i,
      build: () => "Handle API rate limits: backoff, cache, quota design.",
      priority: 300,
      examples: [{ input: "API rate limit errors", output: "Handle API rate limits: backoff, cache, quota design." }],
      source: "seed"
    },
    {
      id: "elite.pandas_dataframe_error",
      intent: "code_debugging",
      pattern: /\bpandas dataframe (?:error|issue)\b/i,
      build: () => "Debug pandas DataFrame issue with corrected code.",
      priority: 300,
      examples: [{ input: "pandas DataFrame error", output: "Debug pandas DataFrame issue with corrected code." }],
      source: "seed"
    },
    {
      id: "elite.modulenotfounderror",
      intent: "code_debugging",
      pattern: /\bmodulenotfounderror\b(?!.*\b(?:react|vue|angular|typescript|javascript|flask|django|pinia|dashboard|explain likely|exact fix|walkthrough)\b)/i,
      build: () => "Debug ModuleNotFoundError: env, interpreter, install path, import.",
      priority: 300,
      examples: [{ input: "ModuleNotFoundError in Python", output: "Debug ModuleNotFoundError: env, interpreter, install path, import." }],
      source: "seed"
    },
    {
      id: "elite.python_refactor",
      intent: "rewriting_paraphrasing",
      pattern: /\bpython script refactor\b|\brefactor python\b/i,
      build: () => "Refactor Python: functions, names, errors, maintainability.",
      priority: 300,
      examples: [{ input: "Python script refactor", output: "Refactor Python: functions, names, errors, maintainability." }],
      source: "seed"
    },
    {
      id: "elite.react_state",
      intent: "code_debugging",
      pattern: /\breact state\b(?:.*\b(?:bug|issue|fix|debug|error|not working|crash|broken|problem|fail)\b|\s+(?:bug|issue|error|fix))/i,
      build: () => "Debug React state: mutation, async updates, props, keys.",
      priority: 300,
      examples: [{ input: "React state bug", output: "Debug React state: mutation, async updates, props, keys." }],
      source: "seed"
    },
    {
      id: "elite.nextjs_tailwind",
      intent: "code_debugging",
      pattern: /\bnext\.?js tailwind\b|\btailwind.*next\.?js\b/i,
      build: () => "Fix Next.js Tailwind: config, imports, content paths, restart.",
      priority: 300,
      examples: [{ input: "Next.js Tailwind not working", output: "Fix Next.js Tailwind: config, imports, content paths, restart." }],
      source: "seed"
    },
    {
      id: "elite.clean_notebook",
      intent: "rewriting_paraphrasing",
      pattern: /\bclean notebook\b|\bnotebook cleanup\b/i,
      build: () => "Clean notebook: sections, reproducible code, outputs.",
      priority: 300,
      examples: [{ input: "clean up Jupyter notebook", output: "Clean notebook: sections, reproducible code, outputs." }],
      source: "seed"
    },
    {
      id: "elite.user_research_survey",
      intent: "brainstorming",
      pattern: /\buser research survey\b.*\bstartup\b|\bstartup\b.*\buser research survey\b/i,
      build: () => "Create SaaS validation survey: pain, WTP, features.",
      priority: 300,
      examples: [{ input: "user research survey for startup", output: "Create SaaS validation survey: pain, WTP, features." }],
      source: "seed"
    },
    {
      id: "elite.prompt_optimizer_extension",
      intent: "code_generation",
      pattern: /\bprompt[- ]optimizer chrome extension\b|\bchrome extension\b.*\bprompt optimizer\b|\bprompt optimizer\b.*\bchrome extension\b/i,
      build: () => "Design prompt-optimizer Chrome extension preserving intent.",
      priority: 300,
      examples: [{ input: "prompt optimizer Chrome extension", output: "Design prompt-optimizer Chrome extension preserving intent." }],
      source: "seed"
    },
    {
      id: "elite.prompt_compression_logic",
      intent: "code_generation",
      pattern: /\bprompt compression (?:logic|function)\b|\bintent-preserving prompt compression\b|\bcompress(?:es|ing)? prompts?.*preserving (?:user )?intent\b/i,
      build: () => "Build intent-preserving prompt compression logic.",
      priority: 300,
      examples: [{ input: "prompt compression function preserving intent", output: "Build intent-preserving prompt compression logic." }],
      source: "seed"
    },
    {
      id: "elite.saas_backend",
      intent: "code_generation",
      pattern: /\bsubscription saas backend\b|\bsaas backend\b/i,
      build: () => "Design SaaS backend: auth, billing, usage limits, schema.",
      priority: 300,
      examples: [{ input: "subscription SaaS backend design", output: "Design SaaS backend: auth, billing, usage limits, schema." }],
      source: "seed"
    },
    {
      id: "elite.startup_pitch_prompt",
      intent: "creative_writing",
      pattern: /\bstartup pitch\b.*\bprompt optimizer\b|\bpitch\b.*\bprompt optimizer\b/i,
      build: () => "Pitch prompt optimizer: problem, solution, market, model, moat.",
      priority: 300,
      examples: [{ input: "startup pitch for prompt optimizer", output: "Pitch prompt optimizer: problem, solution, market, model, moat." }],
      source: "seed"
    },
    {
      id: "elite.leanprompt_landing",
      intent: "creative_writing",
      pattern: /\bleanprompt landing copy\b|\blanding (?:page )?copy\b.*\bleanprompt\b/i,
      build: () => "Write LeanPrompt landing copy: value, benefits, CTA.",
      priority: 300,
      examples: [{ input: "LeanPrompt landing page copy", output: "Write LeanPrompt landing copy: value, benefits, CTA." }],
      source: "seed"
    },
    {
      id: "elite.streamlit_metrics",
      intent: "code_generation",
      pattern: /\bstreamlit\b.*\b(?:post[- ]metrics|social media metrics)\b|\bpost[- ]metrics app\b/i,
      build: () => "Plan Streamlit post-metrics app: URL, metrics, charts, errors.",
      priority: 300,
      examples: [{ input: "Streamlit social media metrics app", output: "Plan Streamlit post-metrics app: URL, metrics, charts, errors." }],
      source: "seed"
    },
    {
      id: "elite.fat_loss_muscle",
      intent: "question_answering",
      pattern: /\bfat loss while gaining muscle\b|\bfat loss \+ muscle\b/i,
      build: () => "Plan fat loss + muscle retention: calories, protein, training.",
      priority: 300,
      examples: [{ input: "fat loss while gaining muscle plan", output: "Plan fat loss + muscle retention: calories, protein, training." }],
      source: "seed"
    },
    {
      id: "elite.weight_loss_plateau",
      intent: "question_answering",
      pattern: /\bweight[- ]loss plateau\b/i,
      build: () => "Fix weight-loss plateau: causes + actions.",
      priority: 300,
      examples: [{ input: "weight loss plateau help", output: "Fix weight-loss plateau: causes + actions." }],
      source: "seed"
    },
    {
      id: "elite.whole_foods_snacks",
      intent: "question_answering",
      pattern: /\bwhole foods (?:healthy )?snacks?\b/i,
      build: () => "Recommend fat-loss-friendly Whole Foods snacks.",
      priority: 300,
      examples: [{ input: "Whole Foods healthy snacks", output: "Recommend fat-loss-friendly Whole Foods snacks." }],
      source: "seed"
    },
    {
      id: "elite.push_pull_split",
      intent: "question_answering",
      pattern: /\bpush\/pull split\b|\bpush pull (?:workout )?split\b/i,
      build: () => "Efficient push/pull split: exercises, sets, reps.",
      priority: 300,
      examples: [{ input: "push pull workout split", output: "Efficient push/pull split: exercises, sets, reps." }],
      source: "seed"
    },
    {
      id: "elite.legday_hr_spike",
      intent: "question_answering",
      pattern: /\bleg[- ]day (?:hr|heart rate) spike\b|\bheart rate\b.*\bleg day\b/i,
      build: () => "Explain leg-day HR spike + safe progression.",
      priority: 300,
      examples: [{ input: "leg day heart rate spike", output: "Explain leg-day HR spike + safe progression." }],
      source: "seed"
    },
    {
      id: "elite.meal_calories",
      intent: "question_answering",
      pattern: /\bmeal calories\b|\bcalories\/protein\b|\bcalories and protein\b/i,
      build: () => "Estimate meal calories/protein from portions.",
      priority: 300,
      examples: [{ input: "meal calories and protein", output: "Estimate meal calories/protein from portions." }],
      source: "seed"
    },
    {
      id: "elite.protein_130g",
      intent: "question_answering",
      pattern: /\b130g protein\b|\b130 g protein\b/i,
      build: () => "Low-calorie 130g protein meals with portions.",
      priority: 300,
      examples: [{ input: "130g protein diet meals", output: "Low-calorie 130g protein meals with portions." }],
      source: "seed"
    },
    {
      id: "elite.pre_football_snack",
      intent: "question_answering",
      pattern: /\bpre[- ]football snack\b|\bfootball snack\b/i,
      build: () => "Pre-football snack for 40-min game.",
      priority: 300,
      examples: [{ input: "pre football game snack", output: "Pre-football snack for 40-min game." }],
      source: "seed"
    },
    {
      id: "elite.research_paper_summary",
      intent: "summarization",
      pattern: /\bresearch paper summary\b/i,
      build: () => "Summarize paper: problem/method/data/results/limits/contribution.",
      priority: 300,
      examples: [{ input: "research paper summary", output: "Summarize paper: problem/method/data/results/limits/contribution." }],
      source: "seed"
    },
    {
      id: "elite.ml_viva",
      intent: "question_answering",
      pattern: /\bmachine learning viva\b|\bml viva\b/i,
      build: () => "Prep ML viva: concepts, questions, formulas, examples.",
      priority: 300,
      examples: [{ input: "ML viva preparation", output: "Prep ML viva: concepts, questions, formulas, examples." }],
      source: "seed"
    },
    {
      id: "elite.blockchain_viva",
      intent: "question_answering",
      pattern: /\bblockchain viva\b/i,
      build: () => "Prep blockchain viva: terms, examples, questions.",
      priority: 300,
      examples: [{ input: "blockchain viva prep", output: "Prep blockchain viva: terms, examples, questions." }],
      source: "seed"
    },
    {
      id: "elite.software_testing_viva",
      intent: "question_answering",
      pattern: /\bsoftware testing viva\b/i,
      build: () => "Software testing viva guide: topics + Q&A.",
      priority: 300,
      examples: [{ input: "software testing viva guide", output: "Software testing viva guide: topics + Q&A." }],
      source: "seed"
    },
    {
      id: "elite.ms_cs_course_selection",
      intent: "question_answering",
      pattern: /\bcourse selection\b.*\bms cs\b|\bms cs\b.*\bcourse selection\b/i,
      build: () => "Optimize MS CS courses: GPA/workload/prereqs/career.",
      priority: 300,
      examples: [{ input: "MS CS course selection", output: "Optimize MS CS courses: GPA/workload/prereqs/career." }],
      source: "seed"
    },
    {
      id: "elite.latex_assignment",
      intent: "general_instruction",
      pattern: /\blatex assignment formatting\b|\bassignment formatting\b.*\blatex\b/i,
      build: () => "Format assignment in LaTeX.",
      priority: 300,
      examples: [{ input: "LaTeX assignment formatting", output: "Format assignment in LaTeX." }],
      source: "seed"
    },
    {
      id: "elite.cpt_vs_opt",
      intent: "question_answering",
      pattern: /\bcpt vs opt\b|\bopt vs cpt\b/i,
      build: () => "Explain CPT vs OPT for F-1 internships.",
      priority: 300,
      examples: [{ input: "CPT vs OPT", output: "Explain CPT vs OPT for F-1 internships." }],
      source: "seed"
    },
    {
      id: "elite.f1_startup_monetization",
      intent: "question_answering",
      pattern: /\bf-?1 startup monetization\b|\bstartup monetization rules\b/i,
      build: () => "Explain F-1 startup monetization considerations.",
      priority: 300,
      examples: [{ input: "F-1 startup monetization rules", output: "Explain F-1 startup monetization considerations." }],
      source: "seed"
    },
    {
      id: "elite.ssn_f1",
      intent: "question_answering",
      pattern: /\bssn\b.*\bf-?1\b|\bf-?1\b.*\bssn\b|\bwrong form fix\b|\bssn appointment documents?\b/i,
      build: () => "SSN docs for F-1 + wrong form fix.",
      priority: 300,
      examples: [{ input: "SSN appointment documents for F-1", output: "SSN docs for F-1 + wrong form fix." }],
      source: "seed"
    },
    {
      id: "elite.ta_grade_email",
      intent: "email_drafting",
      pattern: /\bemail to ta\b.*\b(?:quiz )?grade\b|\bta grade[- ]review email\b/i,
      build: () => "Draft TA grade-review email.",
      priority: 300,
      examples: [{ input: "email to TA about quiz grade", output: "Draft TA grade-review email." }],
      source: "seed"
    },
    {
      id: "elite.professor_grade_email",
      intent: "email_drafting",
      pattern: /\bprofessor\b.*\bgrade[- ]improvement\b|\bgrade[- ]improvement email\b|\bemail to professor about grade\b/i,
      build: () => "Draft professor grade-improvement email.",
      priority: 300,
      examples: [{ input: "email to professor about grade improvement", output: "Draft professor grade-improvement email." }],
      source: "seed"
    },
    {
      id: "elite.prof_extra_credit_grade",
      intent: "email_drafting",
      pattern: /\b(?:write|draft|compose|send)\s+(?:an?\s+)?(?:email|mail)\s+to\s+(?:my\s+)?(?:prof(?:essor|ressor)?|teacher)\b.*\bextra\s+credit\b/i,
      build: () => "Polite Email prof: extra credit assignment? [grade dropping]",
      priority: 305,
      examples: [
        {
          input: "write an email to my profressor asking him if there's an assignment i could do for an extra credit since my grade is dropping pls make it polite",
          output: "Polite Email prof: extra credit assignment? [grade dropping]"
        }
      ],
      source: "seed"
    },
    {
      id: "elite.landlord_repair_email",
      intent: "email_drafting",
      pattern: /\blandlord\b.*\brepair\b/i,
      build: () => "Draft landlord repair email.",
      priority: 300,
      examples: [{ input: "landlord repair request email", output: "Draft landlord repair email." }],
      source: "seed"
    },
    {
      id: "elite.guest_request_email",
      intent: "email_drafting",
      pattern: /\bguest request email\b/i,
      build: () => "Polish guest request email.",
      priority: 300,
      examples: [{ input: "guest request email polish", output: "Polish guest request email." }],
      source: "seed"
    },
    {
      id: "elite.split_bill",
      intent: "general_instruction",
      pattern: /\bsplit bill\b|\bbill split\b/i,
      build: () => "Split bill by items + tax/tip.",
      priority: 300,
      examples: [{ input: "split the bill by items", output: "Split bill by items + tax/tip." }],
      source: "seed"
    },
    {
      id: "elite.grad_student_budget",
      intent: "general_instruction",
      pattern: /\bgrad student monthly budget\b|\bmonthly (?:student|grad student) budget\b|\bmonthly budget\b.*\b(?:grad )?student\b/i,
      build: () => "Create grad student monthly budget.",
      priority: 300,
      examples: [{ input: "monthly budget for grad student", output: "Create grad student monthly budget." }],
      source: "seed"
    },
    // ── PAPER PRESENTATION (priority 250) ──────────────────────────────────────
    // Uses lookaheads to check all three terms independently of order.
    // build() reads m.input to access the full original string.
    {
      id: "qa.paper_presentation",
      intent: "summarization",
      pattern: /^(?=[\s\S]*\bpapers?\b)(?=[\s\S]*\bpresent(?:ation|ing)?\b)(?=[\s\S]*\b(?:summari[sz]e|prepare|help|understand|review)\b)/i,
      build: (m) => {
        const text = m.input ?? m[0];
        const countMatch = /\b(?:actually|really|about|around)?[,]?\s*(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+papers?\b/i.exec(text);
        const count = countMatch ? numberWordToDigits(countMatch[1]) : null;
        const deadlineMatch = /\b(?:in|within|by)\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+(days?|weeks?|hours?)\b/i.exec(text);
        const deadline = deadlineMatch ? ` in ${numberWordToDigits(deadlineMatch[1])} ${deadlineMatch[2].toLowerCase()}` : "";
        const subject = count ? `${count} papers` : "paper";
        return `Summarize ${subject} for presentation${deadline}.`;
      },
      priority: 250,
      examples: [
        { input: "summarize 3 papers for presentation in 2 days", output: "Summarize 3 papers for presentation in 2 days." },
        { input: "help me prepare for paper presentation", output: "Summarize paper for presentation." }
      ],
      source: "seed"
    },
    // ── WRITING REQUESTS (priority 200-220) ────────────────────────────────────
    {
      id: "creative.writing_with_style",
      intent: "creative_writing",
      pattern: /^(?:please\s+)?(?:write|draft|compose|create|generate)\s+(?:me\s+)?(?:a|an|the)?\s*(essay|report|article|blog post|paragraph|review|story|analysis|summary|poem|script|narrative|song|haiku)\s+(?:for\s+.+?\s+)?(?:on|about|of)\s+(.+?)\s+(?:make it|write it|keep it|make this|write this|keep this|make the tone|use a tone|in a|with a|for a)\s+(.+?)(?:\?|$)/i,
      build: (m) => `${artifactLabel(m[1])}: ${writingTopic(m[2])}, ${styleLabel(m[3])}.`,
      priority: 220,
      examples: [
        { input: "write an essay on climate change make it persuasive", output: "Essay: climate change, persuasive style." },
        { input: "create a blog post about AI in a casual friendly tone", output: "Blog post: AI, casual friendly style." }
      ],
      source: "seed"
    },
    {
      id: "creative.writing_plain",
      intent: "creative_writing",
      pattern: /^(?:please\s+)?(?:write|draft|compose|create|generate)\s+(?:me\s+)?(?:a|an|the)?\s*(essay|report|article|blog post|paragraph|review|story|analysis|summary|poem|script|narrative|song|haiku)\s+(?:on|about|of)\s+(.+?)(?:\?|$)/i,
      build: (m) => `${artifactLabel(m[1])}: ${writingTopic(m[2])}.`,
      priority: 200,
      examples: [
        { input: "write an essay on climate change", output: "Essay: climate change." },
        { input: "draft an article about machine learning", output: "Article: machine learning." }
      ],
      source: "seed"
    },
    // ── PROFESSIONAL-FRIENDLY MESSAGE REQUEST (priority 198) ─────────────────────
    // "Write me something professional but still friendly for asking about [topic]..."
    // → "Short professional-friendly message about [topic]."
    {
      id: "creative.professional_friendly_message",
      intent: "creative_writing",
      pattern: /^write\s+me\s+something\s+professional\s+but\s+still\s+friendly\s+for\s+(?:asking(?:\s+about)?|saying|doing)\s+(.+?)(?:,?\s+(?:and\s+)?keep\s+it\s+under\s+(\d+)\s+words?)?\.?$/i,
      build: (m) => {
        const topic = writingTopic((m[1] ?? "").replace(/^about\s+/i, "").trim());
        return `Short professional-friendly message about ${topic}.`;
      },
      priority: 198,
      examples: [
        { input: "Write me something professional but still friendly for asking about dating advice, and keep it under 150 words.", output: "Short professional-friendly message about dating advice." },
        { input: "Write me something professional but still friendly for asking about machine learning.", output: "Short professional-friendly message about machine learning." }
      ],
      source: "seed"
    },
    // ── "FASTEST WAY TO IMPROVE AT [TOPIC]" (priority 197) ─────────────────────
    // "tell me about the fastest way to improve at story pacing" → "Story pacing."
    // "I want to know the fastest way to improve at screen time please explain simply" → "Screen time please simply — simple."
    {
      id: "info.fastest_way_to_improve_at",
      intent: "question_answering",
      pattern: /^(?:(?:tell\s+me\s+about|I\s+want\s+to\s+know|can\s+you(?:\s+tell\s+me)?|could\s+you|help\s+me|I\s+need\s+(?:help\s+with)?|what\s+is|what'?s\s+the\s+best\s+way\s+to|whats?\s+(?:a\s+)?(?:good\s+)?way\s+to|what'?s|should\s+I|can\s+I|how\s+do\s+I|any\s+tips\s+(?:for|on|about)|give\s+me(?:\s+some)?)\s+)?the\s+fastest\s+way\s+to\s+improve\s+at\s+(.+?)(?:\s+(please\s+.+|make\s+it\s+.+|keep\s+it\s+.+|be\s+realistic.+|with\s+examples?.+|I\s+(?:need|tried|don'?t|haven'?t).+))?\.?$/i,
      build: (m) => {
        const topic = cleanTopic((m[1] ?? "").trim());
        const constraintRaw = (m[2] ?? "").toLowerCase().replace(/[.!?]+$/, "").replace(/\s+(?:tbh|rn|ngl|fr)\s*$/i, "").replace(/^with\s+/, "").replace(/\bexplain\s+/i, "").trim();
        const label = constraintRaw ? deriveConstraintLabel(constraintRaw) : "";
        if (!constraintRaw) return topic ? `${sc(topic.toLowerCase())}.` : "";
        return label ? `${sc(topic.toLowerCase())} ${constraintRaw} \u2014 ${label}.` : `${sc(topic.toLowerCase())} ${constraintRaw}.`;
      },
      priority: 197,
      examples: [
        { input: "tell me about the fastest way to improve at story pacing", output: "Story pacing." },
        { input: "I want to know the fastest way to improve at screen time please explain simply.", output: "Screen time please simply \u2014 simple." }
      ],
      source: "seed"
    },
    // ── "EXPLAIN X LIKE I'M 5 [CONSTRAINT]" (priority 196) ──────────────────────
    // "could you explain headaches like I'm 5 with examples if possible." → "Headaches like i'm 5 examples if possible — examples."
    // "how do I explain Indian food like I'm 5 please explain simply." → "How to indian food like i'm 5 please simply — simple."
    {
      id: "info.explain_like_five",
      intent: "question_answering",
      pattern: /^(?:(?:could\s+you|how\s+do\s+I|I\s+want\s+to\s+know|tell\s+me\s+about)\s+)?(?:explain|describe)\s+(.+?)\s+like\s+(?:I'?m\s+5|a\s+(?:five[\s-]year[\s-]old|5[\s-]year[\s-]old|child|toddler|beginner))(?:\s+(please\s+.+|with\s+examples?.+|make\s+it\s+.+|keep\s+it\s+.+|I'?m\s+.+))?\.?$/i,
      build: (m) => {
        const topic = cleanTopic((m[1] ?? "").trim());
        if (!topic) return "";
        const constraintRaw = (m[2] ?? "").toLowerCase().replace(/[.!?]+$/, "").replace(/\s+(?:rn|tbh|tbf|imo|ngl|im)\s*$/i, "").replace(/^with\s+/, "").replace(/\bexplain\s+/i, "").trim();
        const frameIsHowDoI = /^how\s+do\s+I\s+/i.test((m.input ?? "").replace(/\s+/g, " ").trim());
        const topicClean = frameIsHowDoI ? `How to ${topic.toLowerCase()}` : sc(topic.toLowerCase());
        const suffix = "like i'm 5";
        if (!constraintRaw) return `${topicClean} ${suffix}.`;
        const label = deriveConstraintLabel(constraintRaw);
        return label ? `${topicClean} ${suffix} ${constraintRaw} \u2014 ${label}.` : `${topicClean} ${suffix} ${constraintRaw}.`;
      },
      priority: 196,
      examples: [
        { input: "could you explain headaches like I'm 5 with examples if possible.", output: "Headaches like i'm 5 examples if possible \u2014 examples." },
        { input: "how do I explain Indian food like I'm 5 please explain simply.", output: "How to indian food like i'm 5 please simply \u2014 simple." },
        { input: "tell me about explain saving money like I'm 5.", output: "Saving money like i'm 5." },
        { input: "could you explain debugging like I'm 5 I'm kinda overwhelmed rn.", output: "Debugging like i'm 5 i'm kinda overwhelmed." }
      ],
      source: "seed"
    },
    // ── EMAIL SPECIFICS (priority 185-199) ─────────────────────────────────────
    {
      id: "email.boss_raise",
      intent: "email_drafting",
      pattern: /^write (?:a |an )?(?:email|message|letter)\s+to\s+my boss asking for a raise after working here for\s+(.+?)(?:\.|\?|$)/i,
      build: (m) => `Draft: ${cleanTopic(m[1]).toLowerCase()} tenure salary raise request.`,
      priority: 198,
      examples: [{ input: "write an email to my boss asking for a raise after working here for 2 years", output: "Draft: 2 years tenure salary raise request." }],
      source: "seed"
    },
    {
      id: "email.post_interview_thankyou",
      intent: "email_drafting",
      pattern: /^write (?:a |an )?follow up email after a job interview thanking the interviewer(?:\.|\?|$)/i,
      build: () => "Draft: post-interview thank you email.",
      priority: 198,
      examples: [{ input: "write a follow up email after a job interview thanking the interviewer", output: "Draft: post-interview thank you email." }],
      source: "seed"
    },
    {
      id: "email.client_apology",
      intent: "email_drafting",
      pattern: /^write (?:a |an )?apology email to a client for missing a project deadline(?:\.|\?|$)/i,
      build: () => "Draft: client apology for missed deadline.",
      priority: 198,
      examples: [{ input: "write an apology email to a client for missing a project deadline", output: "Draft: client apology for missed deadline." }],
      source: "seed"
    },
    {
      id: "email.vc_cold_outreach",
      intent: "email_drafting",
      pattern: /^write (?:a |an )?cold outreach email to a potential venture capital investor(?:\.|\?|$)/i,
      build: () => "Draft: VC cold outreach email.",
      priority: 198,
      examples: [{ input: "write a cold outreach email to a potential venture capital investor", output: "Draft: VC cold outreach email." }],
      source: "seed"
    },
    {
      id: "email.draft_brief",
      intent: "email_drafting",
      pattern: /^(?:i need you to |can you |please )?draft (?:a |an )?(?:short |brief )?(polite |professional )?email (?:asking|requesting)\s+(.+?)\s+for\s+(.+?)(?:\.|\?|$)/i,
      build: (m) => `Draft brief ${m[1] ?? ""}email: ${cleanTopic(m[2]).toLowerCase()} for ${cleanTopic(m[3]).toLowerCase()}.`,
      priority: 190,
      examples: [{ input: "draft a polite email asking my professor for a deadline extension", output: "Draft brief polite email: professor for deadline extension." }],
      source: "seed"
    },
    {
      id: "email.write_to_person",
      intent: "email_drafting",
      pattern: /^(?:write|draft|compose)\s+(?:a |an )?(polite |professional )?email\s+to\s+(.+?)\s+(?:asking|requesting)\s+for\s+(.+?)(?:\.|\?|$)/i,
      build: (m) => `Draft ${m[1] ?? ""}email: ${cleanTopic(m[2]).toLowerCase()} for ${cleanTopic(m[3]).toLowerCase()}.`,
      priority: 185,
      examples: [{ input: "write a polite email to my professor asking for an extension", output: "Draft polite email: professor for extension." }],
      source: "seed"
    },
    // ── TRANSLATION (priority 185) ─────────────────────────────────────────────
    {
      id: "translation.from_to",
      intent: "translation",
      pattern: /^(?:can you\s+)?translate (?:the following |this |these )?(?:text|paragraph|sentence|document|recipe|contract|instructions?)\s+(?:from\s+(.+?)\s+)?(?:in)?to\s+(.+?)(?:\s+for me)?(?:\?|$)/i,
      build: (m) => m[1] ? `Translate from ${compactFactualSubject(m[1])} to ${compactFactualSubject(m[2])}:` : `Translate to ${compactFactualSubject(m[2])}:`,
      priority: 185,
      examples: [
        { input: "translate this sentence from English to French", output: "Translate from English to French:" },
        { input: "translate this document into Spanish", output: "Translate to Spanish:" }
      ],
      source: "seed"
    },
    // ── SUMMARIZATION (priority 175-180) ───────────────────────────────────────
    {
      id: "summarization.into_bullets_into",
      intent: "summarization",
      pattern: /^(?:could you |can you |please )?summari[sz]e\s+(?:the following |this |the )?(.+?)\s+into\s+(\w+|\d+)\s+(?:concise |brief )?(bullets?|bullet points?)(?:\?|$)/i,
      build: (m) => `Summarize ${cleanTopic(m[1]).toLowerCase()}: ${m[2]} concise ${m[3].toLowerCase()}.`,
      priority: 180,
      examples: [{ input: "summarize this article into 3 concise bullet points", output: "Summarize article: 3 concise bullet points." }],
      source: "seed"
    },
    {
      id: "summarization.into_bullets_in",
      intent: "summarization",
      pattern: /^(?:could you |can you |please )?summari[sz]e\s+(?:the following |this |the )?(.+?)\s+in\s+(\w+|\d+)\s+(?:concise |brief )?(bullets?|bullet points?)(?:\.|\?|$)/i,
      build: (m) => `Summarize ${cleanTopic(m[1]).toLowerCase()}: ${m[2]} concise ${m[3].toLowerCase()}.`,
      priority: 178,
      examples: [{ input: "summarize the meeting notes in 3 bullet points", output: "Summarize meeting notes: 3 concise bullet points." }],
      source: "seed"
    },
    // ── CODE GENERATION (priority 170-175) ─────────────────────────────────────
    {
      id: "code.generate_with_tests",
      intent: "code_generation",
      pattern: /^(?:generate|write|create)\s+(?:a |an )?(javascript|typescript|python|java|go|rust|c\+\+)?\s*(function|class|script|component)?\s+that\s+(.+?)\s+and\s+include\s+tests(?:\.|\?|$)/i,
      build: (m) => `Generate ${m[1] ? `${langify(m[1])} ` : ""}${m[2] ?? "code"}: ${cleanTopic(m[3]).toLowerCase()}; tests.`,
      priority: 175,
      examples: [{ input: "generate a TypeScript function that validates emails and include tests", output: "Generate TypeScript function: validates emails; tests." }],
      source: "seed"
    },
    {
      id: "code.generate_in_language",
      intent: "code_generation",
      pattern: /^(?:generate|write|create)\s+(javascript|typescript|python|java|go|rust|c\+\+)\s+code\s+to\s+(.+?)(?:\.|\?|$)/i,
      build: (m) => {
        const task = cleanTopic(m[2]).replace(/\ba\s+csv\b/gi, "CSV").replace(/\bcsv\b/gi, "CSV").replace(/\s+and\s+/gi, "; ").replace(/\s+;\s+/g, "; ");
        return `Generate ${langify(m[1])} code: ${task}.`;
      },
      priority: 170,
      examples: [{ input: "generate python code to read a csv and print rows", output: "Generate Python code: read CSV; print rows." }],
      source: "seed"
    },
    // ── GOAL QUESTIONS (priority 165) ──────────────────────────────────────────
    {
      id: "action.goal_question",
      intent: "general_instruction",
      pattern: /^(?:I\s+)?(?:need|want|would like|am trying|I'm trying)\s+to\s+.+?\b(?:what|where|how|which)\s+(?:can|should|could|would|do)\s+(?:I|you|one|someone)\b/i,
      build: (m) => {
        const text = (m.input ?? m[0]).replace(/\s+/g, " ").replace(/\s+([?.!,;:])/g, "$1").trim().replace(/[?.!]+$/, "");
        const markerA = /\b(?:what|where|how|which)\s+(?:can|should|could|would|do)\s+I\b/i.exec(text);
        const markerB = /\b(?:what|where|how|which)\s+(?:can|should|could|would)\s+(?:you|one|someone)\b/i.exec(text);
        const marker = markerA ?? markerB;
        if (!marker) return "";
        const before = text.slice(0, marker.index).replace(/[,;:\s]+$/g, "").trim();
        const after = text.slice(marker.index).trim();
        const knowAboutM = after.match(/\b(?:should\s+I\s+)?(?:know|learn)\s+about\s+(.+?)(?:[.?!]|$)/i);
        if (knowAboutM) {
          const topic = cleanTopic(knowAboutM[1]);
          if (topic.split(/\s+/).length >= 2) {
            const trailingC = after.match(/\?\s+(.+?)(?:[.!]|$)/);
            if (trailingC) {
              const c = trailingC[1].toLowerCase().replace(/[.!]+$/, "");
              const label = deriveConstraintLabel(c);
              return label ? `${sc(topic.toLowerCase())}? ${c} \u2014 ${label}.` : `${sc(topic.toLowerCase())}? ${c}.`;
            }
            return `${sc(topic.toLowerCase())}?`;
          }
        }
        const howDoIM = after.match(/^how\s+do\s+I\s+(.+?)(?:[.?!]|$)/i);
        if (howDoIM) {
          const topic = cleanTopic(howDoIM[1]);
          const isPreambleContextGoal = /\b(?:get (?:an? )?internship|get (?:a )?job|land (?:a\s+)?(?:job|internship)|lose weight|save money|start (?:a )?business|get fit|get healthy|become \w+|pass (?:my )?exam)\b/i.test(before);
          if (isPreambleContextGoal && topic.length > 2 && !/^(?:this|that|it|one|started|going|done|rid)\b/i.test(topic)) {
            const trailingC = after.match(/\?\s+(.+?)(?:[.!]|$)/);
            if (trailingC) {
              const c = trailingC[1].toLowerCase().replace(/[.!]+$/, "");
              const label = deriveConstraintLabel(c);
              return label ? `How to ${topic.toLowerCase()}? ${c} \u2014 ${label}.` : `How to ${topic.toLowerCase()}? ${c}.`;
            }
            return `How to ${topic.toLowerCase()}?`;
          }
        }
        const goalMatch = before.match(/^(?:I\s+)?(?:need|want|would like|am trying|I'm trying)\s+to\s+(.+)$/i);
        if (!goalMatch) return "";
        const goal = compactGoal(goalMatch[1]);
        const suffix = extractDirectiveSuffix(after);
        return `${goal}.${suffix ? ` ${suffix}` : ""}`.trim();
      },
      priority: 165,
      examples: [
        { input: "I want to plan a date night for my girlfriend what can I do include cheap options", output: "Date night ideas for girlfriend's. Include budget options." },
        { input: "I need to choose a laptop for college what should I buy give product links", output: "College laptop recommendations. Include product links." }
      ],
      source: "seed"
    },
    // ── GOAL DIRECTIVES (priority 162) ─────────────────────────────────────────
    {
      id: "action.goal_directive",
      intent: "general_instruction",
      pattern: /^(?:I\s+)?(?:need|want|would like|am trying|I'm trying)\s+to\s+.+?\b(?:send|give|include|show|with)\b/i,
      build: (m) => {
        const text = (m.input ?? m[0]).replace(/\s+/g, " ").replace(/\s+([?.!,;:])/g, "$1").trim();
        const split = /\b(?:send|give|include|show|with)\b/i.exec(text);
        if (!split) return "";
        const before = text.slice(0, split.index).replace(/[,;:\s]+$/g, "").trim();
        const after = text.slice(split.index).trim();
        const goalMatch = before.match(/^(?:I\s+)?(?:need|want|would like|am trying|I'm trying)\s+to\s+(.+)$/i);
        if (!goalMatch) return "";
        const goal = compactGoal(goalMatch[1]);
        const suffix = extractDirectiveSuffix(after);
        if (!suffix) return "";
        return `${goal}. ${suffix}`;
      },
      priority: 162,
      examples: [
        { input: "I need to buy my mom something for her birthday what can I get her give links to products too please", output: "Gift ideas for mom's birthday. Include product links." },
        { input: "I want to get a gift for my friends 23rd bday, send amazon links pls", output: "Gift ideas for friend's 23rd birthday. Include Amazon links." }
      ],
      source: "seed"
    },
    // ── TOPIC + TRAILING CONSTRAINT (priority 163) ────────────────────────────
    // Handles 22% of dataset: "any tips for X? [constraint]", "tell me about X? constraint",
    // "what should I know about X? constraint", "how do I X? constraint", "[preamble], [frame] X? constraint"
    // Teacher style: "[Topic]? [constraint verbatim lowercase] — [label]."
    {
      id: "info.topic_trailing_constraint",
      intent: "question_answering",
      pattern: /^.+?\?\s+(?:make\s+it|keep\s+it|I\s+(?:need|don'?t|only|can'?t|tried|have(?:\s+been)?|really)|please\s+\w|pls\b|bc\s+I|and\s+I|I\s+only|explain\s+simply|for\s+beginners?|I'?m\s+(?:stuck|kinda)|with\s+examples?|examples?\s+if\s+possible|be\s+realistic)/i,
      build: (m) => {
        const text = (m.input ?? m[0]).replace(/\s+/g, " ").trim();
        const splitM = /\?\s+((?:make\s+it|keep\s+it|I\s+(?:need|don'?t|only|can'?t|tried|have(?:\s+been)?|really)|please\s+\w|pls\b|bc\s+I|and\s+I|I\s+only|explain\s+simply|for\s+beginners?|I'?m\s+(?:stuck|kinda)|with\s+examples?|examples?\s+if\s+possible|be\s+realistic).+?)\.?\s*$/i.exec(text);
        if (!splitM) return "";
        const beforeQ = text.slice(0, text.length - splitM[0].length).replace(/\?\s*$/, "").trim();
        const constraintRaw = splitM[1].toLowerCase().replace(/[.!?]+$/, "").replace(/\s+(?:rn|tbh|tbf|imo|ngl|im)\s*$/i, "").trim();
        const constraint = constraintRaw.replace(/^with\s+/, "").replace(/\bpls\b\s*/gi, "").replace(/\bexplain\s+/i, "");
        const PREAMBLE_FRAME_RE = /^(?:(?:and\s+honestly|idk\s+if\s+this\s+is\s+dumb\s+but)\s+)?(?:.*?[,;]\s+)?(?:any\s+tips\s+for|tell\s+me\s+(?:about|more\s+about)?|what\s+should\s+I\s+know\s+about|what\s+(?:is|are)\s+(?:some\s+)?(?:tips?\s+for|ways?\s+to)|help\s+me\s+(?:with\s+)?|how\s+do\s+I|how\s+to|what'?s?\s+(?:the\s+)?best\s+way\s+to|whats?\s+(?:a\s+)?(?:good\s+)?way\s+to|can\s+you\s+(?:tell\s+me\s+about)?|give\s+me\s+(?:some\s+)?(?:tips?\s+(?:for|on)|advice\s+(?:for|on))|I\s+(?:need|want)\s+(?:to\s+know\s+|help\s+(?:with\s+)?)?|advice\s+on|idk\s+if\s+this\s+is\s+dumb\s+but)\s*/i;
        const stripped = beforeQ.replace(PREAMBLE_FRAME_RE, "").trim();
        const topic = cleanTopic(stripped || beforeQ);
        const frameIsHowDoI = /^how\s+do\s+I\s+/i.test(beforeQ.replace(/^.*?[,;]\s+/i, ""));
        const topicClean = frameIsHowDoI ? `How to ${topic.toLowerCase()}` : sc(topic.toLowerCase());
        const label = deriveConstraintLabel(constraint);
        return label ? `${topicClean}? ${constraint} \u2014 ${label}.` : `${topicClean}? ${constraint}.`;
      },
      priority: 163,
      examples: [
        { input: "any tips for budgeting? make it beginner friendly.", output: "Budgeting? make it beginner friendly \u2014 beginner-friendly." },
        { input: "tell me about sleep schedule? make it beginner friendly.", output: "Sleep schedule? make it beginner friendly \u2014 beginner-friendly." },
        { input: "how do I renewable energy? keep it short please.", output: "How to renewable energy? keep it short please \u2014 short." },
        { input: "I'm planning a solo trip, tell me about React bug? I need something practical.", output: "React bug? i need something practical \u2014 practical." }
      ],
      source: "seed"
    },
    // ── STEP-BY-STEP PLAN TOPIC EXTRACTION (priority 161) ─────────────────────
    // Matches "give me/any tips for/I need/how do I a step by step plan for X [constraint]"
    // and outputs teacher-style "[Topic] [constraint] — [label]." stripping the plan frame.
    {
      id: "info.step_by_step_plan",
      intent: "question_answering",
      pattern: /^(?:(?:any tips for|give me|I need(?:\s+help)?(?:\s+with)?|should I|how do I|I want(?:\s+to(?:\s+know)?)?|tell me(?:\s+about)?|can you(?:\s+give me)?|help me(?:\s+with)?|I'?m?\s+looking for|whats?\s+(?:a\s+)?(?:good\s+)?(?:way to)?|idk\s+if\s+this\s+is\s+dumb\s+but)\s+(?:an?\s+)?)step by step plan for\s+(.+)$/i,
      build: (m) => {
        const rest = (m[1] ?? "").trim().replace(/[.?!]+$/, "");
        const constraintM = /\s+(I(?:'m|\s+am)?\s+(?:need|only have|don't|tried|have(?:\s+been)?|really)|make\s+it|keep\s+it|please|I\s+only|pls[,\s]|but\s+I|bc\s+I|bc[,\s]|I\s+don'?t|honestly|and\s+honestly|explain\s+(?:simply|it)|for\s+\w+ers?|u\s+know)/i.exec(rest);
        let topic;
        let constraint;
        if (constraintM && constraintM.index > 2) {
          topic = rest.slice(0, constraintM.index).trim();
          constraint = rest.slice(constraintM.index).trim().toLowerCase().replace(/[.?!]+$/, "").replace(/\bexplain\s+/i, "").replace(/\bpls\b\s*/gi, "").trim();
        } else {
          topic = rest;
          constraint = "";
        }
        const topicSc = sc(cleanTopic(topic));
        if (!constraint) return `${topicSc}.`;
        const label = deriveConstraintLabel(constraint);
        return label ? `${topicSc} ${constraint} \u2014 ${label}.` : `${topicSc} ${constraint}.`;
      },
      priority: 161,
      examples: [
        { input: "any tips for a step by step plan for cold war I need something practical", output: "Cold war i need something practical \u2014 practical." },
        { input: "I need help with a step by step plan for SQL joins make it beginner friendly", output: "Sql joins make it beginner friendly \u2014 beginner-friendly." },
        { input: "give me a step by step plan for cheap flights I need this by tomorrow", output: "Cheap flights i need this by tomorrow \u2014 needed tomorrow." }
      ],
      source: "seed"
    },
    // ── "GIMME ADVICE ON [TOPIC] [CONSTRAINT]" (priority 162) ────────────────────
    // "gimme advice on carry on packing please explain simply." → "Carry on packing please simply — simple."
    // "gimme advice on job rejection with examples if possible." → "Job rejection examples if possible — examples."
    {
      id: "info.gimme_advice_on_topic",
      intent: "general_instruction",
      pattern: /^(?:gimme|give\s+me)\s+(?:some\s+)?advice\s+on\s+(.+?)(?:\s+(please\s+.+|with\s+.+|make\s+it\s+.+|keep\s+it\s+.+|be\s+.+))?\.?$/i,
      build: (m) => {
        const topic = cleanTopic((m[1] ?? "").trim());
        if (!topic) return "";
        const constraintRaw = (m[2] ?? "").toLowerCase().replace(/[.!?]+$/, "").replace(/^with\s+/, "").replace(/\bexplain\s+/i, "").replace(/\s+(?:rn|tbh)\s*$/i, "").trim();
        if (!constraintRaw) return `${sc(topic.toLowerCase())}.`;
        const label = deriveConstraintLabel(constraintRaw);
        return label ? `${sc(topic.toLowerCase())} ${constraintRaw} \u2014 ${label}.` : `${sc(topic.toLowerCase())} ${constraintRaw}.`;
      },
      priority: 162,
      examples: [
        { input: "gimme advice on carry on packing please explain simply.", output: "Carry on packing please simply \u2014 simple." },
        { input: "gimme advice on job rejection with examples if possible.", output: "Job rejection examples if possible \u2014 examples." },
        { input: "give me advice on meal prepping.", output: "Meal prepping." }
      ],
      source: "seed"
    },
    // ── "AND HONESTLY" MID-SENTENCE PREAMBLE STRIP (priority 162) ───────────────
    // "[preamble] and honestly [frame?] [topic] [constraint?]" → "[Topic] [constraint] — [label]."
    // "I'm starting gym again after a year and honestly any tips for cardio I need this by tomorrow."
    //   → "Cardio i need this by tomorrow — needed tomorrow."
    // "I'm a CS grad student at Northwestern and honestly help me worldbuilding" → "Worldbuilding."
    {
      id: "info.and_honestly_preamble",
      intent: "general_instruction",
      pattern: /^(.+?)\s+and\s+honestly\s+(?:(?:help\s+me(?:\s+with)?|any\s+tips\s+(?:for|on|about)|give\s+me(?:\s+some)?|I\s+need(?:\s+help)?(?:\s+with)?|tell\s+me\s+(?:about|more\s+about\s+)?|can\s+you|could\s+you|I\s+want\s+to\s+know|what(?:'?s)?\s+(?:the\s+)?(?:a\s+)?(?:good\s+|best\s+)?(?:way\s+to)|please\s+give\s+me)\s+)?(.+?)\.?$/i,
      build: (m) => {
        const preamble = (m[1] ?? "").trim();
        const rest = (m[2] ?? "").trim().replace(/\.$/, "").trim();
        if (!rest) return "";
        const constraintM = /\s+(I\s+(?:need|tried|don'?t|only|can'?t|really)|make\s+it|keep\s+it|please\s+\w|pls\b|with\s+examples?|examples?\s+if\s+possible)/i.exec(rest);
        let topic;
        let constraint;
        if (constraintM && constraintM.index > 2) {
          topic = rest.slice(0, constraintM.index).trim();
          constraint = rest.slice(constraintM.index).trim().toLowerCase().replace(/\s+(?:tbh|rn|tbf|imo|ngl)(?:[.,!?]\s*(?:pls|please))?\s*$/i, "").replace(/\s+(?:pls|please)\.?\s*$/i, "").replace(/[.!?]+$/, "").replace(/^with\s+/, "").replace(/\bexplain\s+/i, "");
        } else {
          topic = rest;
          constraint = "";
        }
        const topicClean = topic.replace(/\s+(?:rn|tbh|tbf|imo|fwiw|ngl|lol|lmk)\s*$/gi, "").replace(/[\?\.!]+$/, "").replace(/^(?:a|an|the|some|any|this|that)\s+/i, "").replace(/\s{2,}/g, " ").trim().toLowerCase();
        if (!topicClean) return "";
        const preambleBody = preamble.replace(/^I(?:'m|'ve|\s+am|\s+have)\s+/i, "");
        const hasProperNoun = /\b[A-Z][a-z]{1,}/.test(preambleBody);
        const preambleCleaned = preamble.replace(/\s+(?:rn|tbh|ngl|tbf|imo)\s*$/i, "").trim();
        const preambleWords = preambleCleaned.split(/\s+/).length;
        const isItsMyContext = /^its?\s+(?:my|your|our|his|her|their)\s+/i.test(preamble);
        const topicSc = sc(topicClean);
        if (!hasProperNoun && preambleWords <= 4 && !constraint && isItsMyContext) {
          return `${sc(preamble.toLowerCase())} and honestly ${topicClean}.`;
        }
        if (!constraint) return `${topicSc}.`;
        const label = deriveConstraintLabel(constraint);
        return label ? `${topicSc} ${constraint} \u2014 ${label}.` : `${topicSc} ${constraint}.`;
      },
      priority: 162,
      examples: [
        { input: "its my rest day and honestly any tips for villain arc", output: "Its my rest day and honestly villain arc." },
        { input: "I'm a CS grad student at Northwestern and honestly help me worldbuilding", output: "Worldbuilding." },
        { input: "I'm travelling to Tokyo next month and honestly whats a good way to Git workflow", output: "Git workflow." },
        { input: "I'm starting gym again after a year and honestly any tips for cardio I need this by tomorrow.", output: "Cardio i need this by tomorrow \u2014 needed tomorrow." },
        { input: "I'm studying for finals and honestly I need help with carry on packing", output: "Carry on packing." }
      ],
      source: "seed"
    },
    // ── "[PREAMBLE], I NEED HELP WITH / CAN U HELP ME WITH TOPIC" (priority 161) ─
    // "I'm broke this month tbh, I need help with career switch?" → "Career switch."
    // "I'm 21 and trying to save money, can u help me with roommate conflict pls" → "Roommate conflict."
    {
      id: "info.preamble_help_with_topic",
      intent: "general_instruction",
      pattern: /^(.+?),\s+(?:I\s+need\s+help\s+with|can\s+u\s+help\s+me(?:\s+with)?|can\s+you\s+help\s+me(?:\s+with)?|could\s+you|help\s+me(?:\s+with)?|I\s+want\s+to\s+know|I\s+need|should\s+I|how\s+do\s+I|any\s+tips\s+(?:for|on|about)|give\s+me(?:\s+some)?(?:\s+tips)?)\s+(.+?)(?:\s+(?:pls|please|tho))?\.?\??$/i,
      build: (m) => {
        const preamble = (m[1] ?? "").trim();
        const topicFull = (m[2] ?? "").replace(/[?!.]+$/, "").replace(/\s+(?:rn|tbh|tbf|imo|fwiw|ngl|lol|lmk|gimme)\s*$/gi, "").replace(/\s+(?:pls|tho)\.?\s*$/gi, "").replace(/\b(?:pls)\b\s*/gi, "").replace(/\s{2,}/g, " ").trim();
        const preambleBody = preamble.replace(/^I(?:'m|'ve|\s+am|\s+have|\s+just)\s+/i, "");
        const hasProperNoun = /\b[A-Z][a-z]{1,}/.test(preambleBody);
        const hasQuantifiedActivity = /\b(?:working|doing|juggling|balancing|taking|handling|managing)\s+\d+/i.test(preamble);
        const preambleWords = preamble.trim().split(/\s+/).length;
        const isItsMyContext = /^its?\s+(?:my|your|our|his|her|their)\s+/i.test(preamble);
        const keepPreamble = hasProperNoun || hasQuantifiedActivity || preambleWords <= 4 && isItsMyContext;
        const qConstraintM = /^(.+?)\?\s+(.+?)$/.exec(topicFull);
        if (qConstraintM) {
          const topicCore = cleanTopic((qConstraintM[1] ?? "").trim());
          const constraintRaw = (qConstraintM[2] ?? "").toLowerCase().replace(/[.!?]+$/, "").replace(/\s+(?:tbh|rn|tbf|imo|ngl)\s*$/i, "").replace(/^with\s+/, "").replace(/\bexplain\s+/i, "").trim();
          const label = deriveConstraintLabel(constraintRaw);
          const topicSc = keepPreamble ? `${preamble.toLowerCase()}, ${topicCore.toLowerCase()}?` : `${sc(topicCore.toLowerCase())}?`;
          return label ? `${topicSc} ${constraintRaw} \u2014 ${label}.` : `${topicSc} ${constraintRaw}.`;
        }
        const pleaseM = /\s+(please\s+\S)/i.exec(topicFull);
        if (pleaseM && pleaseM.index > 1) {
          const topicCore = topicFull.slice(0, pleaseM.index).trim();
          const constraintRaw = topicFull.slice(pleaseM.index).trim().toLowerCase().replace(/\s+(?:tbh|rn|tbf|ngl)\s*$/i, "").replace(/[.!?]+$/, "").replace(/\bexplain\s+/i, "").trim();
          const label = deriveConstraintLabel(constraintRaw);
          const topicSc = keepPreamble ? `${preamble.toLowerCase()}, ${topicCore.toLowerCase()}` : `${sc(topicCore.toLowerCase())}`;
          return label ? `${topicSc} ${constraintRaw} \u2014 ${label}.` : `${topicSc} ${constraintRaw}.`;
        }
        let topic = topicFull.replace(/\b(?:pls)\b\s*/gi, "").replace(/\s{2,}/g, " ").trim();
        const preambleSubject = preamble.match(/\b(?:like|about)\s+([a-z][\w\s]{1,30}?)(?:\s*,|\s*$)/i)?.[1]?.trim();
        if (preambleSubject && /\b(?:good\s+)?resources?\b|\btips\b|\bguide\b/i.test(topic) && !topic.toLowerCase().includes(preambleSubject.toLowerCase())) {
          const forBeginners = /\bfor beginners?\b/i.test(topic);
          const learnHobby = /\blearn(?:ing)?\s+(?:a\s+)?(?:new\s+)?hobby\b/i.test(preamble);
          const core = topic.replace(/\bgood\s+/i, "").replace(/\bsome\s+/i, "").replace(/\s+for beginners?\b/i, "").replace(/\s{2,}/g, " ").trim();
          topic = forBeginners || learnHobby ? `${preambleSubject} beginner ${core}` : `${preambleSubject} ${core}`;
        }
        if (!topic) return "";
        if (keepPreamble) {
          return `${preamble.toLowerCase()}, ${topic.toLowerCase()}.`;
        }
        const out = sc(topic.toLowerCase());
        return /\bresources?\b|\btips\b/i.test(out) ? `${out}?` : `${out}.`;
      },
      priority: 164,
      examples: [
        { input: "I'm a CS grad student at Northwestern, I need help with taxes", output: "i'm a cs grad student at northwestern, taxes." },
        { input: "I'm planning a solo trip, can u help me with sushi at home pls", output: "Sushi at home." },
        { input: "I'm 21 and trying to save money, can u help me with roommate conflict pls", output: "Roommate conflict." }
      ],
      source: "seed"
    },
    // ── PREAMBLE "WHAT SHOULD I KNOW ABOUT TOPIC" (priority 160) ────────────────
    // "[preamble], what should I know about [topic]?" with no trailing constraint
    // → "[Topic]."  (topic_trailing_constraint at 163 handles the constraint case)
    {
      id: "info.preamble_know_about_topic",
      intent: "question_answering",
      pattern: /^(.+?)[,.]?\s+what should I know about\s+(.+?)(?:\?|$)/i,
      build: (m) => {
        const preamble = (m[1] ?? "").trim();
        const full = (m.input ?? m[0]).replace(/\s+/g, " ").trim();
        const preambleBody = preamble.replace(/^I(?:'m|'ve|\s+am|\s+have|\s+just)\s+/i, "");
        const hasProperNoun = /\b[A-Z][a-z]{1,}/.test(preambleBody);
        const hasQuantifiedActivity = /\b(?:working|doing|juggling|balancing|taking|handling|managing)\s+\d+/i.test(preamble);
        const preambleWords = preamble.trim().split(/\s+/).length;
        const isItsMyContext = /^its?\s+(?:my|your|our|his|her|their)\s+/i.test(preamble);
        const keepPreamble = hasProperNoun || hasQuantifiedActivity || preambleWords <= 4 && isItsMyContext;
        const preambleOut = keepPreamble ? preamble.replace(/\s+(?:rn|tbh|ngl)\s*$/i, "").trim().toLowerCase() : "";
        const qConstraintM = /what should I know about\s+(.+?)\?\s+(.+?)\.?\s*$/i.exec(full);
        if (qConstraintM) {
          const topic2 = cleanTopic((qConstraintM[1] ?? "").trim());
          const constraint = (qConstraintM[2] ?? "").toLowerCase().replace(/[.!?]+$/, "").replace(/^with\s+/, "").trim();
          const label = deriveConstraintLabel(constraint);
          const topicSc = keepPreamble ? `${preambleOut}, ${topic2.toLowerCase()}?` : `${sc(topic2.toLowerCase())}?`;
          return label ? `${topicSc} ${constraint} \u2014 ${label}.` : `${topicSc} ${constraint}.`;
        }
        const topic = cleanTopic((m[2] ?? "").replace(/[?!]+$/, "").trim());
        if (!topic) return "";
        if (keepPreamble) {
          return `${preambleOut}, ${topic.toLowerCase()}.`;
        }
        return `${sc(topic.toLowerCase())}.`;
      },
      priority: 164,
      examples: [
        { input: "I'm starting gym again after a year, what should I know about group project?", output: "Group project." },
        { input: "I'm a new parent, what should I know about sleep training?", output: "Sleep training." },
        { input: "I'm starting gym again after a year, what should I know about communication? be realistic tho.", output: "Communication? be realistic tho \u2014 realistic." }
      ],
      source: "seed"
    },
    // ── FILLER-FRAME MINIMAL TOPIC EXTRACTION (priority 156) ─────────────────
    // For frames with no trailing "? constraint", produce just the topic noun.
    // "any tips for worldbuilding" → "Worldbuilding."
    // "idk if this is dumb but whats a good way to Docker" → "Docker."
    {
      id: "info.filler_frame_topic",
      intent: "question_answering",
      pattern: /^(?:(?:idk\s+if\s+(?:this\s+is\s+)?dumb(?:\s+but)?|and\s+honestly)\s+)?(?:any\s+tips\s+(?:for|on|about)|any\s+advice\s+(?:for|on)|give\s+me\s+(?:some\s+)?tips\s+(?:for|on|about)|help\s+me(?:\s+with)?|I\s+want\s+to\s+know|whats?\s+(?:a\s+)?(?:good\s+)?(?:way\s+to|the\s+best\s+way\s+to)|what\s+is\s+the\s+best\s+way\s+to)\s+(.+?)(?:[.!]|$)/i,
      build: (m) => {
        const raw = (m[1] ?? "").trim().replace(/[.?!]+$/, "");
        const topic = cleanTopic(raw);
        return topic ? `${sc(topic.toLowerCase())}.` : "";
      },
      priority: 156,
      examples: [
        { input: "any tips for worldbuilding", output: "Worldbuilding." },
        { input: "idk if this is dumb but any tips for worldbuilding", output: "Worldbuilding." },
        { input: "idk if this is dumb but whats a good way to Docker", output: "Docker." }
      ],
      source: "seed"
    },
    // ── "SHOULD I / CAN I [TOPIC] [CONSTRAINT]" FILLER FRAME (priority 157) ──────
    // "idk if this is dumb but should I saving money keep it short please." → "Saving money keep it short please — short."
    // "should I freelancing make it beginner friendly" → "Freelancing make it beginner friendly — beginner-friendly."
    {
      id: "info.should_i_filler_topic",
      intent: "general_instruction",
      pattern: /^(?:(?:idk\s+if\s+(?:this\s+is\s+)?dumb(?:\s+but)?|and\s+honestly)\s+)?(?:should\s+I|can\s+I|could\s+you|can\s+you|help\s+me(?:\s+with)?)\s+(.+?)(?:\s+(keep\s+it\s+.+|make\s+it\s+.+|please\s+.+|I\s+(?:need|only|don'?t|tried)|be\s+realistic|with\s+examples?|for\s+beginners?|pls\b.*))?\.?$/i,
      build: (m) => {
        const topicRaw = (m[1] ?? "").trim().replace(/[.?!]+$/, "");
        const topic = cleanTopic(topicRaw);
        if (!topic) return "";
        const constraintRaw = (m[2] ?? "").toLowerCase().replace(/[.!?]+$/, "").replace(/\s+(?:rn|tbh|tho)\s*$/i, "").replace(/^with\s+/, "").replace(/\bexplain\s+/i, "").trim();
        if (!constraintRaw) return `${sc(topic.toLowerCase())}.`;
        const label = deriveConstraintLabel(constraintRaw);
        return label ? `${sc(topic.toLowerCase())} ${constraintRaw} \u2014 ${label}.` : `${sc(topic.toLowerCase())} ${constraintRaw}.`;
      },
      priority: 157,
      examples: [
        { input: "idk if this is dumb but should I saving money keep it short please.", output: "Saving money keep it short please \u2014 short." },
        { input: "should I freelancing make it beginner friendly", output: "Freelancing make it beginner friendly \u2014 beginner-friendly." }
      ],
      source: "seed"
    },
    // ── PREAMBLE + "SHOULD I [TOPIC]? [CONSTRAINT]" (priority 158) ────────────
    // "I'm starting gym again after a year, should I habit tracking? I need this by tomorrow."
    //   → "Habit tracking? i need this by tomorrow — needed tomorrow."
    {
      id: "info.preamble_should_i_topic",
      intent: "question_answering",
      pattern: /^(.+?),\s+(?:should\s+I|can\s+I)\s+(.+?)(?:\?\s+(.+?))?\.?\s*$/i,
      build: (m) => {
        const preamble = (m[1] ?? "").trim();
        const topicRaw = cleanTopic((m[2] ?? "").replace(/[?!.]+$/, "").trim());
        if (!topicRaw) return "";
        const constraintRaw = (m[3] ?? "").toLowerCase().replace(/[.!?]+$/, "").replace(/^with\s+/, "").replace(/\bexplain\s+/i, "").replace(/\s+(?:rn|tbh)\s*$/i, "").trim();
        const preambleBody = preamble.replace(/^I(?:'m|'ve|\s+am|\s+have|\s+just)\s+/i, "");
        const hasProperNoun = /\b[A-Z][a-z]{1,}/.test(preambleBody);
        const hasVisaOrRoleCode = /\b(?:F\d|OPT|H-?1B?|J\d|TN|L-?1|O-?1)\b/i.test(preamble);
        const hasQuantifiedActivity = /\b(?:working|doing|juggling|balancing|taking|handling|managing)\s+\d+/i.test(preamble);
        const preambleWords = preamble.trim().split(/\s+/).length;
        const topicSc = sc(topicRaw.toLowerCase());
        const label = constraintRaw ? deriveConstraintLabel(constraintRaw) : "";
        const isItsMyContext = /^its?\s+(?:my|your|our|his|her|their)\s+/i.test(preamble);
        const keepPreamble = hasProperNoun || hasVisaOrRoleCode || hasQuantifiedActivity || preambleWords <= 4 && isItsMyContext;
        if (keepPreamble) {
          const preambleClean = preamble.replace(/\s+(?:rn|tbh|ngl)\s*$/i, "").trim().toLowerCase();
          const base = `${preambleClean}, ${topicRaw.toLowerCase()}?`;
          return constraintRaw ? label ? `${base} ${constraintRaw} \u2014 ${label}.` : `${base} ${constraintRaw}.` : `${base}`;
        }
        if (!constraintRaw) return `${topicSc}?`;
        return label ? `${topicSc}? ${constraintRaw} \u2014 ${label}.` : `${topicSc}? ${constraintRaw}.`;
      },
      priority: 165,
      examples: [
        { input: "I'm starting gym again after a year, should I habit tracking? I need this by tomorrow.", output: "Habit tracking? i need this by tomorrow \u2014 needed tomorrow." },
        { input: "its my rest day, should I cold plunge?", output: "Its my rest day, cold plunge?" }
      ],
      source: "seed"
    },
    // ── "HOW DO I [TOPIC]?" → "How to [topic]?" (priority 168) ─────────────────
    // "how do I system design" → "How to system design?"
    // "idk if this is dumb but how do I psychology basics" → "How to psychology basics?"
    // "how do I the fastest way to improve at solo travel" → "How to solo travel?"
    // "how do I a step by step plan for career switch" → "How to career switch?"
    {
      id: "info.how_do_i_topic",
      intent: "question_answering",
      // Only match simple single-topic forms — no comma, no "and what", no multi-clause
      pattern: /^(?:(?:idk\s+if\s+(?:this\s+is\s+)?dumb(?:\s+but)?)\s+)?how\s+do\s+I\s+(?:(?:the\s+)?fastest\s+way\s+to\s+(?:improve\s+at|learn)\s+|a\s+step\s+by\s+step\s+plan\s+for\s+)?([^,?!.]+?)[.!?]?\s*$/i,
      build: (m) => {
        const raw = (m[1] ?? "").replace(/[?!.]+$/, "").trim();
        if (/\band\s+what\b|\bif\s+I'?m\b|\bknow\s+if\b/i.test(raw)) return "";
        const topic = cleanTopic(raw);
        if (!topic) return "";
        return `How to ${topic.toLowerCase()}?`;
      },
      priority: 198,
      examples: [
        { input: "how do I system design", output: "How to system design?" },
        { input: "idk if this is dumb but how do I psychology basics", output: "How to psychology basics?" },
        { input: "how do I the fastest way to improve at solo travel", output: "How to solo travel?" },
        { input: "how do I a step by step plan for career switch", output: "How to career switch?" }
      ],
      source: "seed"
    },
    // ── "[PREAMBLE] AND I REALLY NEED HELP WITH [TOPIC] [CONSTRAINT]" (priority 167, below 168) ─
    // Teacher keeps preamble when it has a proper noun or quantified activity ("I'm working 2 jobs").
    // Teacher strips generic preambles ("I'm in my final semester", "I'm burned out").
    // "I'm working 2 jobs rn and I really need help with bench press plateau please explain simply."
    //   → "I'm working 2 jobs and i really need help bench press plateau please simply — simple."
    // "I'm a CS grad student at Northwestern and I really need help with phone addiction I need something practical."
    //   → "I'm a cs grad student at northwestern and i really need help phone addiction i need something practical — practical."
    // "I'm in my final semester and I really need help with apology text I need this by tomorrow."
    //   → "And i really need help apology text i need this by tomorrow — needed tomorrow."
    {
      id: "info.and_i_really_need_help",
      intent: "question_answering",
      pattern: /^(.+?)\s+and\s+I\s+really\s+need\s+help\s+(?:with\s+)?(.+?)\s*[.!]?\s*$/i,
      build: (m) => {
        const preamble = (m[1] ?? "").trim();
        const fullRaw = (m[2] ?? "").trim().replace(/[.!]+$/, "").trim();
        const constraintM = /\s+(please\s+\w|I\s+(?:need|tried|only|don'?t)|make\s+it|with\s+examples?|examples?\s+if|be\s+realistic|for\s+beginners?|I'?m\s+kinda|I\s+only\s+have)/i.exec(fullRaw);
        let topic;
        let constraintRaw;
        if (constraintM && constraintM.index > 2) {
          topic = fullRaw.slice(0, constraintM.index).trim();
          constraintRaw = fullRaw.slice(constraintM.index).trim().toLowerCase().replace(/\s+(?:tbh|rn|tbf|imo|ngl|fr)\s*$/i, "").replace(/[.!?]+$/, "").replace(/^with\s+/, "").replace(/\bexplain\s+/i, "").trim();
        } else {
          topic = fullRaw;
          constraintRaw = "";
        }
        const topicClean = topic.replace(/\s+(?:rn|tbh|tbf|imo|fwiw|ngl|lol|lmk|fr|gimme)\s*$/gi, "").replace(/[\?\.!]+$/, "").replace(/^(?:a|an|the|some|any|this|that)\s+/i, "").replace(/\s{2,}/g, " ").trim().toLowerCase();
        if (!topicClean) return "";
        const label = constraintRaw ? deriveConstraintLabel(constraintRaw) : "";
        const preambleBody = preamble.replace(/^I(?:'m|'ve|\s+am|\s+have|\s+just)\s+/i, "");
        const hasProperNoun = /\b[A-Z][a-z]{1,}/.test(preambleBody);
        const hasQuantifiedActivity = /\b(?:working|doing|juggling|balancing|taking|handling|managing|caring\s+for)\s+\d+/i.test(preamble);
        const keepPreamble = hasProperNoun || hasQuantifiedActivity;
        const preambleClean = preamble.replace(/\s+(?:rn|tbh|ngl|tbf|imo)\s*$/i, "").replace(/\s{2,}/g, " ").trim().toLowerCase();
        if (keepPreamble) {
          if (!constraintRaw) return `${preambleClean} and i really need help ${topicClean}.`;
          return label ? `${preambleClean} and i really need help ${topicClean} ${constraintRaw} \u2014 ${label}.` : `${preambleClean} and i really need help ${topicClean} ${constraintRaw}.`;
        }
        if (!constraintRaw) return `And i really need help ${topicClean}.`;
        return label ? `And i really need help ${topicClean} ${constraintRaw} \u2014 ${label}.` : `And i really need help ${topicClean} ${constraintRaw}.`;
      },
      priority: 167,
      examples: [
        { input: "I'm working 2 jobs rn and I really need help with bench press plateau please explain simply.", output: "I'm working 2 jobs and i really need help bench press plateau please simply \u2014 simple." },
        { input: "I'm a CS grad student at Northwestern and I really need help with phone addiction I need something practical.", output: "I'm a cs grad student at northwestern and i really need help phone addiction i need something practical \u2014 practical." },
        { input: "I'm in my final semester and I really need help with apology text I need this by tomorrow.", output: "And i really need help apology text i need this by tomorrow \u2014 needed tomorrow." },
        { input: "I'm burned out lately and I really need help with stop procrastinating with examples if possible.", output: "And i really need help stop procrastinating examples if possible \u2014 examples." }
      ],
      source: "seed"
    },
    // ── GIFT PATTERNS (priority 155) ───────────────────────────────────────────
    {
      id: "gift.for_person_suggest_my",
      intent: "brainstorming",
      pattern: /^I want to get a gift for my\s+(.+?),\s*suggest\s+(?:some\s+)?products?(?:\.|\?|$)/i,
      build: (m) => `Gift ideas for ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 158,
      examples: [{ input: "I want to get a gift for my dad, suggest some products", output: "Gift ideas for dad." }],
      source: "seed"
    },
    {
      id: "gift.for_person_suggest",
      intent: "brainstorming",
      pattern: /^I want to get a gift for\s+(.+?),\s*suggest\s+(?:some\s+)?products?(?:\.|\?|$)/i,
      build: (m) => `Gift ideas for ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 155,
      examples: [{ input: "I want to get a gift for my friend, suggest some products", output: "Gift ideas for friend." }],
      source: "seed"
    },
    // ── HOBBY / INTEREST PATTERNS (priority 150-158) ───────────────────────────
    {
      id: "hobby.explore_new",
      intent: "question_answering",
      pattern: /^(?:so\s+)?I have a new hobby I want to explore it it(?:'s| is)\s+(.+?)\s+and I want to know more about it(?:\?|$)/i,
      build: (m) => hobbyOverview(m[1]),
      priority: 158,
      examples: [{ input: "so I have a new hobby I want to explore it it's fencing and I want to know more about it", output: "Fencing overview" }],
      source: "seed"
    },
    {
      id: "hobby.just_started",
      intent: "question_answering",
      pattern: /^I just started a new hobby it(?:'s| is)\s+(.+?)\s+and I want to know more(?:\?|$)/i,
      build: (m) => hobbyOverview(m[1]),
      priority: 156,
      examples: [{ input: "I just started a new hobby it's rock climbing and I want to know more", output: "Rock Climbing overview" }],
      source: "seed"
    },
    {
      id: "hobby.picked_up",
      intent: "question_answering",
      pattern: /^I picked up\s+(.+?)\s+recently and I want to learn more about it(?:\?|$)/i,
      build: (m) => hobbyOverview(m[1]),
      priority: 156,
      examples: [{ input: "I picked up photography recently and I want to learn more about it", output: "Photography overview" }],
      source: "seed"
    },
    {
      id: "hobby.my_new_hobby",
      intent: "question_answering",
      pattern: /^my new hobby is\s+(.+?)\s+and I want to explore it further(?:\?|$)/i,
      build: (m) => hobbyOverview(m[1]),
      priority: 156,
      examples: [{ input: "my new hobby is pottery and I want to explore it further", output: "Pottery overview" }],
      source: "seed"
    },
    {
      id: "hobby.new_interest",
      intent: "question_answering",
      pattern: /^I have a new interest its\s+(.+?)\s+(?:I want to learn more|can you tell me more about it)(?:\?|$)/i,
      build: (m) => hobbyOverview(m[1]),
      priority: 156,
      examples: [{ input: "I have a new interest its chess I want to learn more", output: "Chess overview" }],
      source: "seed"
    },
    {
      id: "hobby.recently_started",
      intent: "question_answering",
      pattern: /^(?:I recently started|I started)\s+(.+?)\s+as a hobby and want to (?:learn|explore).*(?:\?|$)/i,
      build: (m) => hobbyOverview(m[1]),
      priority: 154,
      examples: [{ input: "I recently started painting as a hobby and want to learn more", output: "Painting overview" }],
      source: "seed"
    },
    {
      id: "hobby.got_into",
      intent: "question_answering",
      pattern: /^(?:I got into|got into)\s+(.+?)\s+(?:last week\s+)?(?:as a new hobby\s+)?(?:and want to know more about it|what should I know)(?:\?|$)/i,
      build: (m) => hobbyOverview(m[1]),
      priority: 152,
      examples: [{ input: "I got into tennis last week as a new hobby and want to know more about it", output: "Tennis overview" }],
      source: "seed"
    },
    // ── LEARNING RESOURCES (priority 145-150) ──────────────────────────────────
    {
      id: "qa.learn_x_resources_are_there",
      intent: "question_answering",
      pattern: /^I want to learn\s+(.+?),?\s+(?:are there any|any|what|where can I find).*\bresources?\b.*(?:\?|$)/i,
      build: (m) => `${compactTopic(learningTopic(m[1]))} beginner resources?`,
      priority: 150,
      examples: [
        { input: "I want to learn fencing, are there any resources I can use?", output: "Fencing beginner resources?" },
        { input: "I want to learn a new sport maybe fencing, are there any resources I can use?", output: "Fencing beginner resources?" }
      ],
      source: "seed"
    },
    {
      id: "qa.learn_x_resources_give",
      intent: "question_answering",
      pattern: /^I want to learn\s+(.+?),?\s+give me\s+(?:some\s+)?(?:good\s+)?resources?.*(?:\?|$)/i,
      build: (m) => `${compactTopic(learningTopic(m[1]))} beginner resources?`,
      priority: 148,
      examples: [{ input: "I want to learn Spanish, give me some resources", output: "Spanish beginner resources?" }],
      source: "seed"
    },
    {
      id: "qa.get_into_x_resources",
      intent: "question_answering",
      pattern: /^I want to get into\s+(.+?),?\s+(?:what|any|are there any|where can I find).*\bresources?\b.*(?:\?|$)/i,
      build: (m) => `${compactTopic(m[1])} beginner resources?`,
      priority: 148,
      examples: [{ input: "I want to get into tennis, what beginner resources should I use?", output: "Tennis beginner resources?" }],
      source: "seed"
    },
    // ── HOW LONG — EXACT PHRASES (priority 140-148) ────────────────────────────
    {
      id: "qa.how_long_last_freezer",
      intent: "question_answering",
      pattern: /^how long does\s+(.+?)\s+last in (?:the\s+)?freezer(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(`frozen ${m[1]}`)} shelf life?`,
      priority: 148,
      examples: [{ input: "how long does chicken last in the freezer", output: "Frozen Chicken shelf life?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_stay_system",
      intent: "question_answering",
      pattern: /^how long does\s+(.+?)\s+stay in (?:your|my|the)\s+system(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[1])} clearance time?`,
      priority: 148,
      examples: [{ input: "how long does caffeine stay in your system", output: "Caffeine clearance time?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_mortgage_close",
      intent: "question_answering",
      pattern: /^how long does\s+(?:a |an |the )?mortgage\s+take to close(?:\?|$)/i,
      build: () => "Mortgage closing time?",
      priority: 148,
      examples: [{ input: "how long does a mortgage take to close", output: "Mortgage closing time?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_take_cure_dry",
      intent: "question_answering",
      pattern: /^how long does\s+(.+?)\s+take to\s+(cure|dry|close)(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[1])} ${m[2].toLowerCase().replace(/e$/, "")}ing time?`,
      priority: 146,
      examples: [{ input: "how long does concrete take to cure", output: "Concrete curing time?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_take_work",
      intent: "question_answering",
      pattern: /^how long does\s+(.+?)\s+take to\s+(?:work|kick in|start working)(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[1])} onset time?`,
      priority: 146,
      examples: [{ input: "how long does ibuprofen take to work", output: "Ibuprofen onset time?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_last_generic",
      intent: "question_answering",
      pattern: /^how long does\s+(.+?)\s+last(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[1])} duration?`,
      priority: 144,
      examples: [{ input: "how long does a car battery last", output: "Car Battery duration?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_take_learn",
      intent: "question_answering",
      pattern: /^how long does it take to learn\s+(.+?)(?:\?|$)/i,
      build: (m) => `Time to learn ${compactFactualSubject(m[1])}?`,
      priority: 143,
      examples: [{ input: "how long does it take to learn Python", output: "Time to learn Python?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_take_build",
      intent: "question_answering",
      pattern: /^how long does it take to build\s+(.+?)(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[1])} building timeline?`,
      priority: 143,
      examples: [{ input: "how long does it take to build a house", output: "House building timeline?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_take_recover",
      intent: "question_answering",
      pattern: /^how long does it take to recover from\s+(.+?)(?:\?|$)/i,
      build: (m) => `Post-${cleanTopic(m[1]).toLowerCase()} recovery time?`,
      priority: 143,
      examples: [{ input: "how long does it take to recover from surgery", output: "Post-surgery recovery time?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_take_ev",
      intent: "question_answering",
      pattern: /^how long does it take to charge\s+(?:an? |the )?electric car(?:\?|$)/i,
      build: () => "EV charging time?",
      priority: 143,
      examples: [{ input: "how long does it take to charge an electric car", output: "EV charging time?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_take_get",
      intent: "question_answering",
      pattern: /^how long does it take to get\s+(?:a |an |the )?(.+?)(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[1])} processing time?`,
      priority: 141,
      examples: [{ input: "how long does it take to get a passport", output: "Passport processing time?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_take_run",
      intent: "question_answering",
      pattern: /^how long does it take to run\s+(?:a |an |the )?(.+?)(?:\?|$)/i,
      build: (m) => `Average ${compactFactualSubject(m[1])} run time?`,
      priority: 141,
      examples: [{ input: "how long does it take to run a marathon", output: "Average Marathon run time?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_walk_mile",
      intent: "question_answering",
      pattern: /^how long does it take to walk\s+(?:a |an |the )?mile(?:\?|$)/i,
      build: () => "Walking pace per mile?",
      priority: 143,
      examples: [{ input: "how long does it take to walk a mile", output: "Walking pace per mile?" }],
      source: "seed"
    },
    // ── HOW MANY — EXACT FORMS (priority 138-144) ──────────────────────────────
    {
      id: "qa.daily_calorie_intake",
      intent: "question_answering",
      pattern: /^how many calories should I eat (?:per|a|each)\s+day(?:\?|$)/i,
      build: () => "Daily calorie intake?",
      priority: 144,
      examples: [{ input: "how many calories should I eat per day", output: "Daily calorie intake?" }],
      source: "seed"
    },
    {
      id: "qa.daily_steps",
      intent: "question_answering",
      pattern: /^how many steps should I walk (?:per|a|each)\s+day(?:\?|$)/i,
      build: () => "Recommended daily steps?",
      priority: 144,
      examples: [{ input: "how many steps should I walk per day", output: "Recommended daily steps?" }],
      source: "seed"
    },
    {
      id: "qa.sleep_hours",
      intent: "question_answering",
      pattern: /^how many hours of sleep (?:do I|should I|does a person)\s+need(?:\?|$)/i,
      build: () => "Recommended sleep hours?",
      priority: 144,
      examples: [{ input: "how many hours of sleep do I need", output: "Recommended sleep hours?" }],
      source: "seed"
    },
    {
      id: "qa.daily_grams_nutrient",
      intent: "question_answering",
      pattern: /^how many grams of\s+(.+?)\s+(?:do I|should I|does a person)\s+need\s+(?:per|a|each)\s+day(?:\?|$)/i,
      build: (m) => `Daily ${singularizeNoun(m[1])} target?`,
      priority: 142,
      examples: [{ input: "how many grams of protein do I need per day", output: "Daily protein target?" }],
      source: "seed"
    },
    {
      id: "qa.mg_dosage",
      intent: "question_answering",
      pattern: /^how many (?:mg|milligrams) of\s+(.+?)\s+should I\s+take(?:\?|$)/i,
      build: (m) => `Recommended ${cleanTopic(m[1]).replace(/\bd\b/i, "D")} dosage?`,
      priority: 142,
      examples: [{ input: "how many mg of vitamin D should I take", output: "Recommended Vitamin D dosage?" }],
      source: "seed"
    },
    {
      id: "qa.daily_generic_target",
      intent: "question_answering",
      pattern: /^how many\s+(.+?)\s+should\s+(?:I|an? adult|a person|people|you)\s+(?:eat|take|get|drink|consume|have|walk|sleep|do)\s+(?:per|a|each)\s+day(?:\?|$)/i,
      build: (m) => `Daily ${singularizeNoun(m[1])} target?`,
      priority: 140,
      examples: [{ input: "how many calories should an adult consume per day", output: "Daily calorie target?" }],
      source: "seed"
    },
    {
      id: "qa.how_many_times_week",
      intent: "question_answering",
      pattern: /^how many times a week should I\s+(.+?)(?:\?|$)/i,
      build: (m) => `Recommended ${cleanTopic(m[1]).toLowerCase()} frequency?`,
      priority: 140,
      examples: [{ input: "how many times a week should I work out", output: "Recommended work out frequency?" }],
      source: "seed"
    },
    {
      id: "qa.how_many_adult_need",
      intent: "question_answering",
      pattern: /^how many (.+?) (?:does|do) (?:an? )?(?:adult|person|human|child|baby|woman|man) need(?:\?|$)/i,
      build: (m) => `Recommended ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 138,
      examples: [{ input: "how many calories does a person need", output: "Recommended calories?" }],
      source: "seed"
    },
    // ── FACTUAL — EXPLAIN / ANSWER BRIEFLY (priority 130-140) ─────────────────
    {
      id: "qa.answer_briefly",
      intent: "question_answering",
      pattern: /^(?:please )?answer briefly:\s*what(?:'s| is)\s+(?:a |an |the )?(.+?)(?:\?|$)/i,
      build: (m) => briefQuestion(m[1]),
      priority: 140,
      examples: [{ input: "Please answer briefly: what is DNS?", output: "DNS? Briefly." }],
      source: "seed"
    },
    {
      id: "qa.explain_how_works",
      intent: "question_answering",
      pattern: /^explain how\s+(.+?)\s+works?(?:\?|$)/i,
      build: (m) => `How ${cleanTopic(m[1]).toLowerCase()} works?`,
      priority: 138,
      examples: [{ input: "explain how TCP/IP works", output: "How TCP/IP works?" }],
      source: "seed"
    },
    {
      id: "qa.explain_simple_terms",
      intent: "question_answering",
      pattern: /^explain\s+(.+?)\s+in simple terms(?:\?|$)/i,
      build: (m) => `${titleCaseSubject(m[1])} explained simply.`,
      priority: 136,
      examples: [{ input: "explain photosynthesis in simple terms", output: "Photosynthesis explained simply." }],
      source: "seed"
    },
    {
      id: "qa.tell_me_what_simple",
      intent: "question_answering",
      pattern: /^(?:can you )?tell me what\s+(.+?)\s+is\s+in\s+simple terms(?:\?|$)/i,
      build: (m) => `${compactTopic(m[1])}? Simple terms.`,
      priority: 135,
      examples: [{ input: "can you tell me what machine learning is in simple terms", output: "Machine learning? Simple terms." }],
      source: "seed"
    },
    {
      id: "qa.explain_one_sentence",
      intent: "question_answering",
      pattern: /^(?:can you )?(?:please )?explain (?:what |how )?(.+?)\s+(?:is|works)(?:\s+in\s+(?:one|a)\s+(?:short\s+)?sentence)?(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())}? One sentence.`,
      priority: 133,
      examples: [{ input: "Can you please explain what photosynthesis is in one short sentence?", output: "Photosynthesis? One sentence." }],
      source: "seed"
    },
    // ── RECIPE / MAKE (priority 125-130) — DEDUPLICATED ────────────────────────
    {
      id: "qa.how_do_you_make",
      intent: "question_answering",
      pattern: /^how (?:do you|does one) make\s+(.+?)(?:\?|$)/i,
      build: (m) => recipeCompress(m[1]),
      priority: 130,
      examples: [{ input: "how do you make pasta carbonara", output: "Carbonara pasta recipe?" }],
      source: "seed"
    },
    {
      id: "qa.how_do_i_make",
      intent: "question_answering",
      pattern: /^how do I make\s+(.+?)(?:\?|$)/i,
      build: (m) => /^(.+?)\s+from scratch$/i.test(cleanTopic(m[1])) ? `Homemade ${cleanTopic(m[1]).replace(/\s+from scratch$/i, "").toLowerCase()} recipe?` : `${titleCaseSubject(cleanTopic(m[1]))} recipe?`,
      priority: 128,
      examples: [{ input: "how do I make sourdough bread from scratch", output: "Homemade sourdough bread recipe?" }],
      source: "seed"
    },
    {
      id: "qa.best_way_to_make",
      intent: "question_answering",
      pattern: /^what(?:'s| is) the best way to (?:make|cook|prepare|bake)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Best ${cleanTopic(m[1]).toLowerCase()} method?`,
      priority: 126,
      examples: [{ input: "what's the best way to cook rice quickly", output: "Best rice method?" }],
      source: "seed"
    },
    {
      id: "qa.best_way_to_x",
      intent: "question_answering",
      pattern: /^what(?:'s| is) the best way to\s+(.+?)(?:\?|$)/i,
      build: (m) => `Best way to ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 122,
      examples: [{ input: "what's the best way to learn guitar", output: "Best way to learn guitar?" }],
      source: "seed"
    },
    // ── WHAT IS / WHO / WHEN (priority 100-122) ────────────────────────────────
    {
      id: "qa.what_language_spoken",
      intent: "question_answering",
      pattern: /^what language (?:do|does) (?:they|people)\s+speak in\s+(.+?)(?:\?|$)/i,
      build: (m) => `Language spoken in ${compactFactualSubject(m[1])}?`,
      priority: 122,
      examples: [{ input: "what language do they speak in Brazil", output: "Language spoken in Brazil?" }],
      source: "seed"
    },
    {
      id: "qa.what_continent",
      intent: "question_answering",
      pattern: /^what continent is\s+(.+?)\s+in(?:\?|$)/i,
      build: (m) => `Continent of ${compactFactualSubject(m[1])}?`,
      priority: 122,
      examples: [{ input: "what continent is Egypt in", output: "Continent of Egypt?" }],
      source: "seed"
    },
    {
      id: "qa.what_country",
      intent: "question_answering",
      pattern: /^what country is\s+(.+?)\s+in(?:\?|$)/i,
      build: (m) => `Country of ${compactFactualSubject(m[1])}?`,
      priority: 122,
      examples: [{ input: "what country is the Eiffel Tower in", output: "Country of the Eiffel Tower?" }],
      source: "seed"
    },
    {
      id: "qa.difference_between",
      intent: "analysis",
      pattern: /^what(?:'s| is) (?:the )?difference between\s+(.+?)\s+and\s+(.+?)(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[1])} vs ${compactFactualSubject(m[2])}: differences?`,
      priority: 120,
      examples: [
        { input: "what's the difference between mitosis and meiosis", output: "Mitosis vs Meiosis: differences?" },
        { input: "what is the difference between HTTP and HTTPS", output: "HTTP vs HTTPS: differences?" }
      ],
      source: "seed"
    },
    {
      id: "qa.how_much_x_in_y",
      intent: "question_answering",
      pattern: /^how much\s+(.+?)\s+(?:is\s+)?in\s+(?:a |an |the )?(.+?)(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[2])} ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 118,
      examples: [{ input: "how much protein is in a chicken breast", output: "Chicken Breast protein?" }],
      source: "seed"
    },
    {
      id: "qa.what_count_of",
      intent: "question_answering",
      pattern: /^what(?:'s| is) (?:a |an |the )?(.+?) count (?:of|in|for)\s+(?:a |an |the )?(.+?)(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[2])} ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 118,
      examples: [{ input: "what's the calorie count for a Snickers bar?", output: "Snickers bar calorie? Briefly." }],
      source: "seed"
    },
    {
      id: "qa.calorie_count_what_is",
      intent: "question_answering",
      pattern: /^what(?:'s| is) (?:the )?(?:calorie count|calories?) (?:of|in|for)\s+(?:a |an |the )?(.+?)(?:\?|$)/i,
      build: (m) => conciseSubjectQuestion(m[1], "calories"),
      priority: 118,
      examples: [{ input: "what's the calorie count for a Snickers bar?", output: "Snickers bar calories? Briefly." }],
      source: "seed"
    },
    {
      id: "qa.how_many_calories_in",
      intent: "question_answering",
      pattern: /^how many calories (?:are )?(?:in|does|do)\s+(?:a |an |the )?(.+?)(?:\s+have)?(?:\?|$)/i,
      build: (m) => conciseSubjectQuestion(m[1], "calories"),
      priority: 116,
      examples: [
        { input: "how many calories are in a banana?", output: "Banana calories? Briefly." },
        { input: "how many calories in a twix bar", output: "Twix bar calories? Briefly." }
      ],
      source: "seed"
    },
    {
      id: "qa.how_many_x_in_y",
      intent: "question_answering",
      pattern: /^how many (.+?) (?:are )?(?:in|does|do)\s+(?:a |an |the )?(.+?)(?:\s+have)?(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[2]).toLowerCase())} ${cleanTopic(m[1]).toLowerCase()}? Briefly.`,
      priority: 114,
      examples: [{ input: "how many grams of protein are in two eggs?", output: "Two eggs protein? Briefly." }],
      source: "seed"
    },
    {
      id: "qa.how_is_treated",
      intent: "question_answering",
      pattern: /^how is\s+(.+?)\s+treated(?:\?|$)/i,
      build: (m) => `${compactFactualSubject(m[1])} treatment?`,
      priority: 114,
      examples: [{ input: "how is pneumonia treated", output: "Pneumonia treatment?" }],
      source: "seed"
    },
    {
      id: "qa.what_is_the_noun_of",
      intent: "question_answering",
      pattern: /^what(?:'s| is) (?:the )?(\w+) of\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(m[2].trim().replace(/\?+$/, ""))} ${m[1].toLowerCase()}?`,
      priority: 112,
      examples: [{ input: "what's the capital of France", output: "France capital?" }],
      source: "seed"
    },
    {
      id: "qa.what_are_symptoms_of",
      intent: "question_answering",
      pattern: /^what (?:are|is) the (?:symptom|side effect|sign|benefit|cause|effect)s? of\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())} ${symptomLabel(m[0])}?`,
      priority: 112,
      examples: [{ input: "what are the symptoms of dehydration?", output: "Dehydration symptoms?" }],
      source: "seed"
    },
    {
      id: "qa.what_best_x_for",
      intent: "question_answering",
      pattern: /^what(?:'s| are| is)(?: the)? best\s+(.+?)\s+(?:to|for|when|before|after)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Best ${cleanTopic(m[1]).toLowerCase()} for ${cleanTopic(m[2]).toLowerCase()}?`,
      priority: 110,
      examples: [{ input: "what's the best food to eat before a workout", output: "Best food for before a workout?" }],
      source: "seed"
    },
    {
      id: "qa.what_should_i_verb",
      intent: "question_answering",
      pattern: /^what should I\s+(\w+)\s+(before|after|during|for)\s+(.+?)(?:\?|$)/i,
      build: (m) => {
        const verb = m[1], timing = m[2].toLowerCase(), ctx = stripArticle(cleanTopic(m[3]));
        const timingLabel = { before: "pre", after: "post", during: "during", for: "for" };
        return `What to ${verb.toLowerCase()} ${timingLabel[timing] ?? timing}-${ctx.toLowerCase()}?`;
      },
      priority: 108,
      examples: [{ input: "what should I eat before a workout", output: "What to eat pre-workout?" }],
      source: "seed"
    },
    {
      id: "qa.what_should_i_do_if",
      intent: "question_answering",
      pattern: /^what should I do (?:if|when|about)\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())} \u2014 steps?`,
      priority: 108,
      examples: [{ input: "what should I do if my car breaks down", output: "Car breaks down \u2014 steps?" }],
      source: "seed"
    },
    // ── COMPARISON (priority 105-115) ──────────────────────────────────────────
    {
      id: "qa.explain_difference_between",
      intent: "analysis",
      pattern: /^(?:explain )?(?:the )?difference between\s+(.+?)\s+and\s+(.+?)(?:\.|\?|$)/i,
      build: (m) => `${compactTopic(m[1])} vs ${compactTopic(m[2])}: differences?`,
      priority: 115,
      examples: [{ input: "explain the difference between HTTP and HTTPS", output: "HTTP vs HTTPS: differences?" }],
      source: "seed"
    },
    {
      id: "qa.what_is_better_for",
      intent: "analysis",
      pattern: /^what is better for\s+(.+?)\s+(.+?)\s+or\s+(.+?)(?:\?|$)/i,
      build: (m) => `${cleanTopic(m[2])} vs ${cleanTopic(m[3])} for ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 113,
      examples: [{ input: "what is better for weight loss cardio or weights", output: "Cardio vs Weights for weight loss?" }],
      source: "seed"
    },
    {
      id: "qa.which_is_better",
      intent: "analysis",
      pattern: /^which is (?:better|faster|best|more \w+)\s+(.+?)\s+or\s+(.+?)(?:\?|$)/i,
      build: (m) => `${cleanTopic(m[1])} vs ${cleanTopic(m[2])}?`,
      priority: 113,
      examples: [{ input: "which is better React or Vue", output: "React vs Vue?" }],
      source: "seed"
    },
    {
      id: "qa.should_i_use_or",
      intent: "analysis",
      pattern: /^should I use\s+(.+?)\s+or\s+(.+?)\s+for\s+(.+?)(?:\?|$)/i,
      build: (m) => `${cleanTopic(m[1])} vs ${cleanTopic(m[2])} for ${cleanTopic(m[3])}?`,
      priority: 112,
      examples: [{ input: "should I use React or Vue for my project", output: "React vs Vue for my project?" }],
      source: "seed"
    },
    // ── SAFETY / CAN I (priority 105-115) ─────────────────────────────────────
    {
      id: "qa.is_safe_to_with",
      intent: "question_answering",
      pattern: /^is it (?:safe|okay|ok|fine|alright) to\s+(?:take|use|mix)\s+(.+?)\s+(?:with|and)\s+(.+?)(?:\?|$)/i,
      build: (m) => `${compactTopic(m[1])} with ${cleanTopic(m[2]).toLowerCase()} safe?`,
      priority: 115,
      examples: [{ input: "is it safe to take ibuprofen with coffee", output: "Ibuprofen with coffee safe?" }],
      source: "seed"
    },
    {
      id: "qa.can_i_use_on",
      intent: "question_answering",
      pattern: /^can I (?:use|apply|put)\s+(.+?)\s+on\s+(.+?)(?:\?|$)/i,
      build: (m) => `Is ${cleanTopic(m[1]).toLowerCase()} safe on ${trimContext(cleanTopic(m[2])).toLowerCase()}?`,
      priority: 113,
      examples: [{ input: "can I use apple cider vinegar on my hair", output: "Is apple cider vinegar safe on hair?" }],
      source: "seed"
    },
    {
      id: "qa.can_i_use_with",
      intent: "question_answering",
      pattern: /^can I (?:use|take|mix)\s+(.+?)\s+(?:with|and)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Is ${compactFactualSubject(m[1])} safe with ${cleanTopic(m[2]).toLowerCase()}?`,
      priority: 113,
      examples: [{ input: "can I take melatonin with alcohol", output: "Is Melatonin safe with alcohol?" }],
      source: "seed"
    },
    {
      id: "qa.can_i_after_taking",
      intent: "question_answering",
      pattern: /^can I\s+(\w+)\s+after taking\s+(.+?)(?:\?|$)/i,
      build: (m) => `Safe to ${m[1].toLowerCase()} after ${cleanTopic(m[2]).toLowerCase()}?`,
      priority: 111,
      examples: [{ input: "can I exercise after taking ibuprofen", output: "Safe to exercise after ibuprofen?" }],
      source: "seed"
    },
    {
      id: "qa.can_i_verb_after",
      intent: "question_answering",
      pattern: /^can I (?:drive|eat|drink|exercise)\s+(?:after|while|before|during)\s+(.+?)(?:\?|$)/i,
      build: (m) => {
        const verb = (m.input ?? m[0]).split(/\s+/)[2].toLowerCase();
        return `Safe to ${verb} after ${cleanTopic(m[1]).toLowerCase()}?`;
      },
      priority: 111,
      examples: [{ input: "can I drive after taking antihistamines", output: "Safe to drive after antihistamines?" }],
      source: "seed"
    },
    {
      id: "qa.can_i_use_generic",
      intent: "question_answering",
      pattern: /^can I (?:use|take)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Is ${cleanTopic(m[1]).toLowerCase()} safe to use?`,
      priority: 108,
      examples: [{ input: "can I use expired sunscreen", output: "Is expired sunscreen safe to use?" }],
      source: "seed"
    },
    {
      id: "qa.is_it_safe_to",
      intent: "question_answering",
      pattern: /^is it (?:safe|okay|ok|fine|alright) to\s+(.+?)(?:\?|$)/i,
      build: (m) => `Is ${cleanTopic(m[1]).toLowerCase()} safe?`,
      priority: 108,
      examples: [{ input: "is it safe to eat raw eggs", output: "Is eating raw eggs safe?" }],
      source: "seed"
    },
    {
      id: "qa.is_it_normal",
      intent: "question_answering",
      pattern: /^is it normal (?:to|for)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Is ${cleanTopic(m[1]).toLowerCase()} normal?`,
      priority: 108,
      examples: [{ input: "is it normal to feel tired after eating", output: "Is feeling tired after eating normal?" }],
      source: "seed"
    },
    {
      id: "qa.is_it_harmful",
      intent: "question_answering",
      pattern: /^is it (?:bad|harmful|dangerous) to\s+(.+?)(?:\?|$)/i,
      build: (m) => `Is ${cleanTopic(m[1]).toLowerCase()} harmful?`,
      priority: 108,
      examples: [{ input: "is it bad to drink coffee every day", output: "Is drinking coffee every day harmful?" }],
      source: "seed"
    },
    {
      id: "qa.is_it_possible",
      intent: "question_answering",
      pattern: /^is it (?:possible|feasible|realistic) to\s+(.+?)(?:\?|$)/i,
      build: (m) => `Can you ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 108,
      examples: [{ input: "is it possible to learn a language in 3 months", output: "Can you learn a language in 3 months?" }],
      source: "seed"
    },
    {
      id: "qa.is_it_okay",
      intent: "question_answering",
      pattern: /^is it (?:okay|ok|fine|alright|safe) (?:to |for )?(.+?)(?:\?|$)/i,
      build: (m) => `Is ${cleanTopic(m[1]).toLowerCase()} okay?`,
      priority: 106,
      examples: [{ input: "is it okay to skip breakfast", output: "Is skipping breakfast okay?" }],
      source: "seed"
    },
    // ── NEAR / LOCAL (priority 105-108) ────────────────────────────────────────
    {
      id: "qa.what_are_near",
      intent: "question_answering",
      pattern: /^what are some (?:\w+ )?(.+?)\s+near\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())} near ${m[2].trim().replace(/\?$/, "")}?`,
      priority: 108,
      examples: [{ input: "what are some good coffee shops near downtown", output: "Coffee shops near downtown?" }],
      source: "seed"
    },
    {
      id: "qa.where_can_find_near",
      intent: "question_answering",
      pattern: /^where can (?:I|you) (?:find|get|buy|see)\s+(?:some |a |good |any )?(.+?)\s+near\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())} near ${m[2].trim().replace(/\?$/, "")}?`,
      priority: 106,
      examples: [{ input: "where can I find good tacos near Austin", output: "Tacos near Austin?" }],
      source: "seed"
    },
    {
      id: "qa.nearest",
      intent: "question_answering",
      pattern: /^where is (?:the )?nearest\s+(.+?)(?:\s+to me)?(?:\?|$)/i,
      build: (m) => `Nearest ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 106,
      examples: [{ input: "where is the nearest pharmacy to me", output: "Nearest pharmacy?" }],
      source: "seed"
    },
    {
      id: "qa.what_ways_to",
      intent: "question_answering",
      pattern: /^what are some (?:good |useful )?ways? to\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())} methods?`,
      priority: 106,
      examples: [{ input: "what are some good ways to reduce stress", output: "Reduce stress methods?" }],
      source: "seed"
    },
    // ── HOW DOES ONE / HOW DO I (broad — priority 95) ─────────────────────────
    // Lower priority than the specific "how do I make" rules above.
    {
      id: "qa.how_does_one_x",
      intent: "question_answering",
      pattern: /^how do[es]? (?:I|one|you|we)\s+(.+?)(?:\?|$)/i,
      build: (m) => codeTopic(m[1]),
      priority: 95,
      examples: [
        { input: "how do I reverse a string in Python", output: "Reverse string in Python?" },
        { input: "how does one implement binary search", output: "Implement binary search?" }
      ],
      source: "seed"
    },
    // ── HOW LONG (generic forms — priority 90-95) ─────────────────────────────
    {
      id: "qa.how_long_does_take",
      intent: "question_answering",
      pattern: /^how long (?:does it take|do \w+ take) (?:for |to )?(.+?)(?:\?|$)/i,
      build: (m) => `How long does ${cleanTopic(m[1]).toLowerCase()} take?`,
      priority: 95,
      examples: [{ input: "how long does it take for hair to grow", output: "How long does hair to grow take?" }],
      source: "seed"
    },
    {
      id: "qa.how_long_does_last",
      intent: "question_answering",
      pattern: /^how long (?:does|do|will)\s+(.+?)\s+(?:take|last)(?:\?|$)/i,
      build: (m) => `How long does ${cleanTopic(m[1]).toLowerCase()} take?`,
      priority: 93,
      examples: [{ input: "how long will this medicine last", output: "How long does medicine take?" }],
      source: "seed"
    },
    // ── WHY (priority 90) ──────────────────────────────────────────────────────
    {
      id: "qa.why_x",
      intent: "question_answering",
      pattern: /^why (?:is|are|do|does|am|can't|won't|didn't|don't)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Why ${(m.input ?? m[0]).split(/\s+/)[1]} ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 90,
      examples: [{ input: "why is the sky blue", output: "Why is sky blue?" }],
      source: "seed"
    },
    // ── BROAD WHAT IS / WHO / WHEN (priority 85-92) ───────────────────────────
    {
      id: "qa.what_is",
      intent: "question_answering",
      pattern: /^what(?:'s| is) (?:a |an |the )?(.+?)(?:\?|$)/i,
      build: (m) => briefQuestion(m[1]),
      priority: 92,
      examples: [
        { input: "what is photosynthesis", output: "Photosynthesis? Briefly." },
        { input: "what's the capital of France?", output: "Capital of France? Briefly." }
      ],
      source: "seed"
    },
    {
      id: "qa.who_is",
      intent: "question_answering",
      pattern: /^who(?:'s| is) (?:a |an |the )?(.+?)(?:\?|$)/i,
      build: (m) => briefQuestion(m[1]),
      priority: 90,
      examples: [{ input: "who is Ada Lovelace?", output: "Ada Lovelace? Briefly." }],
      source: "seed"
    },
    {
      id: "qa.when_is",
      intent: "question_answering",
      pattern: /^when (?:is|was|are|were|did|does|do)\s+(.+?)(?:\?|$)/i,
      build: (m) => `When ${cleanTopic(m[1]).toLowerCase()}? Briefly.`,
      priority: 90,
      examples: [{ input: "when was the Declaration of Independence signed?", output: "When declaration of independence signed? Briefly." }],
      source: "seed"
    },
    // ── REWRITE / MAKE MORE (priority 88-92) ──────────────────────────────────
    {
      id: "rewrite.please_rewrite",
      intent: "rewriting_paraphrasing",
      pattern: /^(?:please )?rewrite\s+(?:this |the )?(.+?)\s+to\s+be\s+(.+?)(?:\s+while\s+preserving\s+(?:the\s+)?meaning)?(?:\.|\?|$)/i,
      build: (m) => `Rewrite ${cleanTopic(m[1]).toLowerCase()}: ${cleanTopic(m[2]).toLowerCase()}; preserve meaning.`,
      priority: 92,
      examples: [{ input: "please rewrite this paragraph to be clearer and more concise while preserving the meaning", output: "Rewrite paragraph: clearer and more concise; preserve meaning." }],
      source: "seed"
    },
    {
      id: "rewrite.make_more",
      intent: "rewriting_paraphrasing",
      pattern: /^make\s+(?:this |the )?(.+?)\s+more\s+(.+?)(?:\.|\?|$)/i,
      build: (m) => `Rewrite ${cleanTopic(m[1]).toLowerCase()}: more ${cleanTopic(m[2]).toLowerCase()}.`,
      priority: 90,
      examples: [{ input: "make this sentence more professional and concise", output: "Rewrite sentence: more professional and concise." }],
      source: "seed"
    },
    // ── BRAINSTORM (priority 88) ───────────────────────────────────────────────
    {
      id: "brainstorm.n_x_for_y",
      intent: "brainstorming",
      pattern: /^brainstorm\s+(\d+)\s+(.+?)\s+for\s+(?:a |an |the )?(.+?)(?:\.|\?|$)/i,
      build: (m) => `Brainstorm ${m[1]} ${cleanTopic(m[3]).toLowerCase()} ${cleanTopic(m[2]).toLowerCase()}.`,
      priority: 88,
      examples: [
        { input: "brainstorm 10 names for a coffee shop", output: "Brainstorm 10 coffee shop names." },
        { input: "brainstorm five names for a minimalist budgeting app", output: "Brainstorm five budgeting app names." }
      ],
      source: "seed"
    },
    // ── PERSONAL / SITUATION (priority 80-90) ─────────────────────────────────
    {
      id: "personal.accidentally",
      intent: "question_answering",
      pattern: /^I accidentally\s+(.+?)\s+(?:is there|any way|how can I)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Recover ${cleanTopic(m[1]).toLowerCase()}?`,
      priority: 90,
      examples: [{ input: "I accidentally deleted a file is there any way to recover it", output: "Recover deleted file?" }],
      source: "seed"
    },
    {
      id: "personal.keeps",
      intent: "question_answering",
      pattern: /^my (.+?) keeps?\s+(.+?)\s+what should I do(?:\?|$)/i,
      build: (m) => `Fix ${cleanTopic(m[1]).toLowerCase()} ${cleanTopic(m[2]).toLowerCase()}?`,
      priority: 88,
      examples: [{ input: "my phone keeps crashing what should I do", output: "Fix phone crashing?" }],
      source: "seed"
    },
    {
      id: "personal.recurring",
      intent: "question_answering",
      pattern: /^I have been having\s+(.+?)\s+(?:for|every day|all week)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Recurring ${cleanTopic(m[1]).toLowerCase()} ${cleanTopic(m[2]).toLowerCase()} \u2014 causes?`,
      priority: 86,
      examples: [{ input: "I have been having headaches every day for a week", output: "Recurring headaches week \u2014 causes?" }],
      source: "seed"
    },
    {
      id: "personal.hurts_when",
      intent: "question_answering",
      pattern: /^(?:my )?(.+?) hurts? when I\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())} pain when ${cleanTopic(m[2]).toLowerCase()} \u2014 cause?`,
      priority: 86,
      examples: [{ input: "my knee hurts when I run", output: "Knee pain when run \u2014 cause?" }],
      source: "seed"
    },
    {
      id: "personal.have_event_soon",
      intent: "question_answering",
      pattern: /^I have (?:an? )?(.+?)\s+(?:tomorrow|soon|next week)[,.]?\s+what should I\s+(.+?)(?:\?|$)/i,
      build: (m) => {
        const knowAbout = (m[2] ?? "").match(/^know\s+about\s+(.+)$/i);
        if (knowAbout) return `${sc(cleanTopic(knowAbout[1]).toLowerCase())}?`;
        return `${sc(cleanTopic(m[1]).toLowerCase())} prep?`;
      },
      priority: 86,
      examples: [
        { input: "I have an interview tomorrow, what should I do", output: "Interview prep?" },
        { input: "I have an interview tomorrow, what should I know about psychology basics", output: "Psychology basics?" }
      ],
      source: "seed"
    },
    {
      id: "personal.have_x_causes",
      intent: "question_answering",
      pattern: /^I have\s+(.+?)\s+what could it be(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())} \u2014 possible causes?`,
      priority: 84,
      examples: [{ input: "I have a persistent cough, what could it be", output: "Persistent cough \u2014 possible causes?" }],
      source: "seed"
    },
    {
      id: "personal.trying_to_is",
      intent: "question_answering",
      pattern: /^I am trying to\s+(.+?)\s+(?:is that|what is)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Is ${cleanTopic(m[1]).toLowerCase()} ${cleanTopic(m[2]).toLowerCase()}?`,
      priority: 84,
      examples: [{ input: "I am trying to lose 10 pounds in a month is that realistic", output: "Is lose 10 pounds in a month realistic?" }],
      source: "seed"
    },
    {
      id: "personal.is_refusing",
      intent: "question_answering",
      pattern: /^my (.+?) is (?:refusing to|not|broken|slow)\s+(.+?)\s+what are my\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(m[3].trim().replace(/\?$/, "").toLowerCase())} when ${cleanTopic(m[1]).toLowerCase()} ${cleanTopic(m[2]).toLowerCase()}?`,
      priority: 84,
      examples: [{ input: "my car is refusing to start what are my options", output: "Options when car refusing to start?" }],
      source: "seed"
    },
    // ── CHECKLIST / LIST PATTERNS (priority 160-175) ─────────────────────────
    // Must come BEFORE broad util rules (priority 60-75) to prevent fallback.
    {
      id: "util.travel_trip_checklist",
      intent: "general_instruction",
      // "I am travelling/going to X... wanted/want/need a checklist... [role]... [N days]"
      pattern: /(?:i(?:'m|'m|\s+am|'ll\s+be)?\s+)?(?:travelling|traveling|going|heading|flying|visiting|planning\s+(?:a\s+)?trip)\s+to\s+([\w][\w\s]{1,28}?)\b.{0,300}?\b(?:wanted|want|need|could\s+use|give\s+(?:me\s+)?(?:a\s+)?|looking\s+for\s+(?:a\s+)?)\s*(?:a\s+|the\s+|some\s+)?(?:travel\s+|trip\s+)?checklist/i,
      build: (m) => {
        const dest = titleCaseSubject(cleanTopic(m[1].trim()));
        const full = m[0];
        const durM = /for\s+(\d+)\s+(days?|weeks?|nights?)/i.exec(full);
        const dur = durM ? ` ${durM[1]}-${durM[2].replace(/s$/i, "")}` : "";
        let role = "";
        if (/f[\s-]?1\s*(?:visa)?(?:\s*student)?|f1\s*student/i.test(full)) role = " for F1 visa students";
        else if (/\bstudent/i.test(full)) role = " for students";
        else if (/\bbusiness\b/i.test(full)) role = " for business";
        else if (/\bfamily\b/i.test(full)) role = " for family";
        return `${dest}${dur} trip checklist${role}.`;
      },
      priority: 175,
      examples: [
        { input: "I am travelling to puerto rico with my friends and I wanted a checklist we are f1 visa students going for 5 days", output: "Puerto Rico 5-day trip checklist for F1 visa students." },
        { input: "I'm going to Japan for 10 days and need a checklist", output: "Japan 10-day trip checklist." },
        { input: "We are traveling to London for a business trip, give me a checklist", output: "London trip checklist for business." }
      ],
      source: "seed"
    },
    {
      id: "util.travel_checklist_dest_before_trip",
      intent: "general_instruction",
      // "I wanted/want/need a checklist for a [N-day] [DEST] trip [for role]"
      // Handles phrasing where checklist comes before the destination (no travel verb required)
      pattern: /\bchecklist\s+for\s+(?:a\s+)?(?:(\d+)[\s-](?:days?|nights?|weeks?)\s+)?([\w][\w\s]{1,28}?)\s+trip\b/i,
      build: (m) => {
        const full = m.input ?? m[0];
        const durRaw = m[1];
        const destRaw = m[2].trim().replace(/^(?:my|our|the|a|an)\s+/i, "");
        const dur = durRaw ? ` ${durRaw}-day` : (() => {
          const durM = /for\s+(\d+)\s+(days?|nights?|weeks?)/i.exec(full);
          return durM ? ` ${durM[1]}-${durM[2].replace(/s$/i, "")}` : "";
        })();
        const dest = titleCaseSubject(cleanTopic(destRaw));
        let role = "";
        if (/f[\s-]?1\s*(?:visa)?(?:\s*student)?|f1\s*student/i.test(full)) role = " for F1 visa students";
        else if (/\bstudent/i.test(full)) role = " for students";
        else if (/\bbusiness\b/i.test(full)) role = " for business";
        else if (/\bfamily\b/i.test(full)) role = " for family";
        else if (/\bfriend/i.test(full)) role = "";
        return `${dest}${dur} trip checklist${role}.`;
      },
      priority: 174,
      examples: [
        { input: "I wanted a checklist for a 5 day puerto rico trip for me and my friends, we are f1 visa students", output: "Puerto Rico 5-day trip checklist for F1 visa students." },
        { input: "I need a checklist for a Japan trip", output: "Japan trip checklist." },
        { input: "Can you give me a checklist for a 10-day Europe trip for family?", output: "Europe 10-day trip checklist for family." }
      ],
      source: "seed"
    },
    {
      id: "util.host_plan_event_checklist",
      intent: "general_instruction",
      // "[someone] [wants to] host/plan/throw/organize/have [a] [EVENT] [at/in/for/this/next] [...], give me a checklist"
      pattern: /(?:host|plan|throw|organize|have)\s+(?:a\s+)?(.+?)\s+(?:at|in|for|this|next|near)\b.{0,100}?,\s*give (?:me |a |the )?checklist/i,
      build: (m) => {
        const topic = cleanTopic(m[1]).replace(/^(?:his|her|my|your|their|our)\s+/i, "").replace(/^(?:a|an|the)\s+/i, "").trim();
        return `${titleCaseSubject(topic)} checklist.`;
      },
      priority: 168,
      examples: [
        { input: "my friend wants to host a house party at my place, give me a checklist of things", output: "House party checklist." },
        { input: "we're planning a barbecue for next weekend, give me a checklist", output: "Barbecue checklist." }
      ],
      source: "seed"
    },
    {
      id: "util.checklist_of_things_to",
      intent: "general_instruction",
      pattern: /give (?:me |a |the )?checklist of (?:things|items|stuff)\s+(?:to|for)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Checklist: ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 165,
      examples: [
        { input: "give me a checklist of things to do before a road trip", output: "Checklist: do before a road trip." },
        { input: "give me a checklist of things to buy for a camping trip", output: "Checklist: buy for a camping trip." }
      ],
      source: "seed"
    },
    {
      id: "util.checklist_for_x",
      intent: "general_instruction",
      pattern: /give (?:me |a |the )?checklist (?:of (?:things|items|stuff)\s+)?(?:for|to)\s+(.+?)(?:\?|$)/i,
      build: (m) => `Checklist: ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 163,
      examples: [
        { input: "give me a checklist for moving into a new apartment", output: "Checklist: moving into a new apartment." },
        { input: "give me a checklist to follow before a job interview", output: "Checklist: follow before a job interview." }
      ],
      source: "seed"
    },
    {
      id: "util.wanted_checklist_for",
      intent: "general_instruction",
      // "I wanted/want/need/could use a checklist for X" without a travel verb or "give me"
      pattern: /\b(?:wanted|want|need|could\s+use|looking\s+for)\s+(?:a\s+|an\s+)?(?:travel\s+|trip\s+|packing\s+)?checklist\s+(?:for|of|about|on)\s+(.+?)(?:\.|,|$)/i,
      build: (m) => {
        const full = m.input ?? m[0];
        const subject = cleanTopic(m[1].trim().replace(/^(?:my|our|the|a|an)\s+/i, "").replace(/\s+(?:and|for|with)\s+.+$/i, ""));
        let role = "";
        if (/f[\s-]?1\s*(?:visa)?(?:\s*student)?|f1\s*student/i.test(full)) role = " for F1 visa students";
        else if (/\bstudent/i.test(full)) role = " for students";
        else if (/\bbusiness\b/i.test(full)) role = " for business";
        else if (/\bfamily\b/i.test(full)) role = " for family";
        return `Checklist: ${titleCaseSubject(subject)}${role}.`;
      },
      priority: 161,
      examples: [
        { input: "I wanted a checklist for my camping gear", output: "Checklist: Camping gear." },
        { input: "I need a checklist for my job interview", output: "Checklist: Job interview." }
      ],
      source: "seed"
    },
    {
      id: "util.checklist_generic",
      intent: "general_instruction",
      // Fallback: extracts event context from text before "give me a checklist"
      pattern: /give (?:me |a |the )?checklist(?:\s+of (?:things|items|stuff))?(?:\?|$)/i,
      build: (m) => {
        const full = m.input ?? m[0];
        const idx = full.toLowerCase().indexOf("give me");
        if (idx > 10) {
          const ctx = full.slice(0, idx).replace(/[,;.]+$/, "").trim();
          const ev = /(?:host|plan|throw|organize|have)\s+(?:a\s+)?(.+?)(?:\s+at|\s+in|\s+for|\s+this|\s+next|$)/i.exec(ctx);
          if (ev) return `${titleCaseSubject(cleanTopic(ev[1]))} checklist.`;
        }
        return "Checklist.";
      },
      priority: 160,
      examples: [
        { input: "my friend wants to host a house party at my place, give me a checklist of things", output: "House party checklist." }
      ],
      source: "seed"
    },
    // ── FITNESS / WORKOUT (priority 165-170) ─────────────────────────────────
    // Entity model: [muscles] [duration] workout.
    // Principle: strip "at the gym", "its X day" framing, social preamble —
    // keep only muscles, duration, and the task noun.
    {
      id: "util.workout_its_day_duration",
      intent: "general_instruction",
      // "its back and biceps day, give me a 45 min workout"
      // "its leg day. I need a 20-minute workout"
      pattern: /\b(?:it'?s?\s+)?(?:today\s+is\s+)?(?:it'?s?\s+)?([\w]+(?:\s+(?:and|&)\s+[\w]+)?)\s+day\b.{0,120}?(\d+)[\s-]?(?:min(?:ute)?s?|hr|hour)\s+(?:workout|routine|session|training|lift|program)/i,
      build: (m) => {
        const muscles = titleCaseSubject(m[1].trim().replace(/\s+and\s+/gi, " & "));
        return `${muscles} ${m[2]}-min workout.`;
      },
      priority: 170,
      examples: [
        { input: "im at the gym rn and its back and biceps day, give me a 45 min workout", output: "Back & Biceps 45-min workout." },
        { input: "its leg day, I need a 20-minute workout", output: "Leg 20-min workout." },
        { input: "its chest day. give me a 30 min routine", output: "Chest 30-min workout." }
      ],
      source: "seed"
    },
    {
      id: "util.workout_give_duration_muscles",
      intent: "general_instruction",
      // "give me a 45 min back and biceps workout"
      // "give me a 30-min chest routine"
      pattern: /(?:give\s+me|get\s+me|need|want)\s+(?:a\s+)?(\d+)[\s-]?(?:min(?:ute)?s?|hr|hour)\s+([\w]+(?:\s+(?:and|&)\s+[\w]+)?)\s+(?:workout|routine|session|training|program)/i,
      build: (m) => {
        const muscles = titleCaseSubject(m[2].trim().replace(/\s+and\s+/gi, " & "));
        return `${muscles} ${m[1]}-min workout.`;
      },
      priority: 169,
      examples: [
        { input: "give me a 45 min back and biceps workout", output: "Back & Biceps 45-min workout." },
        { input: "need a 30-min chest routine", output: "Chest 30-min workout." }
      ],
      source: "seed"
    },
    {
      id: "util.workout_muscles_then_duration",
      intent: "general_instruction",
      // "back and biceps workout, 45 minutes" or "give me back and biceps, 45 min workout"
      pattern: /\b([\w]+(?:\s+(?:and|&)\s+[\w]+)?)\s+(?:workout|routine|session|training)\b.{0,40}?(\d+)[\s-]?(?:min(?:ute)?s?|hr|hour)/i,
      build: (m) => {
        const muscles = titleCaseSubject(m[1].trim().replace(/\s+and\s+/gi, " & "));
        return `${muscles} ${m[2]}-min workout.`;
      },
      priority: 167,
      examples: [
        { input: "back and biceps workout for 45 minutes", output: "Back & Biceps 45-min workout." },
        { input: "shoulder routine, 30 min", output: "Shoulder 30-min workout." }
      ],
      source: "seed"
    },
    {
      id: "util.workout_no_duration",
      intent: "general_instruction",
      // "give me a chest workout" or "its leg day, give me a workout"
      pattern: /\b(?:it'?s?\s+)?([\w]+(?:\s+(?:and|&)\s+[\w]+)?)\s+day\b.{0,80}?(?:give\s+me|get\s+me|need|want)\s+(?:a\s+)?(?:workout|routine|session|training|program)/i,
      build: (m) => {
        const muscles = titleCaseSubject(m[1].trim().replace(/\s+and\s+/gi, " & "));
        return `${muscles} workout.`;
      },
      priority: 165,
      examples: [
        { input: "its push day, give me a workout", output: "Push workout." },
        { input: "its arm day, I need a routine", output: "Arm workout." }
      ],
      source: "seed"
    },
    {
      id: "util.give_me_list_of",
      intent: "general_instruction",
      pattern: /^give me (?:a |the )?list of\s+(.+?)(?:\?|$)/i,
      build: (m) => `List: ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 72,
      examples: [
        { input: "give me a list of things to do in New York", output: "List: things to do in New York." },
        { input: "give me a list of Python libraries for data science", output: "List: Python libraries for data science." }
      ],
      source: "seed"
    },
    {
      id: "util.give_me_x_for_y",
      intent: "general_instruction",
      pattern: /^give me (?:some |a few )?(.+?)\s+(?:for|to)\s+(.+?)(?:\?|$)/i,
      build: (m) => `${sc(cleanTopic(m[1]).toLowerCase())} for ${cleanTopic(m[2]).toLowerCase()}.`,
      priority: 70,
      examples: [
        { input: "give me some tips for better sleep", output: "Tips for better sleep." },
        { input: "give me ideas to decorate my room", output: "Ideas to decorate my room." }
      ],
      source: "seed"
    },
    // ── EDGE-CASE GENERALIZATIONS (dataset: multi-topic / role / readiness / compare) ──
    {
      id: "qa.explain_two_topics_connect_real_life",
      intent: "question_answering",
      pattern: /^explain\s+(.+?)\s+and\s+also\s+how\s+it\s+connects\s+to\s+(.+?)\s+in\s+real\s+life\.?$/i,
      build: (m) => `${cleanTopic(m[1]).toLowerCase()} + ${cleanTopic(m[2]).toLowerCase()} relationship overview.`,
      priority: 118,
      examples: [
        {
          input: "Explain system design and also how it connects to climate change in real life.",
          output: "system design + climate change relationship overview."
        }
      ],
      source: "learned"
    },
    {
      id: "qa.introduce_person_to_topic_beginner",
      intent: "question_answering",
      pattern: /^i have (?:a |an )?(.+?),?\s+what are good ways to introduce them to (.+?)\??\.?$/i,
      build: (m) => {
        const rawTopic = (m[2] ?? "").replace(/\s+without\s+overwhelming\s+them\s*/i, "").replace(/\s+with\s+examples?\s+if\s+possible\s*/i, "").replace(/\s+with\s+examples?\s*/i, "").replace(/[?!]+$/, "").trim();
        return `${cleanTopic(rawTopic).toLowerCase()} for ${cleanTopic(m[1]).toLowerCase()}, beginner-friendly.`;
      },
      priority: 117,
      examples: [
        {
          input: "I have a college freshman, what are good ways to introduce them to TypeScript architecture without overwhelming them?",
          output: "typescript architecture for college freshman, beginner-friendly."
        },
        {
          input: "I have a teenager, what are good ways to introduce them to AI research with examples if possible?",
          output: "ai research for teenager, beginner-friendly."
        }
      ],
      source: "learned"
    },
    {
      id: "qa.studying_at_school_topic_especially",
      intent: "question_answering",
      pattern: /^i'?m studying at (.+?) and want to know more about (?:the school'?s\s+)?(.+?),?\s+especially\s+(.+?)\.?$/i,
      build: (m) => `${m[1].trim()} ${cleanTopic(m[2]).toLowerCase()} ${cleanTopic(m[3]).toLowerCase()}.`,
      priority: 116,
      examples: [
        {
          input: "I'm studying at MIT and want to know more about the school's quantum computing, especially research opportunities.",
          output: "MIT quantum computing research opportunities."
        }
      ],
      source: "learned"
    },
    {
      id: "qa.ready_for_topic_then_process",
      intent: "question_answering",
      pattern: /^how do i know if i'?m ready for (.+?),?\s+and what'?s the process after that\??$/i,
      build: (m) => `${cleanTopic(m[1]).toLowerCase()} readiness + process.`,
      priority: 169,
      examples: [
        {
          input: "How do I know if I'm ready for ETF investing, and what's the process after that?",
          output: "etf investing readiness + process."
        }
      ],
      source: "learned"
    },
    {
      id: "qa.compare_where_each_useful",
      intent: "analysis",
      pattern: /^can you compare (.+?) with (.+?) and explain where each is useful\??$/i,
      build: (m) => `${cleanTopic(m[1]).toLowerCase()} vs ${cleanTopic(m[2]).toLowerCase()}: use cases.`,
      priority: 170,
      examples: [
        {
          input: "Can you compare distributed systems with quantum computing and explain where each is useful?",
          output: "distributed systems vs quantum computing: use cases."
        }
      ],
      source: "learned"
    },
    {
      id: "qa.tech_stack_plus_topic_best_practices",
      intent: "question_answering",
      pattern: /^i'?m using (.+?) and dealing with (.+?), how should i structure this properly\??$/i,
      build: (m) => `${m[1].trim()} ${cleanTopic(m[2]).toLowerCase()} best practices.`,
      priority: 169,
      examples: [
        {
          input: "I'm using Vue 3 + TypeScript and dealing with bedtime routines, how should I structure this properly?",
          output: "Vue 3 + TypeScript bedtime routines best practices."
        }
      ],
      source: "learned"
    },
    {
      id: "qa.when_start_timing_next_steps",
      intent: "question_answering",
      pattern: /^when should i start\s+(.+?),?\s+and what usually happens next\??$/i,
      build: (m) => `${cleanTopic(m[1]).toLowerCase()} timing + next steps.`,
      priority: 169,
      examples: [
        {
          input: "When should I start photosynthesis, and what usually happens next?",
          output: "photosynthesis timing + next steps."
        }
      ],
      source: "learned"
    },
    {
      id: "qa.my_role_struggles_easy_help",
      intent: "question_answering",
      pattern: /^my\s+(.+?)\s+struggles\s+with\s+(.+?),?\s+what are some easy ways to help\??$/i,
      build: (m) => `Help ${cleanTopic(m[1]).toLowerCase()} with ${cleanTopic(m[2]).toLowerCase()}.`,
      priority: 169,
      examples: [
        {
          input: "My teenager struggles with climate change, what are some easy ways to help?",
          output: "Help teenager with climate change."
        }
      ],
      source: "learned"
    },
    {
      id: "qa.accepted_into_department_strength",
      intent: "question_answering",
      pattern: /^i just got accepted into\s+(.+?),?\s+how strong is their\s+(.+?)\s+department compared to others\??$/i,
      build: (m) => `${compactFactualSubject(m[1])} ${cleanTopic(m[2]).toLowerCase()} department comparison.`,
      priority: 169,
      examples: [
        {
          input: "I just got accepted into Harvard, how strong is their system design department compared to others?",
          output: "Harvard system design department comparison."
        }
      ],
      source: "learned"
    },
    {
      id: "util.formal_not_robotic_message",
      intent: "general_instruction",
      pattern: /^can you make something formal but not robotic for\s+(.+?)\??$/i,
      build: (m) => `Formal natural message: ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 169,
      examples: [
        {
          input: "Can you make something formal but not robotic for bedtime routines?",
          output: "Formal natural message: bedtime routines."
        }
      ],
      source: "learned"
    },
    {
      id: "code.in_stack_clean_performance_handle",
      intent: "code_debugging",
      pattern: /^in\s+(.+?),?\s+what'?s the cleanest way to handle\s+(.+?) without causing performance issues\??$/i,
      build: (m) => `${m[1].trim()} performant ${cleanTopic(m[2]).toLowerCase()} handling.`,
      priority: 108,
      examples: [
        {
          input: "In FastAPI + PostgreSQL, what's the cleanest way to handle climate change without causing performance issues?",
          output: "FastAPI + PostgreSQL performant climate change handling."
        }
      ],
      source: "learned"
    },
    // ── HYPOTHETICAL (priority 80) ─────────────────────────────────────────────
    {
      id: "qa.if_you_could",
      intent: "question_answering",
      pattern: /^if you could\b(.+)/i,
      build: (m) => `If you could${m[1].trim().replace(/,\s*and why\??$/, "? Explain reasoning.")}`,
      priority: 80,
      examples: [{ input: "if you could live anywhere, where would it be and why?", output: "If you could live anywhere, where would it be? Explain reasoning." }],
      source: "seed"
    },
    // ── BROAD UTILITY (priority 60-75) ─────────────────────────────────────────
    {
      id: "util.give_me_n",
      intent: "general_instruction",
      pattern: /^give me (\d+)\s+(.+?)(?:\?|$)/i,
      build: (m) => `${m[1]} ${cleanTopic(m[2]).toLowerCase()}.`,
      priority: 75,
      examples: [{ input: "give me 5 tips to sleep better", output: "5 tips to sleep better." }],
      source: "seed"
    },
    {
      id: "util.tell_me_about",
      intent: "question_answering",
      pattern: /^tell me (?:more )?(?:about|regarding)\s+(.+?)(?:\?|$)/i,
      build: (m) => `${compactTopic(m[1])} overview`,
      priority: 73,
      examples: [{ input: "tell me more about black holes", output: "Black holes overview" }],
      source: "seed"
    },
    {
      id: "util.explain",
      intent: "question_answering",
      pattern: /^explain (?:to me |for me )?(?:the )?(?:difference between )?(.+?)(?:\?|$)/i,
      build: (m) => `Explain ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 70,
      examples: [{ input: "explain machine learning to me", output: "Explain machine learning." }],
      source: "seed"
    },
    {
      id: "util.write_create",
      intent: "general_instruction",
      pattern: /^(?:write|create|generate|produce) (?:me )?(?:a |an )?(.+)/i,
      build: (m) => `Write ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 68,
      examples: [{ input: "write me a grocery list", output: "Write grocery list." }],
      source: "seed"
    },
    {
      id: "util.draft_compose",
      intent: "general_instruction",
      pattern: /^(?:can you )?(?:write|draft|compose|craft) (?:a |an |me a )?(.+)/i,
      build: (m) => `Draft ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 66,
      examples: [{ input: "can you draft a resignation letter", output: "Draft resignation letter." }],
      source: "seed"
    },
    {
      id: "util.can_you_create",
      intent: "general_instruction",
      pattern: /^can you (?:create|build|generate|produce) (?:a |an )?(.+)/i,
      build: (m) => `Write ${cleanTopic(m[1]).toLowerCase()}.`,
      priority: 64,
      examples: [{ input: "can you create a weekly workout plan", output: "Write weekly workout plan." }],
      source: "seed"
    }
  ];
  var ELITE_PRIORITY = 300;
  function cleanOutput(raw) {
    return raw.replace(/\?\.$/, "?").replace(/\.\.$/, ".").replace(/\s{2,}/g, " ").trim();
  }
  var BLOCKED_RULES_BY_INTENT = {
    email_drafting: /* @__PURE__ */ new Set(["util.write_create", "util.draft_compose", "util.can_you_create"])
  };
  function applyRule(prompt, intentName) {
    const p = prompt.trim();
    const blocked = intentName ? BLOCKED_RULES_BY_INTENT[intentName] : void 0;
    const eliteHits = [];
    for (const rule of COMPRESSION_RULES) {
      if (rule.priority !== ELITE_PRIORITY) continue;
      const execResult = rule.pattern.exec(p);
      if (execResult?.index !== void 0) {
        const m = p.match(rule.pattern) ?? execResult;
        const raw = cleanOutput(rule.build(m));
        if (raw) eliteHits.push({ index: execResult.index, output: raw, ruleId: rule.id });
      }
    }
    if (eliteHits.length > 0) {
      eliteHits.sort((a, b) => a.index - b.index);
      const seen = /* @__PURE__ */ new Set();
      const unique = eliteHits.filter(({ output }) => {
        const key = output.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      const combinedRuleId = unique.map((h) => h.ruleId).join("+");
      if (unique.length === 1) return { text: unique[0].output, ruleId: unique[0].ruleId };
      const combined = unique.map((h) => h.output.replace(/[.]+$/, "")).join("; ") + ".";
      return { text: combined, ruleId: combinedRuleId };
    }
    const candidates = COMPRESSION_RULES.filter(
      (rule) => rule.priority !== ELITE_PRIORITY && rule.pattern.test(p)
    );
    if (!candidates.length) return null;
    candidates.sort(
      (a, b) => b.priority - a.priority || b.pattern.source.length - a.pattern.source.length
    );
    for (const rule of candidates) {
      if (blocked?.has(rule.id)) continue;
      const m = p.match(rule.pattern) ?? (p + "?").match(rule.pattern);
      if (!m) continue;
      const raw = cleanOutput(rule.build(m));
      if (!raw) continue;
      return { text: raw, ruleId: rule.id };
    }
    return null;
  }

  // src/lib/compression/semanticFrame.ts
  var TECH_TERMS = [
    // Frameworks / libraries (longer matches first)
    ["Next.js", "Next.js"],
    ["NestJS", "NestJS"],
    ["Nuxt.js", "Nuxt.js"],
    ["FastAPI", "FastAPI"],
    ["Node.js", "Node.js"],
    ["scikit-learn", "scikit-learn"],
    ["scikit", "scikit-learn"],
    ["TensorFlow", "TensorFlow"],
    ["PyTorch", "PyTorch"],
    ["Tailwind", "Tailwind"],
    ["Bootstrap", "Bootstrap"],
    ["Material UI", "Material UI"],
    ["Chakra", "Chakra UI"],
    ["Zustand", "Zustand"],
    ["Redux", "Redux"],
    ["Recoil", "Recoil"],
    ["Express", "Express"],
    ["Django", "Django"],
    ["Laravel", "Laravel"],
    ["Spring", "Spring"],
    ["Rails", "Rails"],
    ["Flask", "Flask"],
    ["Remix", "Remix"],
    ["Svelte", "Svelte"],
    ["Angular", "Angular"],
    ["React", "React"],
    ["Vue", "Vue"],
    ["Fastify", "Fastify"],
    ["Prisma", "Prisma"],
    ["Sequelize", "Sequelize"],
    ["TypeORM", "TypeORM"],
    ["pandas", "pandas"],
    ["NumPy", "NumPy"],
    ["Matplotlib", "Matplotlib"],
    ["Jupyter", "Jupyter"],
    ["Keras", "Keras"],
    ["Webpack", "Webpack"],
    ["Vite", "Vite"],
    ["ESLint", "ESLint"],
    ["Vitest", "Vitest"],
    ["Cypress", "Cypress"],
    ["Jest", "Jest"],
    // Languages
    ["TypeScript", "TypeScript"],
    ["JavaScript", "JavaScript"],
    ["Python", "Python"],
    ["Kotlin", "Kotlin"],
    ["Swift", "Swift"],
    ["Golang", "Go"],
    ["Ruby", "Ruby"],
    ["PHP", "PHP"],
    ["Rust", "Rust"],
    ["Bash", "Bash"],
    ["Shell", "Shell"],
    ["SASS", "Sass"],
    ["LESS", "Less"],
    ["HTML", "HTML"],
    ["CSS", "CSS"],
    ["SQL", "SQL"],
    ["Java", "Java"],
    ["Go", "Go"],
    ["C++", "C++"],
    // Databases
    ["PostgreSQL", "PostgreSQL"],
    ["MongoDB", "MongoDB"],
    ["DynamoDB", "DynamoDB"],
    ["Firebase", "Firebase"],
    ["Supabase", "Supabase"],
    ["SQLite", "SQLite"],
    ["MySQL", "MySQL"],
    ["Redis", "Redis"],
    // AWS services
    ["Lambda", "Lambda"],
    ["DynamoDB", "DynamoDB"],
    ["S3", "S3"],
    ["EC2", "EC2"],
    ["ECS", "ECS"],
    ["RDS", "RDS"],
    ["CloudFormation", "CloudFormation"],
    ["CloudFront", "CloudFront"],
    // CI/CD & version control
    ["GitHub Actions", "GitHub Actions"],
    ["CircleCI", "CircleCI"],
    ["GitHub", "GitHub"],
    ["GitLab", "GitLab"],
    // Data tools
    ["DataLoader", "DataLoader"],
    ["Elasticsearch", "Elasticsearch"],
    ["Kafka", "Kafka"],
    ["RabbitMQ", "RabbitMQ"],
    // Platforms / infra
    ["Kubernetes", "Kubernetes"],
    ["Terraform", "Terraform"],
    ["Docker", "Docker"],
    ["Vercel", "Vercel"],
    ["Netlify", "Netlify"],
    ["Railway", "Railway"],
    ["Heroku", "Heroku"],
    ["Render", "Render"],
    ["AWS", "AWS"],
    ["GCP", "GCP"],
    ["Azure", "Azure"],
    // Protocols / paradigms
    ["GraphQL", "GraphQL"],
    ["REST", "REST"],
    ["gRPC", "gRPC"],
    ["OAuth", "OAuth"],
    ["JWT", "JWT"],
    // Package managers
    ["npm", "npm"],
    ["yarn", "yarn"],
    ["pnpm", "pnpm"],
    ["pip", "pip"],
    ["conda", "conda"]
  ];
  var TECH_RE = new RegExp(
    TECH_TERMS.map(([raw]) => raw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|"),
    "gi"
  );
  function extractTechStack(text) {
    const seen = /* @__PURE__ */ new Set();
    const found = [];
    let m;
    TECH_RE.lastIndex = 0;
    while ((m = TECH_RE.exec(text)) !== null) {
      const raw = m[0];
      const canonical = TECH_TERMS.find(([t]) => t.toLowerCase() === raw.toLowerCase())?.[1] ?? raw;
      if (seen.has(canonical)) continue;
      seen.add(canonical);
      const afterRaw = text.slice(m.index + raw.length);
      const verMatch = afterRaw.match(/^\s+(\d+(?:\.\d+)*)/);
      found.push(verMatch ? `${canonical} ${verMatch[1]}` : canonical);
    }
    return found;
  }
  var ROLE_RE = /^(?:I(?:'m|\s+am)|As\s+a)\s+an?\s+([\w][\w\s\-]{0,35}?)(?=\s*[,;]|\s+(?:and|trying|looking|going|who|that|currently|with|at|from|in|I|—)|\s*$)/i;
  var GOING_THROUGH_RE = /^going through (?:a )?([\w][\w\s]{2,50}?)(?:\s*[,;]|\s+and\s+|\s+who\s+|\s+that\s+)/i;
  var VISA_RE = /\bI(?:'m|\s+am)\s+on\s+an?\s+(F\d|J\d|OPT|H-?1B?|L[12]|O-?1|TN)\s*(?:visa|student)?\b/i;
  var HAVE_AGE_RE = /\bI\s+have\s+an?\s+(\d+)[- ]year[- ]old\b/i;
  var AUDIENCE_FOR_RE = /\bfor\s+(?:my\s+)?(\d+[- ]year[- ]old|child|kid|toddler|beginner|elderly person|senior)\b/i;
  var ROLE_EXCLUSIONS = /* @__PURE__ */ new Set([
    "asking",
    "using",
    "trying",
    "here",
    "writing",
    "working",
    "looking",
    "currently",
    "not",
    "just",
    "also"
  ]);
  function extractRoleAndAudience(text) {
    let stripped = text;
    let role = null;
    let audience = null;
    const visaM = VISA_RE.exec(text);
    if (visaM) {
      role = `${visaM[1]} visa holder`;
      stripped = text.slice(0, visaM.index) + text.slice(visaM.index + visaM[0].length);
      return { role, audience, stripped: stripped.replace(/^[\s,;]+/, "").trim() };
    }
    const ageM = HAVE_AGE_RE.exec(text);
    if (ageM) {
      audience = `${ageM[1]}-year-old`;
      stripped = (text.slice(0, ageM.index) + text.slice(ageM.index + ageM[0].length)).replace(/^[\s,;]+/, "").trim();
      return { role, audience, stripped };
    }
    const audForM = AUDIENCE_FOR_RE.exec(text);
    if (audForM) {
      audience = audForM[1];
    }
    const roleM = ROLE_RE.exec(text);
    if (roleM) {
      const raw = roleM[1].trim().toLowerCase();
      const firstWord = raw.split(/\s+/)[0];
      if (!ROLE_EXCLUSIONS.has(firstWord)) {
        role = raw;
        stripped = text.slice(roleM[0].length).replace(/^[\s,;]+/, "").trim();
      }
    }
    if (role) {
      const goingM = GOING_THROUGH_RE.exec(stripped);
      if (goingM) {
        role = `${role}; ${goingM[1].trim()}`;
        stripped = stripped.slice(goingM[0].length).replace(/^[\s,;]+/, "").trim();
      }
    }
    return { role, audience, stripped };
  }
  var USING_RE = /^(?:I(?:'m|\s+am)\s+)?using\s+([\w][\w\s.,+\-/]{2,80}?)\s*[,;]\s*/i;
  var SUBTASK_SPLIT_RE = /\s+(?:and\s+also|also)\s+|\s+and\s+how\s+(?:to\s+|do\s+|does\s+|should\s+)?|\s*[,;]\s+and\s+(?=\w)|\s*\?\s*[Aa]nd\s+/;
  var FORMAT_RE = [
    ["roadmap", /\bro(?:ad)?map\b/i],
    ["guide", /\b(?:step[- ]by[- ]step\s+)?guide\b/i],
    ["email", /\bemail\b|\bletter\b/i],
    ["JSON", /\bjson\b/i],
    ["list", /\bbullet\s+points?\b|\bnumbered\s+list\b|\blist\b/i],
    ["summary", /\bsummar(?:y|ize)\b/i],
    ["explanation", /\bexplain\b|\bexplanation\b/i],
    ["comparison", /\bcompar(?:e|ison)\b|\bdifference\b/i],
    ["tutorial", /\btutorial\b|\bhow[- ]to\b/i],
    ["recommendation", /\brecommend(?:ation)?\b|\bsuggestion\b/i]
  ];
  var TONE_RE = [
    ["formal", /\bformal\b/i],
    ["professional", /\bprofessional\b/i],
    ["simple", /\bsimple\s+(?:terms?|words?|language)\b|\bbeginner[- ]friendly\b|\beasy\s+to\s+understand\b/i],
    ["concise", /\bnot\s+too\s+long\b|\bbrief\b|\bconcise\b|\bshort\b/i],
    ["casual", /\bcasual\b|\binformal\b/i],
    ["polite", /\bpolite\b/i],
    ["detailed", /\bdetailed?\b|\bin[- ]depth\b|\bthorough\b/i]
  ];
  var EMAIL_AUDIENCE_RE = /\b(?:email|letter)\s+(?:to|for)\s+(?:my\s+)?(professor|advisor|boss|manager|recruiter|team|client|professor|teacher|hr|landlord)\b/i;
  var EMAIL_TO_RE = /\bto\s+(?:my\s+)?(professor|advisor|boss|manager|recruiter|teacher|hr|landlord|[\w]+)\b/i;
  var JSON_FIELDS_RE = /\bjson\s+(?:only\s+)?(?:with\s+)?fields?\s+([\w,\s]+?)(?:[.?!]|$)/i;
  function stripLeadingFillerFromTask(task) {
    return task.replace(/^(?:can|could|would|should)\s+you\s+(?:please\s+)?/i, "").replace(/^please\s+/i, "").replace(/^(?:how\s+do(?:es)?\s+(?:I|one)\s+|how\s+should\s+I\s+)/i, "").replace(/^(?:what(?:'s|\s+is)\s+the\s+best\s+way\s+to\s+)/i, "").replace(/^(?:help\s+me\s+(?:understand\s+)?|help\s+me\s+)/i, "").replace(/^(?:I\s+(?:want|need)\s+to\s+(?:know\s+)?(?:how\s+to\s+|about\s+)?)/i, "").replace(/^(?:tell\s+me\s+(?:more\s+)?(?:about\s+)?)/i, "").replace(/^(?:give\s+me\s+(?:a[n]?\s+)?)/i, "").replace(/\b(?:please|kindly|pls)\b/gi, "").replace(/[?.!]+$/, "").replace(/\s{2,}/g, " ").trim();
  }
  function taskToNounPhrase(task) {
    if (/^[A-Z]/.test(task) && !/^(How|What|Why|When|Where|Can|Could|Would|Should|Do|Does|Is|Are)\b/.test(task)) {
      return task;
    }
    const cleaned = stripLeadingFillerFromTask(task);
    const verbMatch = cleaned.match(/^(handle|manage|fix|debug|resolve|understand|implement|create|build|set\s+up|configure|use|work\s+with)\s+(.+)/i);
    if (verbMatch) {
      const obj = verbMatch[2].trim();
      const verb = verbMatch[1].toLowerCase().replace(/\s+/g, "_");
      const actionSuffix = {
        handle: "handling",
        manage: "management",
        fix: "fix",
        debug: "debugging",
        resolve: "resolution",
        understand: "understanding",
        implement: "implementation",
        create: "creation",
        build: "setup",
        set_up: "setup",
        configure: "config",
        use: "usage",
        work_with: "usage"
      };
      const suffix = actionSuffix[verb] ?? `${verb.replace("_", " ")}`;
      const objNorm = obj.replace(/s\b/, "").trim();
      return `${objNorm} ${suffix}`;
    }
    return cleaned;
  }
  function extractSemanticFrame(prompt) {
    const text = prompt.trim().replace(/\s+/g, " ");
    const { role, audience, stripped: strippedForRole } = extractRoleAndAudience(text);
    const techStack = extractTechStack(text);
    let outputFormat = null;
    for (const [fmt, re] of FORMAT_RE) {
      if (re.test(text)) {
        outputFormat = fmt;
        break;
      }
    }
    let tone = null;
    const toneList = [];
    for (const [t, re] of TONE_RE) {
      if (re.test(text)) toneList.push(t);
    }
    if (toneList.length) tone = toneList[0];
    const constraints = [...toneList];
    const jsonFieldsM = JSON_FIELDS_RE.exec(text);
    if (jsonFieldsM) constraints.push(`fields: ${jsonFieldsM[1].trim()}`);
    let subTasks = [];
    const splitParts = text.split(SUBTASK_SPLIT_RE).map((p) => p.trim()).filter((p) => p.length > 10);
    if (splitParts.length >= 2) subTasks = splitParts;
    const comparisonTargets = [];
    const diffRe = /\bdifference\s+between\s+([\w][\w\s\-/]{1,40}?)\s+(?:and|vs?\.?)\s+([\w][\w\s\-/]{1,40}?)(?:[,?.!]|$)/i;
    const cmpRe = /\bcompare\s+([\w][\w\s\-/]{1,40}?)\s+(?:and|vs?\.?|with)\s+([\w][\w\s\-/]{1,40}?)(?:[,?.!]|$)/i;
    const diffM = diffRe.exec(text);
    const cmpM = !diffM ? cmpRe.exec(text) : null;
    if (diffM) comparisonTargets.push(diffM[1].trim(), diffM[2].trim());
    else if (cmpM) comparisonTargets.push(cmpM[1].trim(), cmpM[2].trim());
    let emailAudience = null;
    if (outputFormat === "email") {
      const audM = EMAIL_AUDIENCE_RE.exec(text) ?? EMAIL_TO_RE.exec(strippedForRole);
      if (audM) emailAudience = audM[1].toLowerCase();
    }
    let task = strippedForRole.length < text.length ? strippedForRole : text;
    const usingM = USING_RE.exec(task);
    if (usingM) task = task.slice(usingM[0].length).trim();
    task = stripLeadingFillerFromTask(task) || null;
    const techLower = new Set(techStack.map((t) => t.split(" ")[0].toLowerCase()));
    const entities = [];
    for (const m of text.matchAll(/\b[A-Z][a-z]{1,}(?:\s+[A-Z][a-z]+)*\b/g) ?? []) {
      const w = m[0];
      if (!techLower.has(w.toLowerCase())) entities.push(w);
    }
    return {
      task: task || null,
      topic: null,
      role,
      audience: audience ?? emailAudience,
      constraints,
      entities: [...new Set(entities)].slice(0, 6),
      techStack,
      outputFormat,
      tone,
      comparisonTargets,
      subTasks,
      embeddedContext: null
    };
  }
  function mergeSharedSuffix(entities) {
    if (entities.length < 2) return null;
    const wordLists = entities.map((e) => e.toLowerCase().split(/\s+/));
    if (wordLists.some((w) => w.length < 2)) return null;
    const lastWords = wordLists.map((w) => w[w.length - 1]);
    if (new Set(lastWords).size !== 1) return null;
    const suffix = wordLists[0][wordLists[0].length - 1];
    const prefixes = entities.map((e) => e.split(/\s+/).slice(0, -1).join(" "));
    if (prefixes.some((p) => !p)) return null;
    return `${prefixes.join("/")} ${suffix}`;
  }
  function compressSubTask(clause) {
    const stripped = stripLeadingFillerFromTask(clause);
    const howRe = /^how\s+([\w]+(?:\s+[\w]+)?)\s+(\w+)\s+(.+)/i;
    const howM = howRe.exec(stripped);
    if (howM) {
      const subject = howM[1].replace(/s$/, "");
      const obj = howM[3].trim();
      const verb = howM[2].toLowerCase();
      const verbSuffix = {
        handle: "handling",
        survive: "survival",
        process: "processing",
        work: "workings",
        function: "function",
        affect: "effects"
      };
      const vs = verbSuffix[verb] ?? `${verb}ing`;
      return `${subject} ${obj} ${vs}`;
    }
    const whatRe = /^what(?:'s|\s+is)\s+the\s+([\w\s]+?)(?:\?|$)/i;
    const whatM = whatRe.exec(stripped);
    if (whatM) return `${whatM[1].trim()} overview`;
    return stripped;
  }
  function renderCompressedFrame(frame) {
    const { task, role, audience, constraints, techStack, outputFormat, tone, comparisonTargets, subTasks } = frame;
    if (subTasks.length >= 2) {
      const parts = subTasks.map((t) => {
        const subFrame = extractSemanticFrame(t);
        const rendered = renderCompressedFrame({ ...subFrame, subTasks: [] });
        return rendered ?? compressSubTask(t);
      });
      const joined = parts.slice(0, 3).join(" + ");
      if (role) return `${joined} (for ${role})`;
      if (audience) return `${joined} for ${audience}`;
      return joined;
    }
    if (comparisonTargets.length >= 2) {
      const merged = mergeSharedSuffix(comparisonTargets) ?? comparisonTargets.join("/");
      return `${merged} comparison`;
    }
    if (outputFormat === "email" || task && /\bemail\b|\bletter\b/i.test(task)) {
      const tonePart = tone === "formal" ? "Formal" : tone === "professional" ? "Professional" : "";
      const concisePart = constraints.includes("concise") ? " concise" : "";
      const audPart = (audience ?? "").trim();
      let subject = (task ?? "").replace(/\b(?:write|draft|compose|send|write up)\s+(?:a[n]?\s+)?(?:formal\s+|professional\s+|brief\s+|concise\s+)?(?:email|letter)\s+(?:to\s+(?:my\s+)?[\w]+\s+)?/i, "").replace(/\b(?:asking|requesting)\s+(?:for\s+|about\s+)?/i, "").replace(/[?.!]+$/, "").trim();
      if (!subject) subject = "request";
      const parts = [tonePart + concisePart, audPart, subject, "email"].map((p) => p.trim()).filter(Boolean);
      return parts.join(" ");
    }
    if (techStack.length > 0) {
      const stackStr = techStack.slice(0, 3).join(" + ");
      let taskStr = task ?? "";
      if (/^[Mm]y\s/i.test(taskStr)) {
        const howM = /how\s+(?:do|can|should|would)\s+(?:I|one)\s+([\w\s]{2,50}?)(?:\s*\?|$)/i.exec(taskStr);
        if (howM) {
          const action = howM[1].replace(/\s*\bit\b\s*/ig, "").trim();
          const preamble = taskStr.slice(0, howM.index);
          const compoundM = /\b(cold\s+start|memory\s+leak|N\+1|race\s+condition|ERESOLVE|cold\s+boot)\b/i.exec(preamble);
          const simpleM = !compoundM ? /\b(slow|broken|failing|hanging|leaking|crashing|stuck)\b/i.exec(preamble) : null;
          const nounM = /\b(queries?|function|request|response|pipeline|job|script|endpoint)\b/i.exec(preamble);
          const techKwM = /\b(joins?|indexes?|rows?|columns?)\b/i.exec(preamble);
          const problemKw = compoundM?.[1] ?? simpleM?.[1] ?? null;
          const subjectNoun = nounM?.[1]?.toLowerCase() ?? null;
          const techKw = techKwM?.[1]?.toLowerCase() ?? null;
          const parts = [];
          if (subjectNoun && subjectNoun !== action) parts.push(subjectNoun);
          if (problemKw) parts.push(problemKw);
          if (techKw && techKw !== subjectNoun) parts.push(techKw);
          parts.push(action);
          taskStr = parts.join(" ").trim();
        }
      }
      const coreTask = taskStr ? taskToNounPhrase(
        taskStr.replace(new RegExp(`\\b(${techStack.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})\\b`, "gi"), "").replace(/\s{2,}/g, " ").trim()
      ) : "";
      if (coreTask) return `${stackStr} ${coreTask}`;
      return stackStr;
    }
    if (role || audience) {
      const targetRole = role ?? audience;
      const isBeginnerRole = /\bbeginner\b/i.test(targetRole ?? "");
      const coreTask = task ? stripLeadingFillerFromTask(task) : null;
      const topicPart = coreTask ?? "";
      if (isBeginnerRole) {
        const fmt = outputFormat === "explanation" ? "explanation" : outputFormat === "tutorial" ? "tutorial" : outputFormat ?? "overview";
        return `Beginner-friendly ${topicPart} ${fmt}`.replace(/\s{2,}/g, " ").trim();
      }
      const fmtNoun = outputFormat === "roadmap" ? "roadmap" : outputFormat === "guide" ? "guide" : outputFormat === "summary" ? "summary" : outputFormat === "recommendation" ? "recommendations" : "";
      if (fmtNoun) {
        const topicOnly = topicPart.replace(/\b(?:give me|provide|make|create)\s+(?:a[n]?\s+)?(?:roadmap|guide|plan|summary)\b/i, "").replace(new RegExp(`\\b${fmtNoun}\\b`, "i"), "").trim();
        if (topicOnly) return `${sc(topicOnly)} ${fmtNoun} for ${targetRole}`;
        return `${sc(topicPart || fmtNoun)} for ${targetRole}`;
      }
      if (topicPart) return `${sc(topicPart)} for ${targetRole}`;
      return null;
    }
    if (tone && task) {
      const coreTask = stripLeadingFillerFromTask(task);
      const toneAdj = tone === "simple" ? "Simple" : tone === "formal" ? "Formal" : tone === "concise" ? "Concise" : tone === "detailed" ? "Detailed" : "";
      const hasBullets = constraints.some((c) => /bullet/i.test(c));
      const formatSuffix = hasBullets ? "bullet-point " : "";
      if (toneAdj) {
        const fmt = outputFormat === "explanation" ? "explanation" : outputFormat ?? "overview";
        return `${toneAdj} ${formatSuffix}${coreTask} ${fmt}`.replace(/\s{2,}/g, " ").trim();
      }
    }
    return null;
  }

  // src/lib/compression/semanticFallback.ts
  var ABORT_RE = /["'`{}[\]<>]|==|=>/;
  var AM_AT_RE = /^i(?:'m|\s+(?:am|'m|m))\s+(?:currently\s+)?(?:at|in|near|visiting|inside)\s+([\w][\w\s]{0,40}?)\s*,\s*/i;
  var AM_AT_PERIOD_RE = /^i(?:'m|\s+(?:am|'m|m))\s+(?:currently\s+)?(?:at|in|near|visiting|inside)\s+([\w][\w\s]{0,40}?)\s*\.\s+/i;
  var AM_ROLE_RE = /^i(?:'m|\s+(?:am|'m|m))\s+(?:a|an)\s+([\w][\w\s]{0,30}?)\s+(?:at|in|from)\s+([\w][\w\s]{0,30}?)\s*,\s*/i;
  var INTENT_PATTERNS = [
    // ── "how to" family ────────────────────────────────────────────────────────
    { re: /\bi\s+want\s+to\s+know\s+how\s+(?:i\s+)?should\s+go\s+about\s+([\w][\w\s]{0,60}?)(?:\s+(?:this|it|here)\b)?(?:[,.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bi\s+want\s+to\s+know\s+how\s+(?:one|you|someone)\s+(?:goes?|would\s+go)\s+about\s+([\w][\w\s]{0,60}?)(?:[,.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bi\s+(?:want|need)\s+to\s+know\s+how\s+to\s+([\w][\w\s]{0,60}?)(?:\s+(?:this|it|here)\b)?(?:[,.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bi\s+(?:would|'d)\s+like\s+to\s+know\s+how\s+to\s+([\w][\w\s]{0,60}?)(?:[,.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bi\s+was\s+wondering\s+how\s+to\s+([\w][\w\s]{0,60}?)(?:[,.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bi\s+(?:need|want)\s+(?:advice|help|guidance)\s+on\s+how\s+to\s+([\w][\w\s]{0,60}?)(?:[,.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bwhat(?:'s|\s+is)\s+the\s+best\s+way\s+to\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bwhat\s+are\s+some\s+(?:\w+\s+)?ways\s+to\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bhow\s+should\s+i\s+go\s+about\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bhow\s+do\s+i\s+go\s+about\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bhow\s+should\s+i\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bhow\s+(?:do|can|would|could)\s+i\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\btell\s+me\s+how\s+to\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bcould\s+you\s+(?:tell\s+me\s+)?how\s+to\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bexplain\s+how\s+to\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bany\s+(?:advice|tips|guidance)\s+(?:on|for|about)\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    { re: /\bwhat\s+can\s+i\s+(?:do|see|visit|explore)\s+(?:at|in|around|near)\s+([\w][\w\s]{0,60}?)(?:[,?.]|$)/i, mode: "how_to", g: 1 },
    // ── "explain" / overview family ────────────────────────────────────────────
    { re: /\bi\s+want\s+to\s+know\s+more\s+about\s+([\w][\w\s]{0,80}?)(?:[,?.]|$)/i, mode: "overview", g: 1 },
    { re: /\bi\s+want\s+to\s+(?:know|learn)\s+about\s+([\w][\w\s]{0,80}?)(?:[,?.]|$)/i, mode: "overview", g: 1 },
    { re: /\bi\s+want\s+to\s+(?:understand|learn\s+more\s+about)\s+([\w][\w\s]{0,80}?)(?:[,?.]|$)/i, mode: "overview", g: 1 },
    { re: /\bi\s+was\s+wondering\s+about\s+([\w][\w\s]{0,80}?)(?:[,?.]|$)/i, mode: "overview", g: 1 },
    { re: /\bi\s+(?:would|'d)\s+like\s+to\s+know\s+(?:more\s+)?about\s+([\w][\w\s]{0,80}?)(?:[,?.]|$)/i, mode: "overview", g: 1 },
    { re: /\btell\s+me\s+(?:more\s+)?about\s+([\w][\w\s]{0,80}?)(?:[,?.]|$)/i, mode: "overview", g: 1 },
    { re: /\bgive\s+me\s+(?:an?\s+)?overview\s+(?:of|on)\s+([\w][\w\s]{0,80}?)(?:[,?.]|$)/i, mode: "overview", g: 1 },
    { re: /\bwhat\s+should\s+i\s+know\s+about\s+([\w][\w\s]{0,80}?)(?:[,?.]|$)/i, mode: "overview", g: 1 },
    { re: /\bexplain\s+([\w][\w\s]{0,80}?)\s+to\s+me(?:[,?.]|$)/i, mode: "explain", g: 1 }
  ];
  var CATEGORY_NOUN_RE = /\b(?:this|the|that)\s+(?:university|college|school|campus|institution|company|firm|org(?:anization)?|startup|place|location|city|town|country|museum|park|building|library|hospital|area|site|restaurant|hotel|neighborhood|district)\b/gi;
  var PRONOUN_RE = /\bit\b(?!(?:'s|self|\s+(?:is|was|will|can|could|should|would|has|have|'s|'ll|'d)))/gi;
  var GERUND_TABLE = {
    // e-drop (most important — heuristic gets these wrong)
    exploring: "explore",
    creating: "create",
    making: "make",
    taking: "take",
    coming: "come",
    using: "use",
    writing: "write",
    coding: "code",
    improving: "improve",
    developing: "develop",
    managing: "manage",
    navigating: "navigate",
    operating: "operate",
    practicing: "practice",
    preparing: "prepare",
    producing: "produce",
    providing: "provide",
    reducing: "reduce",
    removing: "remove",
    resolving: "resolve",
    sharing: "share",
    storing: "store",
    structuring: "structure",
    timing: "time",
    trading: "trade",
    typing: "type",
    riding: "ride",
    hiding: "hide",
    hiking: "hike",
    baking: "bake",
    driving: "drive",
    arriving: "arrive",
    leaving: "leave",
    proving: "prove",
    saving: "save",
    caring: "care",
    having: "have",
    giving: "give",
    living: "live",
    loving: "love",
    moving: "move",
    increasing: "increase",
    achieving: "achieve",
    choosing: "choose",
    causing: "cause",
    placing: "place",
    raising: "raise",
    pursuing: "pursue",
    interviewing: "interview",
    // irregular
    going: "go",
    doing: "do",
    getting: "get",
    running: "run",
    beginning: "begin",
    sitting: "sit",
    swimming: "swim",
    putting: "put",
    cutting: "cut",
    letting: "let",
    setting: "set",
    hitting: "hit",
    stopping: "stop",
    shopping: "shop",
    dropping: "drop",
    planning: "plan",
    // strip-ing works but looks odd without table (double consonant rule catches these too)
    // no-e words that strip cleanly — table not strictly needed but makes intent clear
    learning: "learn",
    working: "work",
    reading: "read",
    thinking: "think",
    starting: "start",
    asking: "ask",
    looking: "look",
    helping: "help",
    building: "build",
    finding: "find",
    studying: "study",
    trying: "try",
    playing: "play",
    fixing: "fix",
    visiting: "visit",
    designing: "design",
    understanding: "understand",
    analyzing: "analyze",
    implementing: "implement",
    testing: "test",
    reviewing: "review",
    debugging: "debug",
    drafting: "draft",
    translating: "translate",
    summarizing: "summarize",
    comparing: "compare",
    explaining: "explain",
    calculating: "calculate",
    converting: "convert",
    applying: "apply",
    optimizing: "optimize",
    refactoring: "refactor",
    deploying: "deploy"
  };
  function gerundToInfinitive(word) {
    const lower = word.toLowerCase();
    if (GERUND_TABLE[lower]) return GERUND_TABLE[lower];
    if (!lower.endsWith("ing") || lower.length < 5) return word;
    const stem = lower.slice(0, -3);
    if (stem.length >= 3 && stem[stem.length - 1] === stem[stem.length - 2] && !"aeiou".includes(stem[stem.length - 1])) {
      return stem.slice(0, -1);
    }
    return stem.length >= 3 ? stem : word;
  }
  function normalizeTaskVerb(task) {
    if (!task) return task;
    const tokens = task.trim().split(/\s+/);
    if (/^(?:go(?:ing)?\s+about|about|trying\s+to)$/i.test(tokens[0])) tokens.shift();
    if (!tokens.length) return task;
    tokens[0] = gerundToInfinitive(tokens[0]);
    return tokens.join(" ");
  }
  function reconstruct(mode, task, subject, role) {
    const subjectHint = subject ?? "";
    const roleTag = role ? ` for ${role}` : "";
    const taskAlreadyHasSubject = subjectHint && task.toLowerCase().includes(subjectHint.toLowerCase());
    switch (mode) {
      case "how_to": {
        const body = `How to ${task}${taskAlreadyHasSubject || !subjectHint ? "" : ` ${subjectHint}`}`;
        return `${body}?`;
      }
      case "explain": {
        const target = subjectHint || task;
        return `Explain ${target}${roleTag}.`;
      }
      case "overview": {
        const target = (subjectHint || task).replace(/^(?:the|a|an)\s+/i, "");
        return `${sc(target)} overview${roleTag}.`;
      }
      case "role_request": {
        return `${sc(task)}${roleTag}${subjectHint ? ` at ${subjectHint}` : ""}.`;
      }
    }
  }
  function semanticFallback(text) {
    const t = text.replace(/\s+/g, " ").trim();
    if (ABORT_RE.test(t)) return null;
    if ((t.match(/[.!?]+\s/g) ?? []).length >= 3) return null;
    if (t.length < 35) return null;
    {
      const frame = extractSemanticFrame(t);
      const rendered = renderCompressedFrame(frame);
      if (rendered && rendered.length < t.length * 0.85 && rendered.length >= 8) {
        return rendered;
      }
    }
    let subject = null;
    let role = null;
    let searchText = t;
    const atMatch = AM_AT_RE.exec(t) ?? AM_AT_PERIOD_RE.exec(t);
    if (atMatch) {
      subject = titleCaseSubject(atMatch[1].trim());
      searchText = t.slice(atMatch[0].length).trim();
    } else {
      const roleMatch = AM_ROLE_RE.exec(t);
      if (roleMatch) {
        role = cleanTopic(roleMatch[1].trim());
        subject = titleCaseSubject(roleMatch[2].trim());
        searchText = t.slice(roleMatch[0].length).trim();
      }
    }
    let taskRaw = null;
    let mode = "how_to";
    for (const entry of INTENT_PATTERNS) {
      const m = entry.re.exec(searchText);
      if (m) {
        taskRaw = m[entry.g]?.trim() ?? null;
        mode = entry.mode;
        break;
      }
    }
    if (!taskRaw && (subject || role) && searchText.length > 3) {
      const directTask = searchText.replace(/^(?:i\s+want\s+to|i\s+need\s+to|please|help\s+me|can\s+you)\s+/i, "").trim();
      if (directTask.length > 3) {
        taskRaw = directTask;
        mode = "role_request";
      }
    }
    if (!taskRaw) return null;
    let taskCoref = taskRaw;
    if (subject) {
      taskCoref = taskCoref.replace(CATEGORY_NOUN_RE, subject).replace(PRONOUN_RE, subject).replace(/\bhere\b/gi, subject);
    }
    const taskClean = taskCoref.replace(/^(?:go(?:ing)?\s+about|trying\s+to|about)\s+/i, "").replace(/\s+(?:this|it|here)\s*$/i, "").replace(/[.?!]+$/, "").trim();
    const taskVerb = normalizeTaskVerb(taskClean);
    const result = reconstruct(mode, taskVerb, subject, role);
    if (result.length >= t.length * 0.85 || result.length < 8) return null;
    return result;
  }

  // src/lib/compression/intentCompressors/emailCompress.ts
  function resolveRecipient(prompt) {
    if (/\bprof(?:essor|ressor)?\b/i.test(prompt)) return "prof";
    if (/\b(?:my\s+)?ta\b/i.test(prompt)) return "TA";
    if (/\bboss\b/i.test(prompt)) return "boss";
    if (/\bmanager\b/i.test(prompt)) return "manager";
    if (/\blandlord\b/i.test(prompt)) return "landlord";
    if (/\badvisor\b/i.test(prompt)) return "advisor";
    if (/\binterviewer\b/i.test(prompt)) return "interviewer";
    const toM = /\bto\s+(?:my\s+)?([a-z][\w\s]{1,24}?)(?:\s+asking|\s+about|\s+if|\s*,|\s+requesting)/i.exec(prompt);
    if (toM) {
      const who = toM[1].trim().split(/\s+/).slice(0, 2).join(" ");
      if (who && !/^(an?|the|him|her|them)$/i.test(who)) return who.toLowerCase();
    }
    return "recipient";
  }
  function resolveTone(prompt, constraints) {
    if (/\bpolite\b/i.test(prompt) || constraints.tone.includes("polite")) return "Polite";
    if (/\bformal\b/i.test(prompt) || constraints.tone.includes("formal")) return "Formal";
    if (/\bprofessional\b/i.test(prompt) || constraints.tone.includes("professional")) return "Professional";
    if (/\bconcise\b/i.test(prompt) || constraints.tone.includes("concise")) return "Concise";
    if (/\bbrief\b/i.test(prompt) || constraints.explicit.some((e) => /\bbrief\b/i.test(e))) return "Brief";
    return "";
  }
  function bracketContexts(prompt) {
    const brackets = [];
    if (/\bgrade\s+(?:is\s+)?(?:dropping|drop(?:ping)?|low|falling)\b/i.test(prompt)) {
      brackets.push("grade dropping");
    }
    const assignLeft = prompt.match(/\b(\d+)\s+assignments?\s+left\b/i);
    if (assignLeft) brackets.push(`${assignLeft[1]} assignments left`);
    if (/\bdeadline\b/i.test(prompt)) brackets.push("deadline");
    if (/\bextension\b/i.test(prompt) && !brackets.includes("deadline")) {
      brackets.push("extension");
    }
    const weekM = prompt.match(/\b(\d+)[- ]?weeks?\b/i);
    if (weekM) brackets.push(`${weekM[1]}-week`);
    if (/\bnot\s+too\s+long\b/i.test(prompt)) brackets.push("not too long");
    return brackets;
  }
  function resolveAsk(prompt) {
    let body = prompt.replace(/^(?:hi|hello|hey)[,!\s]+/i, "").replace(
      /^(?:please\s+)?(?:write|draft|compose|send|create)\s+(?:me\s+)?(?:a\s+)?(?:an\s+)?(?:polite\s+|formal\s+|professional\s+|brief\s+|concise\s+)?(?:email|mail|letter|message)\s+/i,
      ""
    ).replace(/^to\s+(?:my\s+)?(?:prof(?:essor|ressor)?|teacher|ta|boss|manager|landlord|advisor)\s+/i, "").replace(/\b(?:asking|requesting)\s+(?:him|her|them)\s+(?:if|whether)\s+/i, "").replace(/\b(?:asking|requesting)\s+(?:for|about)\s+/i, "").replace(/\bpls\b/gi, "").replace(/\b(?:please\s+)?make\s+it\s+(?:polite|formal|professional|concise|brief)\b/gi, "").replace(/\s+/g, " ").trim();
    if (!body) return null;
    if (/\bextra\s+credit\b/i.test(body) && /\bassignment\b/i.test(body)) {
      return "extra credit assignment?";
    }
    if (/\bextra\s+credit\b/i.test(body)) {
      return "extra credit options?";
    }
    if (/\braise\b/i.test(body) || /\bgrade\s+(?:bump|improvement|improve)\b/i.test(body)) {
      return "raise grade?";
    }
    if (/\bextension\b/i.test(body) || /\bdeadline\s+extension\b/i.test(body)) {
      const weekM = body.match(/\b(\d+)[- ]?weeks?\b/i);
      const topicM = body.match(/\bon\s+(?:the\s+)?([a-z0-9][\w\s.-]{1,40}?)(?:\s*$|,)/i);
      if (weekM && topicM) {
        return `${weekM[1]}-week deadline extension on ${topicM[1].trim()}?`;
      }
      if (weekM) return `${weekM[1]}-week deadline extension?`;
      if (/\bdeadline\b/i.test(body)) return "deadline extension?";
      return "extension request?";
    }
    if (/\bfollow[- ]?up\b/i.test(body) && /\binterview\b/i.test(body)) {
      return "post-interview thank you?";
    }
    if (/\bsalary\s+raise\b/i.test(body) || /\braise\b/i.test(body)) {
      return "salary raise request?";
    }
    body = body.replace(/\bsince\s+my\s+grade\s+is\s+dropping\b/gi, "").replace(/\bbecause\s+my\s+grade\s+is\s+(?:dropping|low)\b/gi, "").replace(/\s+/g, " ").replace(/[,.]+\s*$/g, "").trim();
    if (body.length > 80) {
      const qM = body.match(/(.{10,70}\?)/);
      if (qM) body = qM[1];
      else body = body.slice(0, 72).trim() + "?";
    }
    if (!body.endsWith("?") && !body.endsWith(".")) {
      body = body.replace(/\bif\s+/i, "") + "?";
    }
    return body;
  }
  function compressEmailPrompt(prompt, constraints) {
    const trimmed = prompt.trim();
    if (!/\b(?:email|mail|letter)\b/i.test(trimmed)) return null;
    if (!/\b(?:write|draft|compose|send|create|polite|formal)\b/i.test(trimmed) && !/\bemail\s+to\b/i.test(trimmed)) {
      return null;
    }
    const recipient = resolveRecipient(trimmed);
    const tone = resolveTone(trimmed, constraints);
    const ask = resolveAsk(trimmed);
    if (!ask) return null;
    const brackets = bracketContexts(trimmed);
    const bracketPart = brackets.length ? ` [${brackets.join(", ")}]` : "";
    const tonePart = tone ? `${tone} ` : "";
    const text = `${tonePart}Email ${recipient}: ${ask}${bracketPart}`.replace(/\s+/g, " ").trim();
    if (text.length >= trimmed.length * 0.92) return null;
    return { text, matchedRuleId: "intent.email_compress" };
  }

  // src/lib/compression/intentCompressors/index.ts
  function tryIntentCompressor(prompt, intent, constraints) {
    if (intent.primary_intent === "email_drafting") {
      return compressEmailPrompt(prompt, constraints);
    }
    return null;
  }

  // src/lib/compression/compressPrompt.context.ts
  var CONTEXT_BLOCK_PATTERNS = [
    /```[\w]*\n[\s\S]*?```\s*/g,
    /(?:(?:[ ]{4}|\t)[^\n]+\n){3,}/g,
    /^(?:here is|look at|i have|below is|pasted? (?:below|here)|the following(?:\s+\w+)?)[^\n]*:\s*\n+(?:[^\n]*\n){1,30}/im,
    /(?:\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}[^\n]*\n){2,}/g,
    /\{[\s\S]{50,}\}/g,
    /(?:CREATE|SELECT|INSERT|UPDATE|DELETE|ALTER)\s+[\s\S]{30,}?;/gi,
    /\[[^\]]{20,}\]\s*/g,
    /(?:^\s*[\w-]+:\s*[^\n]+\n){3,}/gm,
    /^-{3,}\s*\n[\s\S]*?\n-{3,}\s*\n?/gm
  ];
  function trySplitQuotedReference(prompt) {
    const leading = prompt.match(/^\s*/)?.[0].length ?? 0;
    const quote = prompt[leading];
    if (quote !== '"' && quote !== "'") return null;
    let close = -1;
    for (let i = leading + 1; i < prompt.length; i++) {
      if (prompt[i] === "\\") {
        i++;
        continue;
      }
      if (prompt[i] === quote) {
        close = i;
        break;
      }
    }
    if (close < 0) return null;
    const afterQuote = prompt.slice(close + 1);
    const instrStart = close + 1 + (afterQuote.length - afterQuote.trimStart().length);
    const instruction = prompt.slice(instrStart).trim();
    const context = prompt.slice(0, close + 1).trim();
    if (context.length < 24 || instruction.length < 6) return null;
    if (instruction.length >= prompt.length * 0.85) return null;
    return {
      active: true,
      instruction,
      context,
      start: instrStart,
      end: prompt.length,
      source: "auto"
    };
  }
  var INSTRUCTION_TAIL_RE = /\b(summarize|summarise|explain|analyze|analyse|compare|list|describe|write|translate|help|tell me|what are|how do|based on|according to|using the|from the|the above|the below|below|following|attached|pasted|this (?:text|article|passage|content|document)|over to you|your turn)\b/i;
  function looksLikeInstructionLine(line) {
    const t = line.trim();
    if (t.length < 4) return false;
    if (INSTRUCTION_TAIL_RE.test(t)) return true;
    if (/\?\s*$/.test(t)) return true;
    if (/:\s*$/.test(t)) return true;
    return false;
  }
  function trySplitTrailingInstruction(prompt) {
    const blocks = prompt.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
    if (blocks.length < 2) return null;
    const tail = blocks[blocks.length - 1];
    const body = blocks.slice(0, -1).join("\n\n");
    if (body.length < 50 || tail.length < 6) return null;
    if (tail.length > prompt.length * 0.42) return null;
    if (!INSTRUCTION_TAIL_RE.test(tail)) return null;
    const bodyLines = body.split("\n").filter((l) => l.trim().length > 0);
    const tailLines = tail.split("\n").filter((l) => l.trim().length > 0);
    if (bodyLines.length < 2) return null;
    const avg = (lines) => lines.reduce((sum, line) => sum + line.length, 0) / Math.max(1, lines.length);
    if (avg(tailLines) > avg(bodyLines) * 1.35 && tail.length > 120) return null;
    const instrStart = prompt.lastIndexOf(tail);
    if (instrStart < 0) return null;
    return {
      active: true,
      instruction: tail,
      context: body,
      start: instrStart,
      end: prompt.length,
      source: "auto"
    };
  }
  function trySplitLeadingInstruction(prompt) {
    const blocks = prompt.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
    if (blocks.length >= 2) {
      const head = blocks[0];
      const body = blocks.slice(1).join("\n\n");
      if (head.length >= 6 && head.length <= prompt.length * 0.42 && body.length >= 50 && looksLikeInstructionLine(head)) {
        const bodyLines = body.split("\n").filter((l) => l.trim().length > 0);
        if (bodyLines.length >= 2) {
          const instrStart = prompt.indexOf(head);
          if (instrStart >= 0) {
            return {
              active: true,
              instruction: head,
              context: body,
              start: instrStart,
              end: instrStart + head.length,
              source: "auto"
            };
          }
        }
      }
    }
    const lines = prompt.split("\n");
    const nonEmptyIdx = [];
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].trim().length > 0) nonEmptyIdx.push(i);
    }
    if (nonEmptyIdx.length < 2) return null;
    for (let headLineCount = 1; headLineCount <= 3; headLineCount++) {
      if (headLineCount >= nonEmptyIdx.length) break;
      const headEndIdx = nonEmptyIdx[headLineCount - 1];
      const bodyStartIdx = nonEmptyIdx[headLineCount];
      const headText = lines.slice(nonEmptyIdx[0], headEndIdx + 1).join("\n").trim();
      const bodyText = lines.slice(bodyStartIdx).join("\n").trim();
      if (headText.length < 6 || headText.length > prompt.length * 0.4) continue;
      if (bodyText.length < 50) continue;
      if (!looksLikeInstructionLine(headText)) continue;
      const bodyLines = bodyText.split("\n").filter((l) => l.trim().length > 0);
      if (bodyText.length < 40 && bodyLines.length < 1) continue;
      const avg = (text) => {
        const ls = text.split("\n").filter((l) => l.trim().length > 0);
        return ls.reduce((s, l) => s + l.length, 0) / Math.max(1, ls.length);
      };
      if (avg(headText) > avg(bodyText) * 1.2 && bodyText.length > headText.length * 2) continue;
      const instrStart = prompt.indexOf(headText);
      if (instrStart < 0) continue;
      return {
        active: true,
        instruction: headText,
        context: bodyText,
        start: instrStart,
        end: instrStart + headText.length,
        source: "auto"
      };
    }
    return null;
  }
  function isValidUserCompressionRange(prompt, range) {
    const len = prompt.length;
    if (len === 0) return false;
    const spanLen = range.end - range.start;
    if (spanLen < 3) return false;
    const coversNearlyAll = spanLen > len * 0.92 && range.start < len * 0.04 && range.end > len * 0.96;
    if (coversNearlyAll) return false;
    const text = prompt.slice(range.start, range.end).trim();
    return text.length >= 3;
  }
  function hasEmbeddedContext(prompt) {
    if (trySplitQuotedReference(prompt)) return true;
    if (trySplitTrailingInstruction(prompt)) return true;
    if (trySplitLeadingInstruction(prompt)) return true;
    if (prompt.includes("```")) return true;
    if (/^(?:here is|look at|i have pasted|below is|the following)\b/i.test(prompt)) return true;
    const lines = prompt.split("\n");
    if (lines.length > 8) return true;
    if (/[{}\[\]]{3,}/.test(prompt) && prompt.length > 150) return true;
    return false;
  }
  function stripEmbeddedContext(prompt) {
    let stripped = prompt;
    for (const pat of CONTEXT_BLOCK_PATTERNS) {
      stripped = stripped.replace(pat, " ");
    }
    stripped = stripped.replace(/\n{3,}/g, "\n").replace(/[ \t]{2,}/g, " ").trim();
    const lines = stripped.split("\n").filter((l) => l.trim().length > 3);
    const questionLine = lines.reverse().find(
      (l) => /\?$/.test(l.trim()) || /^(?:how|what|why|where|can|is|fix|explain|summarize|translate|rewrite|help)/i.test(l.trim())
    );
    if (questionLine && questionLine.trim().length < stripped.length * 0.6) {
      return questionLine.trim();
    }
    return stripped;
  }
  function removeInstructionFromContext(original, instruction) {
    const directIndex = original.indexOf(instruction);
    if (directIndex >= 0) {
      return `${original.slice(0, directIndex)}${original.slice(directIndex + instruction.length)}`.replace(/\n{3,}/g, "\n\n").trim();
    }
    const instructionLines = instruction.split("\n").map((line) => line.trim()).filter(Boolean);
    const originalLines = original.split("\n");
    const filtered = originalLines.filter((line) => !instructionLines.includes(line.trim()));
    return filtered.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function findInstructionOffsets(original, instruction) {
    const directIndex = original.indexOf(instruction);
    if (directIndex >= 0) {
      return { start: directIndex, end: directIndex + instruction.length };
    }
    const instructionLines = instruction.split("\n").map((l) => l.trim()).filter(Boolean);
    if (!instructionLines.length) return null;
    const originalLines = original.split("\n");
    let startLine = -1;
    let endLine = -1;
    for (let i = 0; i < originalLines.length; i++) {
      if (!instructionLines.includes(originalLines[i].trim())) continue;
      if (startLine < 0) startLine = i;
      endLine = i;
    }
    if (startLine < 0) return null;
    let offset = 0;
    for (let i = 0; i < startLine; i++) offset += originalLines[i].length + 1;
    const start = offset;
    let end = start;
    for (let i = startLine; i <= endLine; i++) {
      end += originalLines[i].length + (i < endLine ? 1 : 0);
    }
    return { start, end };
  }
  function buildSpanFromOffsets(prompt, start, end, source) {
    const safeStart = Math.max(0, Math.min(start, prompt.length));
    const safeEnd = Math.max(safeStart, Math.min(end, prompt.length));
    const instruction = prompt.slice(safeStart, safeEnd).trim();
    const before = prompt.slice(0, safeStart);
    const after = prompt.slice(safeEnd);
    const context = `${before}${after}`.replace(/\n{3,}/g, "\n\n").trim();
    const coversAll = safeStart === 0 && safeEnd >= prompt.length;
    return {
      active: !coversAll || source === "whole",
      instruction: instruction || prompt.trim(),
      context: coversAll ? "" : context,
      start: safeStart,
      end: safeEnd,
      source
    };
  }
  function getCompressionTargetSpan(prompt) {
    const original = prompt.trim();
    if (!original) {
      return { active: false, instruction: "", context: "", start: 0, end: 0, source: "whole" };
    }
    const quoted = trySplitQuotedReference(prompt);
    if (quoted) return quoted;
    const trailing = trySplitTrailingInstruction(prompt);
    if (trailing) return trailing;
    const leading = trySplitLeadingInstruction(prompt);
    if (leading) return leading;
    if (!hasEmbeddedContext(original)) {
      return buildSpanFromOffsets(prompt, 0, prompt.length, "whole");
    }
    const instruction = stripEmbeddedContext(original);
    if (!instruction || instruction === original || instruction.length >= original.length * 0.8) {
      return buildSpanFromOffsets(prompt, 0, prompt.length, "whole");
    }
    const context = removeInstructionFromContext(original, instruction);
    if (!context || context === original) {
      return buildSpanFromOffsets(prompt, 0, prompt.length, "whole");
    }
    const offsets = findInstructionOffsets(prompt, instruction) ?? findInstructionOffsets(original, instruction);
    if (!offsets) {
      return {
        active: true,
        instruction,
        context,
        start: 0,
        end: prompt.length,
        source: "auto"
      };
    }
    return {
      active: true,
      instruction,
      context,
      start: offsets.start,
      end: offsets.end,
      source: "auto"
    };
  }
  function resolveCompressionTarget(prompt, userRange) {
    if (!prompt.trim()) {
      return { active: false, instruction: "", context: "", start: 0, end: 0, source: "whole" };
    }
    if (userRange && isValidUserCompressionRange(prompt, userRange)) {
      return buildSpanFromOffsets(prompt, userRange.start, userRange.end, "user");
    }
    const auto = getCompressionTargetSpan(prompt);
    if (auto.source === "auto" && auto.end - auto.start < prompt.length) {
      return auto;
    }
    return buildSpanFromOffsets(prompt, 0, prompt.length, "whole");
  }

  // src/lib/compression/compressPrompt.ts
  function isStructuredPrompt(prompt) {
    if ((prompt.match(/\?/g) ?? []).length >= 5) return true;
    return prompt.split("\n").filter((l) => l.trim()).length >= 8;
  }
  var INTRO_FILLER = [
    [/^In previous assignments? you have focused on/i, "This assignment covers"],
    [/Now it(?:'s| is) time to focus on/i, "Focus on"],
    [/Creating a true \w[\w ]+ takes time[^.]+\.\s*/gi, ""],
    [/The purpose of this exercise is[^.]+\.\s*/gi, ""],
    [/For the purposes of this exercise,?\s*/gi, ""],
    [/use common sense[^.]+\.\s*/gi, "Use best estimates where data is unavailable. "],
    [/As you can see by the rubric,?\s*I(?:'m| am) not looking for exactness[^.]+\.\s*/gi, ""],
    [/I(?:'m| am) not looking for exactness[^.]+\.\s*/gi, ""],
    [/I just want you to role-play[^.]+\.\s*/gi, ""]
  ];
  function compressIntroParagraph(text) {
    let t = text;
    for (const [pat, rep] of INTRO_FILLER) t = t.replace(pat, rep);
    return t.replace(/[ \t]{2,}/g, " ").replace(/^\s+/gm, "").replace(/\n{3,}/g, "\n\n").replace(/^[,;\s]+/, "").trim();
  }
  var SECTION_HEADER_RE = /^[A-Z][A-Za-z/\- ]{1,40}$/;
  function compressStructuredPrompt(prompt, constraints) {
    const lines = prompt.split("\n");
    const result = [];
    let inIntro = true;
    let introBuf = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) {
        if (inIntro && introBuf.length) {
          result.push(compressIntroParagraph(introBuf.join(" ")));
          introBuf = [];
          result.push("");
        } else {
          result.push("");
        }
        continue;
      }
      if (inIntro && SECTION_HEADER_RE.test(trimmed) && result.length > 0) {
        if (introBuf.length) {
          result.push(compressIntroParagraph(introBuf.join(" ")));
          introBuf = [];
        }
        inIntro = false;
      }
      if (inIntro) introBuf.push(trimmed);
      else result.push(line);
    }
    if (introBuf.length) result.push(compressIntroParagraph(introBuf.join(" ")));
    const suffix = buildConstraintSuffix(constraints);
    const joined = result.join("\n").replace(/\n{3,}/g, "\n\n").trim();
    return suffix ? `${joined}

${suffix}` : joined;
  }
  function buildConstraintSuffix(constraints, core = "") {
    const parts = [];
    const coreLower = core.toLowerCase();
    const has = (...needles) => needles.some((needle) => coreLower.includes(needle));
    const shouldKeepExplicit = (constraint) => {
      const lower = constraint.toLowerCase();
      const bulletCount = lower.match(/\bin\s+(\d+|\w+)\s+bullet points?\b/);
      if (bulletCount && coreLower.includes(bulletCount[1]) && coreLower.includes("bullet")) return false;
      if (lower.includes("preserve") && coreLower.includes("preserve")) return false;
      if (lower.includes("under") && coreLower.includes(lower)) return false;
      return !coreLower.includes(lower);
    };
    if (constraints.outputFormat.includes("bullet_points") && !has("bullet")) parts.push("Use concise bullet points");
    if (constraints.outputFormat.includes("numbered_list")) parts.push("Use a numbered list");
    if (constraints.outputFormat.includes("json")) parts.push("Return JSON");
    if (constraints.outputFormat.includes("table")) parts.push("Return a table");
    if (constraints.outputFormat.includes("one_sentence")) parts.push("One sentence only");
    const wantsConcise = constraints.outputFormat.includes("concise") || constraints.tone.includes("brief");
    if (wantsConcise && !has("brief", "concise", "short", "one sentence")) parts.push("Be concise");
    if (constraints.outputFormat.includes("step_by_step")) parts.push("Give step-by-step output");
    if (constraints.outputFormat.includes("markdown")) parts.push("Use markdown formatting");
    if (constraints.tone.includes("professional") && !has("professional")) parts.push("Use a professional tone");
    if (constraints.tone.includes("polite") && !has("polite")) parts.push("Use a polite tone");
    if (constraints.tone.includes("beginner_friendly") && !has("simple terms")) parts.push("Use simple terms");
    if (constraints.tone.includes("formal")) parts.push("Use a formal tone");
    if (constraints.labels.length) parts.push(`Use labels: ${constraints.labels.join("; ")}`);
    const explicit = constraints.explicit.filter(shouldKeepExplicit);
    if (explicit.length) parts.push(explicit.join("; "));
    return parts.length ? `${parts.join(". ")}.` : "";
  }
  var LIGHT_STOPWORDS = /* @__PURE__ */ new Set([
    "a",
    "an",
    "the",
    "to",
    "of",
    "for",
    "in",
    "on",
    "at",
    "with",
    "that",
    "this",
    "it",
    "is",
    "are",
    "be",
    "as",
    "by",
    "from",
    "about",
    "please",
    "kindly",
    "just"
  ]);
  var PHRASE_REPLACEMENTS = [
    [/\bi want to know more about\b/gi, "explain"],
    [/\bwhat are some\b/gi, "give"],
    [/\btell me some\b/gi, "give"],
    [/\bplease tell me\b/gi, "give"],
    [/\btell me a story about\b/gi, "Write a story about"],
    [/\btell me about\b/gi, "Explain"],
    [/\btell me\b/gi, "Explain"],
    [/\bcould you\b/gi, ""],
    [/\bwould you\b/gi, ""],
    [/\bcan you\b/gi, ""],
    [/\bI need you to\b/gi, ""],
    [/\bI want you to\b/gi, ""],
    [/\bhelp me\b/gi, ""],
    [/\bvery\b/gi, ""],
    [/\breally\b/gi, ""],
    [/\band also\b/gi, "and"],
    [/,\s*and why\??\s*$/i, "? Explain your reasoning."]
  ];
  function applyPhraseReplacements(text) {
    return PHRASE_REPLACEMENTS.reduce((acc, [pat, rep]) => acc.replace(pat, rep), text);
  }
  function normalize(text) {
    return text.replace(/\s+/g, " ").replace(/\s([,.!?;:])/g, "$1").replace(/^(so|well|okay|ok|basically|actually)\b[\s,]*/i, "").replace(/\bthe following\b/gi, "this").trim();
  }
  function compactText(text) {
    const tokens = text.split(/\s+/).filter(Boolean);
    const kept = tokens.filter((t) => {
      const clean = t.toLowerCase().replace(/[^a-z0-9_-]/g, "");
      if (!clean) return false;
      if (clean.length === 1 && clean !== "i" && clean !== "a") return false;
      if (/\d/.test(clean) || clean.length > 10) return true;
      return !LIGHT_STOPWORDS.has(clean);
    });
    return kept.length < 4 ? tokens.join(" ") : kept.join(" ");
  }
  function finishSentence(text) {
    return /[?.!]$/.test(text) ? text : `${text}.`;
  }
  var INTENT_VERB_MAP = {
    summarization: "Summarize",
    classification: "Classify",
    extraction: "Extract",
    rewriting_paraphrasing: "Rewrite",
    code_debugging: "Debug",
    code_explanation: "Explain",
    code_generation: "Generate code for",
    email_drafting: "Draft",
    brainstorming: "Brainstorm",
    translation: "Translate",
    creative_writing: "Write",
    analysis: "Analyze",
    general_instruction: "",
    structured_assignment: ""
  };
  var STARTS_WITH_VERB = /^(summarize|classify|extract|rewrite|review|generate|draft|brainstorm|translate|give|do|write|explain|analyze|debug|create|implement|list|describe|compare|evaluate|identify)\b/i;
  function compressPrompt(prompt, intent, constraints, level) {
    const suffix = buildConstraintSuffix(constraints);
    if (intent.primary_intent === "structured_assignment" || isStructuredPrompt(prompt)) {
      return { text: compressStructuredPrompt(prompt, constraints), matchedRuleId: "structured_assignment" };
    }
    const intentResult = tryIntentCompressor(prompt.trim(), intent, constraints);
    if (intentResult) {
      const core = intentResult.text;
      const intentSuffix = buildConstraintSuffix(constraints, core);
      return {
        text: intentSuffix ? `${core} ${intentSuffix}` : core,
        matchedRuleId: intentResult.matchedRuleId
      };
    }
    const ruleResult = applyRule(prompt.trim(), intent.primary_intent);
    if (ruleResult) {
      const core = ruleResult.text;
      const ruleSuffix = buildConstraintSuffix(constraints, core);
      return {
        text: ruleSuffix ? `${core} ${ruleSuffix}` : core,
        matchedRuleId: ruleResult.ruleId
      };
    }
    const semanticResult = semanticFallback(prompt.trim());
    if (semanticResult) {
      const semanticSuffix = buildConstraintSuffix(constraints, semanticResult);
      return {
        text: semanticSuffix ? `${semanticResult} ${semanticSuffix}` : semanticResult,
        matchedRuleId: "semantic_fallback"
      };
    }
    if (level === "conservative") {
      const cleaned2 = normalize(applyPhraseReplacements(removeFillerPhrases(prompt)));
      const core = cleaned2.replace(/^(can|could|would|will)\s+you\s+/i, "").replace(/^give\s+me\s+/i, "give ").replace(/\s+/g, " ").trim();
      return { text: suffix ? `${core} ${suffix}` : core };
    }
    const cleaned = normalize(applyPhraseReplacements(removeFillerPhrases(prompt)));
    let simplified = cleaned.replace(/^(can|could|would|will)\s+you\s+/i, "").replace(/^give\s+me\s+/i, "give ").replace(/^please\s+/i, "").replace(/\b(make sure|ensure that)\b/gi, "").replace(/\b(in order to|so that)\b/gi, "to").replace(/\s+/g, " ").trim();
    if (level === "balanced") {
      const verb2 = INTENT_VERB_MAP[intent.primary_intent] ?? "";
      const sentence = simplified.replace(/[.]+$/, "");
      const balancedCore = STARTS_WITH_VERB.test(sentence) ? sc(sentence) : verb2 ? `${verb2} ${sentence}` : sc(sentence);
      const balancedSuffix = buildConstraintSuffix(constraints, balancedCore);
      return { text: `${finishSentence(balancedCore)}${balancedSuffix ? ` ${balancedSuffix}` : ""}`.trim() };
    }
    const aggressive = compactText(
      simplified.replace(/\b(very|really|just|little)\b/gi, "").replace(/,\s*(and|then)\s*/gi, "; ").replace(/\s+/g, " ").trim()
    );
    const verb = INTENT_VERB_MAP[intent.primary_intent] ?? "";
    const aggressiveCore = verb ? `${verb} ${aggressive.replace(/[.]+$/, "")}` : sc(aggressive.replace(/[.]+$/, ""));
    const aggressiveSuffix = buildConstraintSuffix(constraints, aggressiveCore);
    return { text: `${finishSentence(aggressiveCore)}${aggressiveSuffix ? ` ${aggressiveSuffix}` : ""}`.trim() };
  }

  // src/lib/compression/autoCorrect.ts
  var directTypoMap = {
    pleasw: "please",
    plese: "please",
    pleas: "please",
    // pls intentionally NOT expanded — handled by rule-level stripping to avoid double "please"
    u: "you",
    // ── Short / fat-finger typos (≤3 chars, skipped by fuzzy matcher) ──────────
    ti: "to",
    fo: "for",
    ot: "to",
    mny: "my",
    tje: "the",
    thr: "the",
    hsi: "his",
    heer: "here",
    wnat: "want",
    watn: "want",
    gve: "give",
    // ── Common informal shorthands ─────────────────────────────────────────────
    // Note: tbh, ngl, gimme, rn, imo are intentionally NOT expanded — teacher
    // output preserves or drops them; expansion hurts Jaccard vs teacher labels.
    thru: "through",
    bc: "because",
    smth: "something",
    sth: "something",
    // ── Double-initial-consonant typos ────────────────────────────────────────
    cchecklist: "checklist",
    ccreate: "create",
    ccode: "code",
    ddraft: "draft",
    ffriend: "friend",
    ffriends: "friends",
    wwrite: "write",
    pplan: "plan",
    eexplain: "explain",
    ssummarize: "summarize",
    // ── Domain / tech words that Hunspell doesn't know ────────────────────────
    nextjs: "Next.js",
    pyhton: "python",
    straemlit: "Streamlit",
    strealmit: "Streamlit",
    tailiwnd: "Tailwind",
    blocckhain: "blockchain",
    bolckchain: "blockchain",
    dtaaframe: "dataframe",
    datafrmae: "dataframe",
    daatframe: "dataframe",
    modulenotfoudnerror: "ModuleNotFoundError",
    modulenofthreshold: "ModuleNotFoundError",
    modulenoftounderror: "ModuleNotFoundError",
    leanpromtp: "LeanPrompt",
    fcan: "can",
    startupp: "startup",
    acctually: "actually",
    asignnment: "assignment",
    // ── Informal shorthands — normalize for cleaner rule matching ────────────
    // gimme intentionally NOT expanded — teacher preserves it
    wanna: "want to",
    gonna: "going to",
    gotta: "got to",
    // ── Travel words (needed because Hunspell may flag informal forms) ─────────
    dyas: "days",
    dayz: "days",
    dayss: "days",
    fro: "for",
    bday: "birthday",
    trvelling: "travelling",
    travlling: "travelling",
    travelign: "travelling",
    vidit: "visit",
    visting: "visiting"
  };
  var splitWordRepairs = [
    // --- Preamble stripping (data.jsonl) ---
    [/^Sure[!,]?\s+(?:here(?:'s| is)|let's|I'?d like|I would)[^"'\n]*[:\n]+\s*["']?/i, ""],
    [/^As a helpful assistant[^"'\n]*:\s*\n+["']?/i, ""],
    [/^Without any specific[^"'\n]*:\s*\n+["']?/i, ""],
    [/^Based on your request[^"'\n]*:\s*\n+["']?/i, ""],
    [/\s+-\s+[A-Z][a-zA-Z]+(?: [A-Z][a-zA-Z]+)*\s*$/, ""],
    [/\s*\([^)]*(?:this prompt|this question|this allows|this can|this aims)[^)]*\)\s*$/i, ""],
    [/["']\s*$/, ""],
    // --- Split-word repairs ---
    [/\ban\s+d\b/gi, "and"],
    [/\by\s+ou\b/gi, "you"],
    [/\bt\s+he\b/gi, "the"],
    [/\bp\s+lease\b/gi, "please"],
    [/\bstuden\s+t\b/gi, "student"],
    [/\bcan\s+u\b/gi, "can you"],
    [/\bw\s+ant\b/gi, "want"],
    [/\bk\s+now\b/gi, "know"],
    [/\bhow o\b/gi, "how to"],
    // --- UI noise from form submissions ---
    [/\s*Save\s*&?\s*Submit(?:Cancel)?\s*$/i, ""],
    [/\s*\bCancel\s*$/i, ""]
  ];
  var _spellPromise = null;
  async function loadSpell() {
    try {
      const base = typeof chrome !== "undefined" && chrome.runtime?.getURL ? chrome.runtime.getURL("dict/") : null;
      if (!base) return null;
      const [aff, dic] = await Promise.all([
        fetch(base + "en.aff").then((r) => r.text()),
        fetch(base + "en.dic").then((r) => r.text())
      ]);
      const { default: nspell } = await Promise.resolve().then(() => __toESM(require_lib(), 1));
      return nspell(aff, dic);
    } catch {
      return null;
    }
  }
  function preloadSpellChecker() {
    if (!_spellPromise) _spellPromise = loadSpell();
  }
  async function getSpell() {
    if (!_spellPromise) _spellPromise = loadSpell();
    return _spellPromise;
  }
  function preserveCase(original, corrected) {
    if (original[0] === original[0].toUpperCase() && original[0] !== original[0].toLowerCase()) {
      return corrected.charAt(0).toUpperCase() + corrected.slice(1);
    }
    return corrected;
  }
  async function maybeCorrectWord(word, spell) {
    const lower = word.toLowerCase();
    const direct = directTypoMap[lower];
    if (direct) return direct;
    if (lower.length <= 2 || /\d/.test(lower)) return word;
    if (!spell) return word;
    if (spell.correct(word)) return word;
    const suggestions = spell.suggest(word);
    if (!suggestions.length) return word;
    const best = suggestions[0];
    if (!best) return word;
    return preserveCase(word, best);
  }
  function applyAutoCorrectSync(text) {
    const repaired = splitWordRepairs.reduce(
      (acc, [pattern, replacement]) => acc.replace(pattern, replacement),
      text
    );
    return repaired.replace(/\b([a-zA-Z]{3,})\b/g, (word) => {
      const lower = word.toLowerCase();
      const direct = directTypoMap[lower];
      return direct ? preserveCase(word, direct) : word;
    });
  }
  async function applyAutoCorrect(text) {
    const repaired = splitWordRepairs.reduce(
      (acc, [pattern, replacement]) => acc.replace(pattern, replacement),
      text
    );
    const spell = await getSpell();
    const words = repaired.split(/(\b[a-zA-Z]{3,}\b)/g);
    const corrected = await Promise.all(
      words.map(
        (chunk, i) => i % 2 === 1 ? maybeCorrectWord(chunk, spell) : Promise.resolve(chunk)
      )
    );
    return corrected.join("");
  }

  // src/lib/intent/detectIntent.ts
  var intentRules = [
    // ── Structured assignment / multi-section document ──────────────────────────────────────────────
    // MUST BE FIRST — rubric/assignment prompts contain many "?" chars and would otherwise
    // be misclassified as question_answering. This intent triggers conservative-only compression
    // so that section headers, question lines, and rubric formatting are fully preserved.
    {
      intent: "structured_assignment",
      patterns: [
        /\d+\s*points?\s+(?:for|each|per)\s+(?:section|each|including)/i,
        /\brubric\b/i,
        /\bpackaging\b[\s\S]{0,300}\bplacement\b/i,
        /\bplacement\b[\s\S]{0,300}\bpromotion\b/i,
        /(?:for\s+a\s+physical\s+product|for\s+a\s+digital\s+product)/i,
        /\b(?:as\s+a\s+team|for\s+your\s+business)\b/i,
        /\bmarketing\s+mix\b/i,
        /\bprice\/cost\b/i
      ]
    },
    // Must come BEFORE question_answering so "tell me a story" doesn't get swallowed by /tell me/i.
    // NOTE: "Imagine you are X. What would you do?" is question_answering, NOT creative_writing.
    //       "Imagine a world where X. How would Y?" is also question_answering — it asks for analysis.
    //       Creative_writing ONLY triggers when an explicit creative artifact is requested.
    {
      intent: "creative_writing",
      patterns: [
        /\btell me a story\b/i,
        /write.*\b(?:story|poem|essay|narrative|blog post|article|song|lyric|haiku|script)\b/i,
        /craft.*\b(?:story|narrative|poem|essay)\b/i,
        /compose.*\b(?:poem|song|lyric|narrative)\b/i,
        /create.*\b(?:story|narrative|poem|fiction)\b/i
      ]
    },
    {
      intent: "summarization",
      patterns: [
        /summari[sz]e/i,
        /\bmain ideas?\b/i,
        /\btl;?dr\b/i,
        /\bsum up\b/i,
        /give.*\bsummary\b/i,
        /\bkey (?:points?|takeaways?)\b/i,
        /\boverview of\b/i
      ]
    },
    {
      intent: "classification",
      patterns: [
        /classif(?:y|ication)/i,
        /\blabel\b/i,
        /categori[zs]e/i,
        /\bsort into (?:categories|groups)\b/i
      ]
    },
    {
      intent: "extraction",
      patterns: [
        /\bextract\b/i,
        /\bpull out\b/i,
        /\bidentify entities\b/i,
        /\blist (?:all |the )?(?:names?|entities|items?|dates?|numbers?)\b/i
      ]
    },
    {
      intent: "rewriting_paraphrasing",
      patterns: [
        /\brewrite\b/i,
        /\bparaphrase\b/i,
        /\brephrase\b/i,
        /\bimprove (?:this|the) (?:text|writing|sentence|paragraph)\b/i,
        /\bmake (?:this|it) (?:more |sound )?\b(?:concise|professional|formal|informal|clear)\b/i
      ]
    },
    {
      intent: "code_debugging",
      patterns: [
        /\bdebug\b/i,
        /\bfix (?:the |this |my )?bug\b/i,
        /\bwhat is wrong\b/i,
        /\bfix (?:this |the )?(?:error|issue|problem|bug)\b/i,
        /\bwhy (?:is|does|isn't|doesn't) (?:this|my) (?:code|function|script)/i,
        /\bcode (?:isn't|doesn't|won't) work/i
      ]
    },
    // Must come BEFORE code_generation so "explain code" doesn't match /implement/i
    {
      intent: "code_explanation",
      patterns: [
        /explain.*\bcode\b/i,
        /\bdecode the logic\b/i,
        /how does.*\bcode\b.*work/i,
        /what does.*\bcode\b.*do/i,
        /walk me through.*\bcode\b/i,
        /\bcode (?:review|analysis|explanation)\b/i,
        /understand.*\balgorithm\b/i
      ]
    },
    {
      intent: "code_generation",
      patterns: [
        /\bwrite (?:a |the )?(?:python|java|javascript|typescript|go|rust|c\+\+|sql|bash|shell)\b/i,
        /\bwrite (?:a |the )?(?:function|class|script|program|module|component|api|endpoint)\b/i,
        /\bwrite code\b/i,
        /\bimplement\b/i,
        /\bgenerate.*code\b/i,
        /\bcreate (?:a |the )?(?:function|class|script|program|component)\b/i,
        /\bcode (?:a |the )?solution\b/i,
        /\bdevelop an algorithm\b/i
      ]
    },
    {
      intent: "email_drafting",
      patterns: [
        /\bdraft.*email\b/i,
        /\bwrite.*email\b/i,
        /\bsubject line\b/i,
        /\bcompose.*(?:email|message|letter)\b/i
      ]
    },
    {
      intent: "brainstorming",
      patterns: [
        /\bbrainstorm\b/i,
        /\bideas? for\b/i,
        /\bcreative options\b/i,
        /\bsuggest (?:some |a few )?ideas?\b/i,
        /\bthink of (?:some |a few )?(?:ways?|ideas?|options?)\b/i
      ]
    },
    {
      intent: "analysis",
      patterns: [
        /\banaly[zs]e\b/i,
        /\bcritique\b/i,
        /\bevaluate\b/i,
        /\bcompare.*(?:and|vs\.?|versus)\b/i,
        /\bcontrast\b/i,
        /\bdistinguish between\b/i,
        /\bdifferences? between\b/i,
        /\bpros? and cons?\b/i
      ]
    },
    {
      intent: "question_answering",
      patterns: [
        /\?/,
        /\bexplain\b/i,
        /\bfacts? about\b/i,
        /\bwhat (?:is|are)\b/i,
        /\bhow (?:does|do|to|can|should)\b/i,
        /\bwhy (?:is|are|does|do)\b/i,
        /\btell me (?:about|more)\b/i,
        /\bwhat (?:are|were) the\b/i,
        /\bdescribe\b/i,
        /\bchat about\b/i,
        // Hypothetical / reflective (data.jsonl — 47% of dataset)
        /\bif you could\b/i,
        /\bimagine you (?:are|were|had|could)\b/i,
        /\bthink of a time\b/i,
        /\bwhat (?:would|will) you\b/i,
        /\bif you (?:had|were|found|discovered)\b/i
      ]
    },
    {
      intent: "translation",
      patterns: [
        /\btranslate\b/i,
        /\bin spanish\b/i,
        /\binto english\b/i,
        /\bin (?:french|german|chinese|japanese|arabic|portuguese|italian|russian|korean)\b/i,
        /\bto (?:spanish|french|german|chinese|japanese)\b/i
      ]
    }
  ];
  function detectIntent(prompt) {
    const questionMarkCount = (prompt.match(/\?/g) ?? []).length;
    const structuredBoost = questionMarkCount >= 5 ? 3 : 0;
    const scores = intentRules.map((rule) => {
      let score = rule.patterns.reduce((acc, pattern) => acc + (pattern.test(prompt) ? 1 : 0), 0);
      if (rule.intent === "structured_assignment") score += structuredBoost;
      return { intent: rule.intent, score };
    }).filter((x) => x.score > 0).sort((a, b) => b.score - a.score);
    if (!scores.length) {
      return { primary_intent: "general_instruction", confidence: 0.45, secondary_intents: [] };
    }
    const top = scores[0];
    const secondary = scores.slice(1, 3).map((x) => x.intent);
    const confidence = Math.min(0.98, 0.55 + top.score * 0.14);
    return {
      primary_intent: top.intent,
      confidence: Number(confidence.toFixed(2)),
      secondary_intents: secondary
    };
  }

  // src/lib/config/buildEnv.ts
  function getBuildEnv() {
    const g = globalThis;
    return g.__LEANPROMPT_BUILD__ ?? { supabaseUrl: "", supabaseAnonKey: "", updateManifestUrl: "" };
  }

  // src/lib/auth/supabaseCredentials.ts
  var SUPABASE_SYNC_KEYS = {
    url: "leanprompt_supabase_url",
    anonKey: "leanprompt_supabase_anon_key"
  };
  function pickCredential(syncValue, buildValue) {
    const fromSync = String(syncValue ?? "").trim();
    return fromSync || buildValue.trim();
  }
  function isValidSupabaseProjectUrl(url) {
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "https:") return false;
      if (/YOUR_PROJECT|example\.com|localhost/i.test(parsed.hostname)) return false;
      return parsed.hostname.length > 0;
    } catch {
      return false;
    }
  }
  function normalizeCredentials(url, anonKey) {
    const normalizedUrl = url.replace(/\/$/, "");
    const normalizedKey = anonKey.trim();
    if (!normalizedUrl || !normalizedKey) return null;
    if (!isValidSupabaseProjectUrl(normalizedUrl)) return null;
    return { url: normalizedUrl, anonKey: normalizedKey };
  }
  async function getResolvedSupabaseCredentials() {
    const build = getBuildEnv();
    if (typeof chrome === "undefined" || !chrome.storage?.sync) {
      return normalizeCredentials(build.supabaseUrl, build.supabaseAnonKey);
    }
    try {
      const sync = await chrome.storage.sync.get([SUPABASE_SYNC_KEYS.url, SUPABASE_SYNC_KEYS.anonKey]);
      const url = pickCredential(sync[SUPABASE_SYNC_KEYS.url], build.supabaseUrl);
      const anonKey = pickCredential(sync[SUPABASE_SYNC_KEYS.anonKey], build.supabaseAnonKey);
      return normalizeCredentials(url, anonKey);
    } catch {
      return normalizeCredentials(build.supabaseUrl, build.supabaseAnonKey);
    }
  }
  async function isSupabaseConfigured() {
    const c = await getResolvedSupabaseCredentials();
    return Boolean(c);
  }

  // src/lib/compression/fastModel.ts
  var MIN_SAMPLES = 2;
  var MIN_SAMPLES_SINGLE = 1;
  var MIN_SIMILARITY = 0.55;
  var MIN_SIMILARITY_SINGLE = 0.78;
  var REMOTE_MODEL_CACHE_KEY = "leanprompt_remote_model_v1";
  var REMOTE_MODEL_TTL_MS = 60 * 60 * 1e3;
  var modelByIntent = /* @__PURE__ */ new Map();
  var modelAnyIntent = /* @__PURE__ */ new Map();
  var isLoaded = false;
  function hasLikelyConstraint(text) {
    return /\b(json|table|bullet|word|tone|formal|polite|concise|brief|exactly|under|at least|no more than)\b/i.test(text);
  }
  function appearsConstraintHeavy(constraints) {
    return constraints.outputFormat.length > 1 || constraints.explicit.length > 0 || constraints.labels.length > 0 || constraints.tone.length > 1;
  }
  function registerFastCompressionModel(artifact) {
    const byIntent = /* @__PURE__ */ new Map();
    const anyIntent = /* @__PURE__ */ new Map();
    for (const template of artifact.templates) {
      const teacherOk = template.teacherValidated === true;
      const samplesOk = template.samples >= MIN_SAMPLES || teacherOk && template.samples >= MIN_SAMPLES_SINGLE || template.samples >= MIN_SAMPLES_SINGLE && template.avgSimilarity >= MIN_SIMILARITY_SINGLE;
      const simOk = template.avgSimilarity >= MIN_SIMILARITY || teacherOk;
      if (!samplesOk || !simOk) continue;
      if (!byIntent.has(template.intent)) byIntent.set(template.intent, /* @__PURE__ */ new Map());
      byIntent.get(template.intent)?.set(template.signature, template);
      anyIntent.set(template.signature, template);
    }
    modelByIntent = byIntent;
    modelAnyIntent = anyIntent;
    isLoaded = true;
  }
  async function loadCachedRemoteModel() {
    if (typeof chrome === "undefined" || !chrome.storage?.local) return null;
    try {
      const stored = await chrome.storage.local.get(REMOTE_MODEL_CACHE_KEY);
      const cached = stored[REMOTE_MODEL_CACHE_KEY];
      if (!cached) return null;
      if (Date.now() - cached.fetchedAt < REMOTE_MODEL_TTL_MS) return cached.artifact;
    } catch {
    }
    return null;
  }
  async function fetchRemoteModel() {
    try {
      const creds = await getResolvedSupabaseCredentials();
      if (!creds) return null;
      const remoteUrl = `${creds.url}/storage/v1/object/public/models/fast_compression_model.json`;
      const response = await fetch(remoteUrl, { signal: AbortSignal.timeout(4e3) });
      if (!response.ok) return null;
      const artifact = await response.json();
      if (!artifact?.templates?.length) return null;
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        chrome.storage.local.set({ [REMOTE_MODEL_CACHE_KEY]: { artifact, fetchedAt: Date.now() } }).catch(() => {
        });
      }
      return artifact;
    } catch {
      return null;
    }
  }
  function newerArtifact(a, b) {
    if (!a) return b;
    if (!b) return a;
    return new Date(a.createdAt) >= new Date(b.createdAt) ? a : b;
  }
  async function preloadFastCompressionModel() {
    if (isLoaded) return;
    if (typeof fetch === "undefined") return;
    try {
      const bundledUrl = typeof chrome !== "undefined" && chrome.runtime?.getURL ? chrome.runtime.getURL("models/fast_compression_model.json") : "/models/fast_compression_model.json";
      const bundledResponse = await fetch(bundledUrl);
      const bundledArtifact = bundledResponse.ok ? await bundledResponse.json() : null;
      if (bundledArtifact?.templates?.length) registerFastCompressionModel(bundledArtifact);
      const cachedRemote = await loadCachedRemoteModel();
      const remoteArtifact = cachedRemote ?? await fetchRemoteModel();
      const best = newerArtifact(bundledArtifact, remoteArtifact);
      if (best && best !== bundledArtifact && best.templates?.length) {
        registerFastCompressionModel(best);
      }
    } catch {
    }
  }
  function tokenOverlapRatio(a, b) {
    const tok = (t) => new Set(
      t.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2)
    );
    const setA = tok(a);
    const setB = tok(b);
    if (!setA.size) return 1;
    let overlap = 0;
    for (const w of setA) if (setB.has(w)) overlap++;
    return overlap / setA.size;
  }
  function lookupTemplate(intentName, prompt) {
    const signatures = [
      normalizeFastModelSignature(prompt),
      normalizeFastModelSignature(removeFillerPhrases(prompt))
    ];
    const seen = /* @__PURE__ */ new Set();
    for (const signature of signatures) {
      if (!signature || seen.has(signature)) continue;
      seen.add(signature);
      const intentHit = modelByIntent.get(intentName)?.get(signature);
      if (intentHit) return intentHit;
      const anyHit = modelAnyIntent.get(signature);
      if (anyHit) return anyHit;
    }
    return null;
  }
  function getFastModelSuggestion(prompt, intent, constraints) {
    if (!isLoaded) return null;
    const selected = lookupTemplate(intent.primary_intent, prompt);
    if (!selected) return null;
    if (tokenOverlapRatio(prompt, selected.idealTemplate) < 0.28) return null;
    if (appearsConstraintHeavy(constraints) && !hasLikelyConstraint(selected.idealTemplate)) {
      return null;
    }
    return {
      text: selected.idealTemplate.trim(),
      matchedRuleId: `fast_model.${selected.intent}.${selected.signature.slice(0, 32)}`
    };
  }

  // src/lib/compression/nanoCompress.ts
  var COMPARISON_SIGNALS = [
    /^(?:(?:please\s+)?(?:can\s+you\s+|could\s+you\s+)?(?:explain|describe|tell\s+me)\s+)?(?:the\s+)?differences?\s+between\s+/i,
    /^what\s+(?:is|are)\s+(?:the\s+)?differences?\s+between\s+/i,
    /^(?:please\s+)?compare(?:\s+and\s+contrast)?\s+/i,
    /^how\s+(?:do|does)\s+.+?\s+differ\s+from\s+/i
  ];
  var FRAMING_STRIPS = [
    /^(?:please\s+)?(?:can|could|would|will)\s+you\s+(?:please\s+)?/i,
    /^please\s+/i,
    /^tell\s+me\s+(?:more\s+)?(?:about|on|regarding|concerning)?\s*/i,
    /^(?:give|show)\s+me\s+(?:(?:an?\s+)?(?:overview|explanation|description|info(?:rmation)?)\s+(?:of|on|about)\s+)?/i,
    /^I\s+(?:want|need|would\s+like)\s+to\s+(?:know|learn|understand)\s+(?:more\s+)?(?:about|on|regarding|concerning)?\s*/i,
    /^(?:explain|describe|discuss|elaborate\s+on)\s+/i,
    /^(?:what|how|why)\s+(?:is|are|was|were|does|do|did)\s+/i
  ];
  var VS_RE = /\s+(?:vs\.?|versus)\s+/i;
  var AND_RE = /\s+(?:and|&)\s+/i;
  function stripArticles(t) {
    return t.replace(/\b(?:the|a|an)\s+/gi, "").trim();
  }
  function extractEntities(text) {
    if (VS_RE.test(text)) {
      return text.split(VS_RE).map((p) => stripArticles(p.trim())).filter(Boolean);
    }
    const parts = text.split(AND_RE).map((p) => stripArticles(p.trim())).filter(Boolean);
    return parts.length > 1 ? parts : [stripArticles(text)];
  }
  function mergeSharedSuffix2(entities) {
    if (entities.length < 2) return null;
    const wordLists = entities.map((e) => e.toLowerCase().split(/\s+/));
    if (wordLists.some((w) => w.length < 2)) return null;
    const lastWords = wordLists.map((w) => w[w.length - 1]);
    if (new Set(lastWords).size !== 1) return null;
    const commonSuffix = wordLists[0][wordLists[0].length - 1];
    const uniqueParts = entities.map((e) => e.split(/\s+/).slice(0, -1).join(" "));
    if (uniqueParts.some((p) => !p)) return null;
    return `${uniqueParts.join("/")} ${commonSuffix}`;
  }
  var INTENT_NOUN = {
    summarization: "summary",
    analysis: "analysis",
    classification: "classification",
    extraction: "extraction",
    question_answering: "overview",
    general_instruction: "info",
    brainstorming: "ideas",
    translation: "translation",
    code_explanation: "explanation"
  };
  function nanoCompress(prompt, intent) {
    const trimmed = prompt.trim();
    if (/^(summarize|classify|extract|debug|translate|compare|write|draft|generate|implement|fix|rewrite|explain|describe|list|create)\b/i.test(
      trimmed
    ))
      return null;
    if (trimmed.includes("\n") || trimmed.length < 25) return null;
    for (const re of COMPARISON_SIGNALS) {
      const m = trimmed.match(re);
      if (m) {
        const rest = trimmed.slice(m[0].length).replace(/[?.!]+$/, "").trim();
        if (!rest) continue;
        const entities2 = extractEntities(rest);
        if (entities2.length >= 2) {
          const merged = mergeSharedSuffix2(entities2) ?? entities2.join("/");
          return `${merged} difference`;
        }
      }
    }
    let stripped = trimmed;
    for (const re of FRAMING_STRIPS) {
      const m = stripped.match(re);
      if (m && m[0].length > 4) {
        stripped = stripped.slice(m[0].length);
        break;
      }
    }
    stripped = stripped.replace(/[?.!]+$/, "").trim();
    if (!stripped || stripped.length < 5) return null;
    if (stripped.length >= trimmed.length * 0.82) return null;
    const entities = extractEntities(stripped);
    if (entities.length >= 2) {
      const merged = mergeSharedSuffix2(entities) ?? entities.join(" + ");
      const noun2 = INTENT_NOUN[intent.primary_intent] ?? "info";
      return `${merged} ${noun2}`;
    }
    const noun = INTENT_NOUN[intent.primary_intent];
    if (noun && !stripped.toLowerCase().includes(noun)) {
      return `${stripped} ${noun}`;
    }
    return stripped.length < trimmed.length * 0.8 ? stripped : null;
  }

  // src/lib/compression/teacherShape.ts
  function teacherShapeBonus(text, intentName) {
    let bonus = 0;
    if (/\[[^\]]{2,}\]/.test(text)) bonus += 0.04;
    if (/\?/.test(text)) bonus += 0.02;
    if (intentName === "email_drafting" && /\bemail\s+\w+/i.test(text)) bonus += 0.05;
    if (/\bvs\b|\/|\+/.test(text)) bonus += 0.02;
    return bonus;
  }
  function applyTeacherShape(text, intent) {
    let out = text.trim();
    if (intent.primary_intent === "email_drafting") {
      out = out.replace(/\bWrite\s+email\s+to\b/gi, "Email");
      out = out.replace(/\bDraft\s+email\s*:\s*/gi, "Email ");
      out = out.replace(/\bprofessor\b/gi, "prof");
      out = out.replace(/\bprofressor\b/gi, "prof");
    }
    return out.replace(/\s+/g, " ").trim();
  }

  // src/lib/compression/optimizePrompt.ts
  var PREAMBLE_STRIP_RULES = /* @__PURE__ */ new Set([
    "info.and_honestly_preamble",
    "qa.introduce_person_to_topic_beginner",
    "info.preamble_know_about_topic",
    "info.fastest_way_to_improve_at",
    "creative.professional_friendly_message",
    "info.preamble_help_with_topic",
    "info.gimme_advice_on_topic",
    "info.should_i_filler_topic",
    "info.preamble_should_i_topic",
    "info.explain_like_five",
    "info.and_i_really_need_help",
    "info.how_do_i_topic",
    // Highly-compressed "learned" rules — symbol-heavy outputs are rejected by the
    // standard overlap validator, so we short-circuit with a trusted score instead.
    "qa.ready_for_topic_then_process",
    "qa.compare_where_each_useful",
    "util.formal_not_robotic_message",
    "qa.explain_two_topics_connect_real_life",
    "qa.my_role_struggles_easy_help",
    "qa.accepted_into_department_strength",
    "qa.studying_at_school_topic_especially",
    "qa.tech_stack_plus_topic_best_practices",
    "qa.when_start_timing_next_steps"
  ]);
  var ITERATIVE_PASSES = 15;
  function tokenSet(text) {
    return new Set(
      text.toLowerCase().split(/[^a-z0-9]+/).filter((token) => token.length > 2)
    );
  }
  function tokenOverlapRatio2(original, candidate) {
    const a = tokenSet(original);
    const b = tokenSet(candidate);
    if (!a.size) return 1;
    let overlap = 0;
    for (const token of a) {
      if (b.has(token)) overlap++;
    }
    return overlap / a.size;
  }
  var INTENT_FIDELITY_WEIGHT = {
    code_generation: 1.2,
    code_debugging: 1.15,
    extraction: 1.15,
    translation: 1.15,
    structured_assignment: 1.1,
    rewriting_paraphrasing: 1.05,
    email_drafting: 1,
    summarization: 1,
    classification: 1,
    analysis: 1,
    question_answering: 0.95,
    brainstorming: 0.9,
    creative_writing: 0.9,
    code_explanation: 1,
    general_instruction: 1
  };
  var INTENT_RANK_WEIGHTS = {
    email_drafting: { quality: 0.58, brevity: 0.38, overlap: 0.01, minReduction: 0.18 },
    code_debugging: { quality: 0.55, brevity: 0.35, overlap: 0.02, minReduction: 0.12 },
    code_generation: { quality: 0.55, brevity: 0.35, overlap: 0.02, minReduction: 0.12 },
    question_answering: { quality: 0.6, brevity: 0.32, overlap: 0.03, minReduction: 0.15 }
  };
  var DEFAULT_RANK_WEIGHTS = { quality: 0.72, brevity: 0.23, overlap: 0.05, minReduction: 0 };
  function rankCandidate(originalText, candidateText, validation, intentName, matchedRuleId) {
    const before = estimateTokens(originalText);
    const after = estimateTokens(candidateText);
    const reduction = before > 0 ? Math.max(0, (before - after) / before) : 0;
    const overlap = tokenOverlapRatio2(originalText, candidateText);
    const fidelityWeight = INTENT_FIDELITY_WEIGHT[intentName] ?? 1;
    const weights = INTENT_RANK_WEIGHTS[intentName] ?? DEFAULT_RANK_WEIGHTS;
    if (reduction < weights.minReduction && matchedRuleId?.startsWith("util.")) {
      return 0;
    }
    const quality = validation.score * weights.quality * fidelityWeight;
    const brevityBonus = reduction * weights.brevity;
    const overlapTieBreaker = overlap * weights.overlap;
    const deterministicRuleBonus = matchedRuleId ? 0.08 : 0;
    const intentBonus = matchedRuleId?.startsWith("intent.") ? 0.12 : 0;
    const shapeBonus = teacherShapeBonus(candidateText, intentName);
    return Number(
      (quality + brevityBonus + overlapTieBreaker + deterministicRuleBonus + intentBonus + shapeBonus).toFixed(6)
    );
  }
  function stripOutputFiller(text) {
    let out = text;
    const hadLeadingWith = /^[Ww]ith\s+(?!examples?\b|example\b|context\b|your\b|the\s|a\s)/i.test(out);
    if (hadLeadingWith) out = out.replace(/^[Ww]ith\s+/i, "");
    out = out.replace(/^[Ss]tep\s+by\s+step\s+plan\s+for\s+/, "");
    out = out.replace(
      /^(?:[Gg]ive\s+me\s+(?:with\s+)?|[Hh]elp\s+me\s+(?:with\s+)?|[Cc]an\s+you\s+(?:with\s+)?|[Bb]est\s+way\s+to\s+(?:with\s+)?|I\s+need\s+help\s+with\s+)(?!beginner\b|examples?\b|context\b)/i,
      ""
    );
    if (out !== text && out.length > 0 && /[a-z]/.test(out[0] ?? "")) {
      out = (out[0] ?? "").toUpperCase() + out.slice(1);
    }
    out = out.replace(/\bi\s+don'?t\s+want\s+to\b/gi, "i don't");
    out = out.replace(/\bplease\s+explain\s+simply\b/gi, "please simply");
    out = out.replace(/\s+\bbc\b\s+/gi, " ");
    out = out.replace(/\s+\b(tbh|rn|ngl|fr|imo|pls|wanna|highkey|lowkey)\b(?=\s+—)/gi, "");
    out = out.replace(/\s+\b(tbh|ngl|fr|imo|fwiw|highkey|lowkey|wanna)\b\s*([.,!?]?\s*)$/gi, "$2");
    out = out.replace(/\s+\bwanna\b\s*$/gi, "");
    out = out.replace(/\s*[.,]?\s*Use\s+simple\s+terms\.\s*$/i, "");
    out = out.replace(/\s*\.\s*with\s+examples?\.\s*$/i, ".");
    out = out.replace(/\s+overview\s*$/i, "");
    out = out.replace(
      /\s+—\s+[a-zA-Z0-9][a-zA-Z0-9\-\/]*(?:\s+[a-zA-Z0-9][a-zA-Z0-9\-\/]*)?\.*\s*$/i,
      ""
    );
    out = out.replace(/\.\s+—\s+/g, " \u2014 ");
    out = out.replace(/\s{2,}/g, " ");
    out = out.replace(/\s+([.,!?])/g, "$1");
    return out.trim();
  }
  function variantTransforms(text) {
    return [
      text,
      text.replace(/^(so|well|okay|ok|basically|actually)\b[\s,]*/i, ""),
      text.replace(/^idk\s+if\s+(?:this\s+is\s+)?dumb(?:\s+but)?\s*/i, ""),
      text.replace(/\band\s+honestly\b[\s,]*/i, ""),
      text.replace(/\bi want to learn\b/gi, "learn"),
      text.replace(/\bi want to know more about\b/gi, "explain"),
      text.replace(/\bi have\b/gi, "have"),
      text.replace(/\s*\.\s*/g, ". ").replace(/\.\s*\./g, "."),
      text.replace(/\bit's\b/gi, "it is"),
      text.replace(/\ba new\b/gi, "a"),
      text.replace(/\bexplore it\b/gi, "explore"),
      text.replace(/\s+/g, " ").trim()
    ];
  }
  function withEmbeddedContext(originalText, instructionResult, context) {
    const optimizedText = context ? `${instructionResult.optimizedText}

Context:
${context}`.trim() : instructionResult.optimizedText;
    const tokenEstimateBefore = estimateTokens(originalText);
    const tokenEstimateAfter = estimateTokens(optimizedText);
    const rawReduction = (tokenEstimateBefore - tokenEstimateAfter) / tokenEstimateBefore * 100;
    return {
      ...instructionResult,
      originalText,
      optimizedText,
      tokenEstimateBefore,
      tokenEstimateAfter,
      reductionPercent: Math.max(0, Number(rawReduction.toFixed(1))),
      costSavingsEstimate: Math.max(
        0,
        Number((estimateCost(tokenEstimateBefore) - estimateCost(tokenEstimateAfter)).toFixed(6))
      ),
      carbonSavingsEstimate: Math.max(
        0,
        Number((estimateCarbon(tokenEstimateBefore) - estimateCarbon(tokenEstimateAfter)).toFixed(6))
      )
    };
  }
  function applySymbolCompaction(text, level) {
    if (level === "conservative") return text;
    if (text.includes("```")) return text;
    let out = text;
    for (const [pattern, replacement] of SYMBOL_COMPACTION_REPLACEMENTS) {
      out = out.replace(pattern, replacement);
    }
    if (level === "aggressive") {
      out = out.replace(/\bversus\b/gi, "vs").replace(/\b(\w+)\s+and\s+(\w+)\b/gi, "$1 + $2").replace(/\s*;\s*/g, " \xB7 ").replace(/\s{2,}/g, " ").trim();
    } else {
      out = out.replace(/\bversus\b/gi, "vs").replace(/\s{2,}/g, " ").trim();
    }
    return out.replace(/\s+([:?])/g, "$1").replace(/:\s+/g, ": ").trim();
  }
  function optimizePromptWithTarget(fullPrompt, target, level, conciseMode = false) {
    const instructionText = fullPrompt.slice(target.start, target.end).trim();
    const isWholeBox = target.source === "whole" || target.start <= 0 && target.end >= fullPrompt.length && !target.context.trim();
    if (!instructionText || isWholeBox) {
      return optimizePrompt(fullPrompt, level, conciseMode);
    }
    if (!target.context.trim()) {
      const partial = optimizePrompt(instructionText, level, conciseMode);
      return { ...partial, originalText: fullPrompt.trim(), instructionSourceText: instructionText };
    }
    const merged = withEmbeddedContext(
      fullPrompt.trim(),
      optimizePrompt(instructionText, level, conciseMode),
      target.context
    );
    return {
      ...merged,
      instructionSourceText: instructionText,
      instructionContextText: target.context
    };
  }
  function optimizePrompt(prompt, level, conciseMode = false) {
    const originalText = prompt.trim();
    if (hasEmbeddedContext(originalText)) {
      const instruction = stripEmbeddedContext(originalText);
      if (instruction && instruction !== originalText && instruction.length < originalText.length * 0.8) {
        const context = removeInstructionFromContext(originalText, instruction);
        if (context && context !== originalText) {
          return withEmbeddedContext(originalText, optimizePrompt(instruction, level), context);
        }
      }
    }
    const normalizedForCompression = applyAutoCorrectSync(originalText);
    const intent = detectIntent(normalizedForCompression);
    const constraints = extractConstraints(normalizedForCompression);
    const learnedText = getLearnedGeminiCompression(normalizedForCompression, intent.primary_intent);
    if (learnedText) {
      const learnedValidation = validateCompression(originalText, learnedText, intent, constraints);
      const tokenEstimateBefore2 = estimateTokens(originalText);
      const tokenEstimateAfter2 = estimateTokens(learnedText);
      if (learnedValidation.valid && learnedValidation.score >= 0.75 && tokenEstimateAfter2 < tokenEstimateBefore2) {
        const rawReduction2 = (tokenEstimateBefore2 - tokenEstimateAfter2) / tokenEstimateBefore2 * 100;
        return {
          originalText,
          optimizedText: learnedText,
          tokenEstimateBefore: tokenEstimateBefore2,
          tokenEstimateAfter: tokenEstimateAfter2,
          reductionPercent: Math.max(0, Number(rawReduction2.toFixed(1))),
          costSavingsEstimate: Math.max(
            0,
            Number((estimateCost(tokenEstimateBefore2) - estimateCost(tokenEstimateAfter2)).toFixed(6))
          ),
          carbonSavingsEstimate: Math.max(
            0,
            Number((estimateCarbon(tokenEstimateBefore2) - estimateCarbon(tokenEstimateAfter2)).toFixed(6))
          ),
          intent,
          constraints,
          validation: learnedValidation,
          matchedRuleId: "gemini_learned",
          compressionTrace: {
            offlineOutput: learnedText,
            geminiOutput: learnedText,
            sourceModel: "gemini",
            geminiModel: "learned_cache",
            geminiLatencyMs: 0
          }
        };
      }
    }
    {
      const preambleResult = applyRule(normalizedForCompression);
      if (preambleResult && PREAMBLE_STRIP_RULES.has(preambleResult.ruleId) && preambleResult.text) {
        const optimizedText2 = stripOutputFiller(preambleResult.text);
        const tokenEstimateBefore2 = estimateTokens(originalText);
        const tokenEstimateAfter2 = estimateTokens(optimizedText2);
        const rawReduction2 = (tokenEstimateBefore2 - tokenEstimateAfter2) / tokenEstimateBefore2 * 100;
        return {
          originalText,
          optimizedText: optimizedText2,
          tokenEstimateBefore: tokenEstimateBefore2,
          tokenEstimateAfter: tokenEstimateAfter2,
          reductionPercent: Math.max(0, Number(rawReduction2.toFixed(1))),
          costSavingsEstimate: Math.max(0, Number((estimateCost(tokenEstimateBefore2) - estimateCost(tokenEstimateAfter2)).toFixed(6))),
          carbonSavingsEstimate: Math.max(0, Number((estimateCarbon(tokenEstimateBefore2) - estimateCarbon(tokenEstimateAfter2)).toFixed(6))),
          intent,
          constraints,
          validation: { valid: true, score: 0.88, reasons: [], preservedConstraints: [], droppedConstraints: [] },
          matchedRuleId: preambleResult.ruleId
        };
      }
    }
    {
      const intentHit = tryIntentCompressor(normalizedForCompression, intent, constraints);
      if (intentHit) {
        const shaped = applyTeacherShape(intentHit.text, intent);
        const validation = validateCompression(originalText, shaped, intent, constraints);
        const tokenEstimateBefore2 = estimateTokens(originalText);
        const tokenEstimateAfter2 = estimateTokens(shaped);
        const reduction = tokenEstimateBefore2 > 0 ? (tokenEstimateBefore2 - tokenEstimateAfter2) / tokenEstimateBefore2 : 0;
        if (validation.valid && validation.score >= 0.72 && tokenEstimateAfter2 < tokenEstimateBefore2 && reduction >= (INTENT_RANK_WEIGHTS[intent.primary_intent]?.minReduction ?? 0.1)) {
          const rawReduction2 = reduction * 100;
          return {
            originalText,
            optimizedText: shaped,
            tokenEstimateBefore: tokenEstimateBefore2,
            tokenEstimateAfter: tokenEstimateAfter2,
            reductionPercent: Math.max(0, Number(rawReduction2.toFixed(1))),
            costSavingsEstimate: Math.max(
              0,
              Number((estimateCost(tokenEstimateBefore2) - estimateCost(tokenEstimateAfter2)).toFixed(6))
            ),
            carbonSavingsEstimate: Math.max(
              0,
              Number((estimateCarbon(tokenEstimateBefore2) - estimateCarbon(tokenEstimateAfter2)).toFixed(6))
            ),
            intent,
            constraints,
            validation,
            matchedRuleId: intentHit.matchedRuleId
          };
        }
      }
    }
    if (conciseMode) {
      const nanoText = nanoCompress(normalizedForCompression, intent);
      if (nanoText) {
        const tokenEstimateBefore2 = estimateTokens(originalText);
        const tokenEstimateAfter2 = estimateTokens(nanoText);
        const rawReduction2 = (tokenEstimateBefore2 - tokenEstimateAfter2) / tokenEstimateBefore2 * 100;
        return {
          originalText,
          optimizedText: nanoText,
          tokenEstimateBefore: tokenEstimateBefore2,
          tokenEstimateAfter: tokenEstimateAfter2,
          reductionPercent: Math.max(0, Number(rawReduction2.toFixed(1))),
          costSavingsEstimate: Math.max(0, Number((estimateCost(tokenEstimateBefore2) - estimateCost(tokenEstimateAfter2)).toFixed(6))),
          carbonSavingsEstimate: Math.max(0, Number((estimateCarbon(tokenEstimateBefore2) - estimateCarbon(tokenEstimateAfter2)).toFixed(6))),
          intent,
          constraints,
          validation: validateCompression(originalText, nanoText, intent, constraints),
          matchedRuleId: "nano_compress"
        };
      }
    }
    const isStructured = intent.primary_intent === "structured_assignment" || (normalizedForCompression.match(/\?/g) ?? []).length >= 5;
    const levelCycle = isStructured ? ["conservative"] : level === "conservative" ? ["conservative", "balanced"] : ["balanced", "aggressive", "conservative"];
    const variants = variantTransforms(normalizedForCompression);
    const seen = /* @__PURE__ */ new Set();
    const candidates = [];
    const fastModelCandidate = getFastModelSuggestion(normalizedForCompression, intent, constraints);
    if (fastModelCandidate) {
      const validation = validateCompression(originalText, fastModelCandidate.text, intent, constraints);
      if (validation.valid && validation.score >= 0.75) {
        seen.add(fastModelCandidate.text);
        candidates.push({
          text: fastModelCandidate.text,
          matchedRuleId: fastModelCandidate.matchedRuleId,
          validation,
          tokens: estimateTokens(fastModelCandidate.text),
          rankScore: rankCandidate(
            originalText,
            fastModelCandidate.text,
            validation,
            intent.primary_intent,
            fastModelCandidate.matchedRuleId
          )
        });
      }
    }
    for (let i = 0; i < ITERATIVE_PASSES; i++) {
      const variant = variants[i % variants.length];
      const candidateLevel = levelCycle[i % levelCycle.length];
      const output = compressPrompt(variant, intent, constraints, candidateLevel);
      const { text, matchedRuleId } = output;
      if (seen.has(text)) continue;
      seen.add(text);
      const validation = validateCompression(originalText, text, intent, constraints);
      candidates.push({
        text,
        matchedRuleId,
        validation,
        tokens: estimateTokens(text),
        rankScore: rankCandidate(originalText, text, validation, intent.primary_intent, matchedRuleId)
      });
    }
    const validCandidates = candidates.filter((c) => c.validation.valid && c.validation.score >= 0.72).sort((a, b) => b.rankScore - a.rankScore || a.tokens - b.tokens || b.validation.score - a.validation.score);
    const validRuleBackedCandidates = validCandidates.filter((c) => Boolean(c.matchedRuleId));
    const fallback = candidates.slice().sort((a, b) => b.rankScore - a.rankScore || b.validation.score - a.validation.score || a.tokens - b.tokens)[0];
    const bestValid = validRuleBackedCandidates[0] ?? validCandidates[0] ?? fallback;
    const optimizedTextBase = applyTeacherShape(stripOutputFiller(bestValid?.text ?? originalText), intent);
    const compacted = applySymbolCompaction(optimizedTextBase, level);
    const compactedValidation = validateCompression(originalText, compacted, intent, constraints);
    const shouldUseCompacted = compacted !== optimizedTextBase && compactedValidation.valid && compactedValidation.score >= (bestValid?.validation.score ?? 0) - 0.02;
    const optimizedText = shouldUseCompacted ? compacted : optimizedTextBase;
    const finalValidation = shouldUseCompacted ? compactedValidation : bestValid?.validation ?? { valid: false, score: 0, reasons: [], preservedConstraints: [], droppedConstraints: [] };
    const tokenEstimateBefore = estimateTokens(originalText);
    let workingText = optimizedText;
    let workingValidation = finalValidation;
    let workingTokens = estimateTokens(workingText);
    if (tokenEstimateBefore >= 100 && workingTokens > tokenEstimateBefore * 0.82) {
      let aggressive = stripOutputFiller(
        applySymbolCompaction(removeFillerPhrases(normalizedForCompression), "aggressive")
      );
      aggressive = aggressive.replace(/\s+/g, " ").trim();
      const aggVal = validateCompression(originalText, aggressive, intent, constraints);
      const aggTokens = estimateTokens(aggressive);
      if (aggVal.valid && aggVal.score >= 0.72 && aggTokens < workingTokens && aggTokens < tokenEstimateBefore) {
        workingText = aggressive;
        workingValidation = aggVal;
        workingTokens = aggTokens;
      }
    }
    const tokenEstimateAfter = workingTokens;
    const rawReduction = (tokenEstimateBefore - tokenEstimateAfter) / tokenEstimateBefore * 100;
    const finalText = tokenEstimateAfter > tokenEstimateBefore ? originalText : workingText;
    const finalTokens = finalText === originalText ? tokenEstimateBefore : tokenEstimateAfter;
    return {
      originalText,
      optimizedText: finalText,
      tokenEstimateBefore,
      tokenEstimateAfter: finalTokens,
      reductionPercent: Math.max(0, Number(rawReduction.toFixed(1))),
      costSavingsEstimate: Math.max(
        0,
        Number((estimateCost(tokenEstimateBefore) - estimateCost(finalTokens)).toFixed(6))
      ),
      carbonSavingsEstimate: Math.max(
        0,
        Number((estimateCarbon(tokenEstimateBefore) - estimateCarbon(finalTokens)).toFixed(6))
      ),
      intent,
      constraints,
      validation: finalText === workingText ? workingValidation : finalValidation,
      matchedRuleId: bestValid?.matchedRuleId
    };
  }

  // src/lib/billing/plan.ts
  var FREE_MONTHLY_LIMIT = 80;
  function isExtensionContextUnavailable(error) {
    return error instanceof Error && /extension context invalidated|context invalidated/i.test(error.message);
  }
  function enforcePlanLimit(user) {
    if (!user) {
      return { allowed: true };
    }
    if (user.plan === "pro") return { allowed: true };
    if (user.monthly_usage_count >= FREE_MONTHLY_LIMIT) {
      return { allowed: false, reason: `Free plan limit reached (${FREE_MONTHLY_LIMIT}/month).` };
    }
    return { allowed: true };
  }
  async function checkOptimizeGate(user, auth) {
    const configured = await isSupabaseConfigured();
    if (configured) {
      const signedIn = Boolean(user) || Boolean(auth?.loggedIn);
      if (!signedIn) {
        return {
          allowed: false,
          reason: "Sign in to LeanPrompt \u2014 click the extension icon and log in."
        };
      }
      const needsVerify = auth?.needsEmailVerification ?? (Boolean(user?.email) && user?.emailVerified === false);
      if (needsVerify) {
        return {
          allowed: false,
          reason: "Verify your email to use LeanPrompt (check your inbox for the confirmation link)."
        };
      }
    }
    return enforcePlanLimit(user);
  }
  async function incrementUsage(user) {
    if (!user) return;
    const key = `usage_${user.id}`;
    try {
      const item = await chrome.storage.local.get(key);
      const next = Number(item[key] ?? user.monthly_usage_count) + 1;
      await chrome.storage.local.set({ [key]: next });
    } catch (error) {
      if (isExtensionContextUnavailable(error)) return;
      throw error;
    }
  }

  // src/lib/feedback/buildTeacherRecord.ts
  function buildTeacherCompressionRecord(result, action, finalText, editedText) {
    const trace = result.compressionTrace ?? {
      offlineOutput: result.optimizedText,
      geminiOutput: null,
      sourceModel: "offline"
    };
    return {
      original_prompt: result.originalText,
      offline_output: trace.offlineOutput,
      gemini_output: trace.geminiOutput ?? null,
      final_output_used: finalText,
      user_action: action,
      user_edited_output: editedText.trim() !== result.optimizedText.trim() ? editedText : null,
      intent: result.intent.primary_intent,
      validation_score: result.validation.score,
      reduction_percent: result.reductionPercent,
      source_model: trace.sourceModel,
      gemini_model: trace.geminiModel ?? null,
      gemini_latency_ms: trace.geminiLatencyMs ?? null
    };
  }
  function modelUsedLabel(result) {
    const trace = result.compressionTrace;
    if (trace?.sourceModel === "gemini") {
      return trace.geminiModel ?? "gemini";
    }
    return result.matchedRuleId ?? "offline";
  }

  // src/lib/feedback/promptFeedbackBridge.ts
  async function flushPromptFeedbackThroughBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
    await new Promise((resolve) => {
      const msg = { type: "LEANPROMPT_FLUSH_PROMPT_FEEDBACK" };
      chrome.runtime.sendMessage(msg, () => {
        void chrome.runtime.lastError;
        resolve();
      });
    });
  }
  async function recordPromptFeedbackThroughBackground(feedback) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
    await new Promise((resolve) => {
      const msg = { type: "LEANPROMPT_RECORD_PROMPT_FEEDBACK", feedback };
      chrome.runtime.sendMessage(msg, () => {
        void chrome.runtime.lastError;
        resolve();
      });
    });
  }

  // src/lib/feedback/teacherCompressionsBridge.ts
  async function recordTeacherCompressionThroughBackground(record) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: "LEANPROMPT_RECORD_TEACHER_COMPRESSION", record },
        (response) => {
          const err = chrome.runtime.lastError;
          if (err) {
            reject(new Error(err.message));
            return;
          }
          if (response?.ok === false) {
            reject(new Error(response.error ?? "Failed to record teacher compression"));
            return;
          }
          resolve();
        }
      );
    });
  }
  async function flushTeacherCompressionsThroughBackground() {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LEANPROMPT_FLUSH_TEACHER_COMPRESSIONS" }, () => {
        resolve();
      });
    });
  }

  // src/lib/storage/settings.ts
  var SETTINGS_KEY = "leanprompt_settings";
  var defaultSettings = {
    compressionLevel: "balanced",
    autoOptimize: false,
    showInlineMetrics: true,
    enabledSites: { chatgpt: true, claude: true, gemini: true },
    historyOptIn: false,
    apiAssistEnabled: true,
    instructionHighlightBeta: false,
    autocorrectEnabled: true
  };
  function isExtensionContextUnavailable2(error) {
    return error instanceof Error && /extension context invalidated|context invalidated/i.test(error.message);
  }
  async function getSettings() {
    try {
      const data = await chrome.storage.sync.get(SETTINGS_KEY);
      const stored = data[SETTINGS_KEY] ?? {};
      return {
        ...defaultSettings,
        ...stored,
        // On by default; only off if user explicitly saved false
        apiAssistEnabled: stored.apiAssistEnabled !== false,
        instructionHighlightBeta: stored.instructionHighlightBeta === true,
        autocorrectEnabled: stored.autocorrectEnabled !== false
      };
    } catch (error) {
      if (isExtensionContextUnavailable2(error)) return defaultSettings;
      throw error;
    }
  }

  // src/content/promptInput.ts
  var PROMPT_INPUT_SELECTORS = [
    "textarea:not([disabled])",
    "div#prompt-textarea[contenteditable='true']",
    "div.ProseMirror[contenteditable='true']",
    "div[contenteditable='true'][data-placeholder]",
    "div[contenteditable='true'][role='textbox']",
    "div[contenteditable='true']"
  ];
  function isVisible(el) {
    if (!el.isConnected) return false;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  function findEditableFromNode(node) {
    let current = node;
    while (current) {
      if (current instanceof HTMLTextAreaElement && isVisible(current)) {
        return current;
      }
      if (current instanceof HTMLElement && current.isContentEditable && isVisible(current)) {
        return current;
      }
      if (current instanceof ShadowRoot) {
        current = current.host;
        continue;
      }
      current = current.parentNode;
    }
    return null;
  }
  function queryPromptInputsInRoot(root) {
    const out = [];
    for (const selector of PROMPT_INPUT_SELECTORS) {
      const nodes = root.querySelectorAll(selector);
      for (const node of Array.from(nodes)) {
        if (node instanceof HTMLElement && isVisible(node)) {
          out.push(node);
        }
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const el of Array.from(allElements)) {
      if (el instanceof HTMLElement && el.shadowRoot) {
        out.push(...queryPromptInputsInRoot(el.shadowRoot));
      }
    }
    return out;
  }
  function dedupeToInnermostEditors(candidates) {
    return candidates.filter(
      (el, i) => !candidates.some((other, j) => j !== i && other !== el && el.contains(other))
    );
  }
  function scorePromptInput(el) {
    const textLen = (el instanceof HTMLTextAreaElement ? el.value : el.innerText ?? "").length;
    const area = el.getBoundingClientRect().width * el.getBoundingClientRect().height;
    let score = textLen * 10 + area;
    if (el.id === "prompt-textarea") score += 5e3;
    if (el.classList.contains("ProseMirror")) score += 3e3;
    if (document.activeElement === el || el.contains(document.activeElement)) score += 2e3;
    const sel = window.getSelection();
    if (sel?.anchorNode && el.contains(sel.anchorNode)) score += 4e3;
    return score;
  }
  function findPromptInputElement() {
    const candidates = dedupeToInnermostEditors(queryPromptInputsInRoot(document));
    if (candidates.length === 0) return null;
    const fromSelection = findEditableFromNode(window.getSelection()?.anchorNode ?? null);
    if (fromSelection && candidates.some((c) => c === fromSelection || c.contains(fromSelection))) {
      return fromSelection;
    }
    if (document.activeElement instanceof HTMLElement) {
      const fromActive = findEditableFromNode(document.activeElement);
      if (fromActive && candidates.some((c) => c === fromActive || c.contains(fromActive))) {
        return fromActive;
      }
    }
    return candidates.sort((a, b) => scorePromptInput(b) - scorePromptInput(a))[0] ?? null;
  }

  // src/content/siteDetection.ts
  function detectSupportedSite(hostname) {
    if (hostname.includes("chatgpt.com") || hostname.includes("chat.openai.com")) return "chatgpt";
    if (hostname.includes("claude.ai")) return "claude";
    if (hostname.includes("gemini.google.com")) return "gemini";
    return null;
  }
  var BLOCKLIST_HOSTS = /* @__PURE__ */ new Set([
    "mail.google.com",
    "gmail.com",
    "outlook.live.com",
    "outlook.office.com",
    "outlook.office365.com",
    "mail.yahoo.com",
    "protonmail.com",
    "app.protonmail.com",
    "mail.protonmail.com",
    "calendar.google.com",
    "docs.google.com",
    "sheets.google.com",
    "slides.google.com",
    "drive.google.com",
    "notion.so"
  ]);
  var AI_HOST_HINTS = [
    "gpt",
    "openai",
    // platform.openai.com, api.openai.com
    "llm",
    "chatbot",
    "assistant",
    "perplexity",
    "poe.com",
    "copilot",
    "mistral",
    "grok",
    "deepseek",
    "openrouter",
    "huggingface"
  ];
  function isLikelyAIToolSite(hostname, pathname) {
    const host = hostname.toLowerCase();
    const path = pathname.toLowerCase();
    if (BLOCKLIST_HOSTS.has(host)) return false;
    if (detectSupportedSite(host)) return true;
    if (AI_HOST_HINTS.some((hint) => host.includes(hint))) return true;
    const segments = host.split(".");
    if (segments[segments.length - 1] === "ai" || segments.includes("ai")) return true;
    if (path.includes("/chat") || path.includes("/assistant") || path.includes("/prompt")) return true;
    return false;
  }

  // src/content/instructionHighlight.ts
  var TYPING_IDLE_MS = 700;
  var PASTE_IDLE_MS = 450;
  function debounce(fn, ms) {
    let timer = null;
    return ((...args) => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => fn(...args), ms);
    });
  }
  function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function syncMirrorStyles(input, mirror) {
    const cs = getComputedStyle(input);
    mirror.style.font = cs.font;
    mirror.style.fontSize = cs.fontSize;
    mirror.style.fontFamily = cs.fontFamily;
    mirror.style.lineHeight = cs.lineHeight;
    mirror.style.letterSpacing = cs.letterSpacing;
    mirror.style.padding = cs.padding;
    mirror.style.border = "none";
    mirror.style.boxSizing = cs.boxSizing;
    mirror.style.whiteSpace = "pre-wrap";
    mirror.style.wordWrap = "break-word";
    mirror.style.overflowWrap = cs.overflowWrap;
    mirror.style.textAlign = cs.textAlign;
    mirror.style.direction = cs.direction;
  }
  function applyFixedBox(el, rect) {
    el.style.position = "fixed";
    el.style.left = `${rect.left}px`;
    el.style.top = `${rect.top}px`;
    el.style.width = `${rect.width}px`;
    el.style.height = `${rect.height}px`;
  }
  function positionShell(shell, input) {
    applyFixedBox(shell, input.getBoundingClientRect());
  }
  function positionRectClipHost(layer, input) {
    const r = input.getBoundingClientRect();
    layer.style.display = "block";
    layer.style.position = "fixed";
    layer.style.left = `${r.left}px`;
    layer.style.top = `${r.top}px`;
    layer.style.width = `${r.width}px`;
    layer.style.height = `${r.height}px`;
    layer.style.overflow = "hidden";
    layer.style.pointerEvents = "none";
    layer.style.zIndex = "2147483644";
  }
  function getScrollableAncestors(el) {
    const out = [];
    let node = el;
    while (node) {
      const style = getComputedStyle(node);
      const scrollable = /(auto|scroll|overlay)/.test(style.overflowY) || /(auto|scroll|overlay)/.test(style.overflow);
      if (scrollable && node.scrollHeight > node.clientHeight + 2) {
        out.push(node);
      }
      node = node.parentElement;
    }
    return out;
  }
  function captionForTarget(target, typing, pinned, rejectedSelection) {
    if (rejectedSelection) {
      return "Selection too large \u2014 showing your instruction only (Esc to reset)";
    }
    if (typing && !pinned) {
      return "Finish typing \u2014 LeanPrompt will detect instruction vs reference";
    }
    if (pinned) {
      return "Locked selection \xB7 Esc or Clear to revert to instruction-only";
    }
    if (target.source === "user") {
      return "Your selection will be compressed";
    }
    if (target.source === "auto") {
      return "Instruction only \u2014 pasted reference will not be compressed";
    }
    return "Full prompt \xB7 select a smaller part to compress it";
  }
  function renderTextareaMirror(input, mirror, start, end, markClass) {
    const value = input.value;
    const safeStart = Math.max(0, Math.min(start, value.length));
    const safeEnd = Math.max(safeStart, Math.min(end, value.length));
    const before = escapeHtml(value.slice(0, safeStart));
    const mid = escapeHtml(value.slice(safeStart, safeEnd));
    const after = escapeHtml(value.slice(safeEnd));
    mirror.innerHTML = `${before}<mark class="${markClass}">${mid}</mark>${after}`;
    mirror.scrollTop = input.scrollTop;
    mirror.scrollLeft = input.scrollLeft;
  }
  function clearHighlightBoxes(layer) {
    layer.replaceChildren();
  }
  function isRangeConnected(range) {
    if (!range) return false;
    try {
      return range.startContainer.isConnected && range.endContainer.isConnected;
    } catch {
      return false;
    }
  }
  function highlightRangesFromDomRange(source) {
    const pieces = [];
    const ancestor = source.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? source.commonAncestorContainer : source.commonAncestorContainer.parentElement;
    if (!ancestor) return [source];
    const walker = document.createTreeWalker(ancestor, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        try {
          return source.intersectsNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        } catch {
          return NodeFilter.FILTER_REJECT;
        }
      }
    });
    let textNode = null;
    while (textNode = walker.nextNode()) {
      const startOff = textNode === source.startContainer ? source.startOffset : 0;
      const endOff = textNode === source.endContainer ? source.endOffset : textNode.data.length;
      if (endOff <= startOff) continue;
      const piece = document.createRange();
      try {
        piece.setStart(textNode, startOff);
        piece.setEnd(textNode, endOff);
        pieces.push(piece);
      } catch {
      }
    }
    return pieces.length > 0 ? pieces : [source];
  }
  function renderContentEditableBoxesFromRange(input, range, layer, userSelected = false) {
    clearHighlightBoxes(layer);
    positionRectClipHost(layer, input);
    const hostRect = input.getBoundingClientRect();
    let boxCount = 0;
    for (const piece of highlightRangesFromDomRange(range)) {
      for (const rect of Array.from(piece.getClientRects())) {
        if (rect.width < 1 || rect.height < 1) continue;
        const box = document.createElement("div");
        box.className = userSelected ? "lp-instruction-rect lp-instruction-rect-user" : "lp-instruction-rect";
        box.style.position = "absolute";
        box.style.left = `${rect.left - hostRect.left}px`;
        box.style.top = `${rect.top - hostRect.top}px`;
        box.style.width = `${rect.width}px`;
        box.style.height = `${rect.height}px`;
        layer.appendChild(box);
        boxCount += 1;
      }
    }
    return boxCount;
  }
  function textLengthToPoint(input, node, offset) {
    const range = document.createRange();
    range.selectNodeContents(input);
    range.setEnd(node, offset);
    return range.toString().length;
  }
  function findDomPointForPromptOffset(input, target) {
    const walker = document.createTreeWalker(input, NodeFilter.SHOW_TEXT);
    let lastPoint = null;
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const nodeStart = textLengthToPoint(input, node, 0);
      const nodeEnd = textLengthToPoint(input, node, node.data.length);
      if (target <= nodeStart) return { node, offset: 0 };
      if (target <= nodeEnd) {
        let lo = 0;
        let hi = node.data.length;
        while (lo < hi) {
          const mid = Math.floor((lo + hi) / 2);
          if (textLengthToPoint(input, node, mid) < target) lo = mid + 1;
          else hi = mid;
        }
        return { node, offset: lo };
      }
      lastPoint = { node, offset: node.data.length };
    }
    return lastPoint;
  }
  function contentEditableRangeFromOffsets(input, start, end) {
    const startPoint = findDomPointForPromptOffset(input, start);
    const endPoint = findDomPointForPromptOffset(input, end);
    if (!startPoint || !endPoint) return null;
    const range = document.createRange();
    try {
      range.setStart(startPoint.node, startPoint.offset);
      range.setEnd(endPoint.node, endPoint.offset);
      return range;
    } catch {
      return null;
    }
  }
  function renderContentEditableBoxesByOffsets(input, start, end, layer, userSelected = false) {
    const range = contentEditableRangeFromOffsets(input, start, end);
    if (!range) {
      clearHighlightBoxes(layer);
      return 0;
    }
    return renderContentEditableBoxesFromRange(input, range, layer, userSelected);
  }
  function readTextareaSelection(input) {
    const { selectionStart, selectionEnd } = input;
    if (selectionEnd > selectionStart + 1) {
      return { start: selectionStart, end: selectionEnd };
    }
    return null;
  }
  function clampRangeToInput(input, range) {
    const inputRange = document.createRange();
    try {
      inputRange.selectNodeContents(input);
    } catch {
      return null;
    }
    try {
      if (range.compareBoundaryPoints(Range.END_TO_START, inputRange) > 0 || range.compareBoundaryPoints(Range.START_TO_END, inputRange) < 0) {
        return null;
      }
      const clamped = range.cloneRange();
      if (clamped.compareBoundaryPoints(Range.START_TO_START, inputRange) < 0) {
        clamped.setStart(inputRange.startContainer, inputRange.startOffset);
      }
      if (clamped.compareBoundaryPoints(Range.END_TO_END, inputRange) > 0) {
        clamped.setEnd(inputRange.endContainer, inputRange.endOffset);
      }
      return clamped;
    } catch {
      return null;
    }
  }
  function readContentEditableSelection(input) {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return null;
    const range = clampRangeToInput(input, sel.getRangeAt(0));
    if (!range) return null;
    const selected = range.toString();
    if (selected.trim().length < 2) return null;
    const pre = document.createRange();
    pre.selectNodeContents(input);
    pre.setEnd(range.startContainer, range.startOffset);
    const start = pre.toString().length;
    const end = start + selected.length;
    if (end <= start) return null;
    return { offsets: { start, end }, domRange: range };
  }
  function readUserSelection(input) {
    if (input instanceof HTMLTextAreaElement) {
      const offsets = readTextareaSelection(input);
      return offsets ? { offsets } : null;
    }
    return readContentEditableSelection(input);
  }
  function clearBrowserSelection(input, range) {
    try {
      if (input instanceof HTMLTextAreaElement) {
        const collapseAt = range ? Math.max(range.start, Math.min(range.end, input.value.length)) : input.selectionEnd;
        input.setSelectionRange(collapseAt, collapseAt);
        return;
      }
      window.getSelection()?.removeAllRanges();
    } catch {
    }
  }
  function attachInstructionHighlight(input, readPrompt) {
    const shell = document.createElement("div");
    shell.className = "lp-instruction-shell";
    shell.setAttribute("aria-hidden", "true");
    const caption = document.createElement("div");
    caption.className = "lp-instruction-caption";
    const lockChip = document.createElement("button");
    lockChip.type = "button";
    lockChip.className = "lp-instruction-lock-chip";
    lockChip.textContent = "Select text to highlight what to compress";
    lockChip.hidden = true;
    const mirror = document.createElement("div");
    mirror.className = "lp-instruction-mirror";
    const rectLayer = document.createElement("div");
    rectLayer.className = "lp-instruction-rect-layer";
    shell.append(caption, mirror);
    document.body.appendChild(shell);
    document.body.appendChild(rectLayer);
    document.body.appendChild(lockChip);
    let mode = null;
    let pinnedUserRange = null;
    let pinnedHighlightRange = null;
    let autoTarget = null;
    let analysisReady = false;
    let isTyping = false;
    let rejectedSelection = false;
    let typingTimer = null;
    let lastPromptLen = 0;
    let suppressSelectionPinUntil = 0;
    let nativeSelectionClearFrame = null;
    const scrollCleanups = [];
    const recomputeAutoTarget = () => {
      const prompt = readPrompt();
      if (!prompt.trim()) {
        autoTarget = null;
        analysisReady = false;
        return;
      }
      autoTarget = getCompressionTargetSpan(prompt);
      analysisReady = true;
    };
    const effectiveTarget = () => {
      const prompt = readPrompt();
      if (!prompt.trim()) {
        return { active: false, instruction: "", context: "", start: 0, end: 0, source: "whole" };
      }
      if (pinnedUserRange && isValidUserCompressionRange(prompt, pinnedUserRange)) {
        const fromDomRange = pinnedHighlightRange && isRangeConnected(pinnedHighlightRange) ? pinnedHighlightRange.toString().trim() : "";
        const instruction = fromDomRange.length >= 3 ? fromDomRange : prompt.slice(pinnedUserRange.start, pinnedUserRange.end).trim();
        const before = prompt.slice(0, pinnedUserRange.start);
        const after = prompt.slice(pinnedUserRange.end);
        return {
          active: true,
          instruction,
          context: `${before}${after}`.trim(),
          start: pinnedUserRange.start,
          end: pinnedUserRange.end,
          source: "user"
        };
      }
      if (analysisReady && autoTarget) {
        return autoTarget;
      }
      return { active: false, instruction: prompt.trim(), context: "", start: 0, end: prompt.length, source: "whole" };
    };
    const renderTarget = (target, showHighlight) => {
      const prompt = readPrompt();
      const pinned = Boolean(pinnedUserRange);
      caption.textContent = captionForTarget(target, isTyping, pinned, rejectedSelection);
      const hasPartialAuto = target.source === "auto" && target.end - target.start < prompt.length * 0.95;
      lockChip.textContent = pinned || rejectedSelection ? "Highlight to compress \xB7 click to clear selection" : "Select text to highlight what to compress";
      lockChip.hidden = !prompt.trim() || !pinned && !rejectedSelection && !hasPartialAuto;
      const capRect = input.getBoundingClientRect();
      lockChip.style.position = "fixed";
      lockChip.style.left = `${capRect.left}px`;
      lockChip.style.top = `${Math.max(8, capRect.top - 28)}px`;
      if (!showHighlight) {
        shell.style.display = "none";
        rectLayer.style.display = "none";
        mirror.innerHTML = "";
        clearHighlightBoxes(rectLayer);
        return;
      }
      const markClass = target.source === "user" || pinned ? "lp-instruction-mark lp-instruction-mark-user" : "lp-instruction-mark";
      positionShell(shell, input);
      if (input instanceof HTMLTextAreaElement) {
        mode = "textarea";
        shell.style.display = "block";
        rectLayer.style.display = "none";
        syncMirrorStyles(input, mirror);
        renderTextareaMirror(input, mirror, target.start, target.end, markClass);
        return;
      }
      mode = "editable";
      shell.style.display = "none";
      if ((target.source === "user" || pinned) && isRangeConnected(pinnedHighlightRange) && renderContentEditableBoxesFromRange(input, pinnedHighlightRange, rectLayer, true) > 0) {
        return;
      }
      renderContentEditableBoxesByOffsets(
        input,
        target.start,
        target.end,
        rectLayer,
        target.source === "user" || pinned
      );
    };
    const refresh = () => {
      if (!input.isConnected) {
        shell.style.display = "none";
        rectLayer.style.display = "none";
        lockChip.hidden = true;
        return;
      }
      const prompt = readPrompt();
      if (!prompt.trim()) {
        shell.style.display = "none";
        rectLayer.style.display = "none";
        lockChip.hidden = true;
        pinnedUserRange = null;
        pinnedHighlightRange = null;
        autoTarget = null;
        analysisReady = false;
        isTyping = false;
        rejectedSelection = false;
        return;
      }
      if (pinnedUserRange && !isValidUserCompressionRange(prompt, pinnedUserRange)) {
        pinnedUserRange = null;
        pinnedHighlightRange = null;
      }
      const target = effectiveTarget();
      const partialAuto = target.source === "auto" && target.end - target.start < prompt.length * 0.95;
      const showHighlight = Boolean(pinnedUserRange) || analysisReady && !isTyping && partialAuto;
      renderTarget(target, showHighlight);
    };
    const refreshSoon = () => {
      requestAnimationFrame(refresh);
    };
    const scheduleAnalysis = (idleMs) => {
      isTyping = true;
      analysisReady = false;
      rejectedSelection = false;
      if (typingTimer) clearTimeout(typingTimer);
      typingTimer = setTimeout(() => {
        isTyping = false;
        recomputeAutoTarget();
        refresh();
      }, idleMs);
      refresh();
    };
    const markTyping = () => scheduleAnalysis(TYPING_IDLE_MS);
    const clearPin = () => {
      pinnedUserRange = null;
      pinnedHighlightRange = null;
      rejectedSelection = false;
      suppressSelectionPinUntil = Date.now() + 300;
      clearBrowserSelection(input);
      if (!isTyping) {
        recomputeAutoTarget();
      }
      refresh();
    };
    lockChip.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      clearPin();
    });
    lockChip.addEventListener("mouseup", (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
    lockChip.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
    const onInput = () => {
      const prompt = readPrompt();
      const len = prompt.length;
      const bigPaste = len - lastPromptLen > 60;
      lastPromptLen = len;
      if (!pinnedUserRange) {
        scheduleAnalysis(bigPaste ? PASTE_IDLE_MS : TYPING_IDLE_MS);
      } else {
        refreshSoon();
      }
    };
    const onScroll = () => {
      if (mode === "textarea" && input instanceof HTMLTextAreaElement) {
        mirror.scrollTop = input.scrollTop;
        mirror.scrollLeft = input.scrollLeft;
      }
      refreshSoon();
    };
    const onKeyDown = (e) => {
      if (e.key === "Escape") {
        clearPin();
      }
    };
    const tryPinFromSelection = () => {
      if (Date.now() < suppressSelectionPinUntil) return;
      const prompt = readPrompt();
      const selection = readUserSelection(input);
      if (!selection) return;
      const sel = selection.offsets;
      if (!isValidUserCompressionRange(prompt, sel)) {
        pinnedUserRange = null;
        pinnedHighlightRange = null;
        rejectedSelection = true;
        isTyping = false;
        if (typingTimer) clearTimeout(typingTimer);
        recomputeAutoTarget();
        refresh();
        return;
      }
      rejectedSelection = false;
      pinnedUserRange = sel;
      pinnedHighlightRange = selection.domRange?.cloneRange() ?? null;
      isTyping = false;
      if (typingTimer) clearTimeout(typingTimer);
      refresh();
      if (nativeSelectionClearFrame !== null) cancelAnimationFrame(nativeSelectionClearFrame);
      nativeSelectionClearFrame = requestAnimationFrame(() => {
        nativeSelectionClearFrame = null;
        if (!pinnedUserRange) return;
        clearBrowserSelection(input, sel);
        refresh();
      });
    };
    const onMouseUp = () => {
      setTimeout(tryPinFromSelection, 20);
    };
    const onBlur = () => {
      if (typingTimer) clearTimeout(typingTimer);
      isTyping = false;
      if (!pinnedUserRange) recomputeAutoTarget();
      refresh();
    };
    input.addEventListener("input", onInput, { passive: true });
    input.addEventListener("scroll", onScroll, { passive: true });
    input.addEventListener("focus", refresh, { passive: true });
    input.addEventListener("blur", onBlur, { passive: true });
    input.addEventListener("keydown", onKeyDown);
    document.addEventListener("mouseup", onMouseUp, { passive: true });
    for (const ancestor of getScrollableAncestors(input)) {
      ancestor.addEventListener("scroll", refreshSoon, { passive: true });
      scrollCleanups.push(() => ancestor.removeEventListener("scroll", refreshSoon));
    }
    window.addEventListener("scroll", refreshSoon, { passive: true, capture: true });
    window.addEventListener("resize", debounce(refresh, 80), { passive: true });
    const resizeObserver = new ResizeObserver(refreshSoon);
    resizeObserver.observe(input);
    let parent = input.parentElement;
    for (let i = 0; i < 5 && parent; i++) {
      resizeObserver.observe(parent);
      parent = parent.parentElement;
    }
    recomputeAutoTarget();
    refresh();
    return {
      refresh,
      getCompressionTarget: effectiveTarget,
      destroy: () => {
        if (typingTimer) clearTimeout(typingTimer);
        if (nativeSelectionClearFrame !== null) cancelAnimationFrame(nativeSelectionClearFrame);
        resizeObserver.disconnect();
        for (const off of scrollCleanups) off();
        input.removeEventListener("input", onInput);
        input.removeEventListener("scroll", onScroll);
        input.removeEventListener("focus", refresh);
        input.removeEventListener("blur", onBlur);
        input.removeEventListener("keydown", onKeyDown);
        document.removeEventListener("mouseup", onMouseUp);
        window.removeEventListener("scroll", refreshSoon, true);
        shell.remove();
        rectLayer.remove();
        lockChip.remove();
      }
    };
  }

  // src/content/index.ts
  var OVERLAY_POS_KEY = "leanprompt_overlay_position_v1";
  var OVERLAY_SIZE_KEY = "leanprompt_overlay_size_v1";
  var OPT_BUTTON_POS_KEY_PREFIX = "leanprompt_opt_button_position_v1";
  var RESPONSE_STYLE_KEY_PREFIX = "leanprompt_response_style_injected_v1";
  var CONCISE_TOGGLE_KEY = "leanprompt_concise_toggle_v1";
  var TOKEN_STATS_KEY_PREFIX = "leanprompt_token_stats_v1";
  var TOKEN_FILTER_KEY_PREFIX = "leanprompt_token_filter_v1";
  var LEANPROMPT_STYLE_ID = "leanprompt-overlay-styles";
  var RESPONSE_STYLE_INSTRUCTION = "Answer concisely.";
  var CONTEXT_WINDOWS = {
    "chatgpt-4o": 128e3,
    "chatgpt-4o-mini": 128e3,
    "chatgpt-4-turbo": 128e3,
    o1: 2e5,
    o3: 2e5,
    "claude-sonnet": 2e5,
    "claude-opus": 2e5,
    "claude-haiku": 2e5,
    "gemini-1.5-pro": 1e6,
    "gemini-1.5-flash": 1e6,
    "gemini-2.0": 1e6
  };
  var LLM_SELECT_LABELS = {
    "chatgpt-4o": "ChatGPT \xB7 4o (~128k)",
    "chatgpt-4o-mini": "ChatGPT \xB7 4o mini (~128k)",
    "chatgpt-4-turbo": "ChatGPT \xB7 4 Turbo (~128k)",
    o1: "ChatGPT \xB7 o1 (~200k)",
    o3: "ChatGPT \xB7 o3 (~200k)",
    "claude-sonnet": "Claude \xB7 Sonnet (~200k)",
    "claude-opus": "Claude \xB7 Opus (~200k)",
    "claude-haiku": "Claude \xB7 Haiku (~200k)",
    "gemini-1.5-pro": "Gemini \xB7 1.5 Pro (~1M)",
    "gemini-1.5-flash": "Gemini \xB7 1.5 Flash (~1M)",
    "gemini-2.0": "Gemini \xB7 2.0 (~1M)"
  };
  function llmSelectOptionsHtml(selected) {
    return Object.keys(CONTEXT_WINDOWS).map(
      (k) => `<option value="${k}" ${k === selected ? "selected" : ""}>${LLM_SELECT_LABELS[k] ?? k}</option>`
    ).join("");
  }
  var fileUploadState = { tokens: 0, names: [] };
  function escapeHtml2(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;");
  }
  function isExtensionContextInvalidated(error) {
    return error instanceof Error && /extension context invalidated|context invalidated/i.test(error.message);
  }
  function attachExtensionInvalidationGuards() {
    window.addEventListener("unhandledrejection", (event) => {
      if (isExtensionContextInvalidated(event.reason)) {
        event.preventDefault();
      }
    });
    window.addEventListener("error", (event) => {
      if (isExtensionContextInvalidated(event.error ?? new Error(String(event.message)))) {
        event.preventDefault();
      }
    });
  }
  function ensureLeanPromptStyles() {
    if (document.getElementById(LEANPROMPT_STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = LEANPROMPT_STYLE_ID;
    style.textContent = `
    .lp-opt-btn {
      position: absolute;
      z-index: 2147483647;
      width: 54px;
      height: 54px;
      border-radius: 50%;
      border: none;
      background: transparent;
      padding: 0;
      cursor: pointer;
      box-shadow: 0 4px 18px rgba(0,0,0,0.28), 0 0 0 0px rgba(153,102,238,0);
      transition: transform 140ms ease, box-shadow 140ms ease;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: visible;
    }
    .lp-opt-btn:hover { transform: scale(1.1); box-shadow: 0 6px 22px rgba(0,0,0,0.35), 0 0 0 4px rgba(153,102,238,0.22); }
    .lp-opt-btn:active { transform: scale(0.94); }
    .lp-opt-btn.lp-dragging { cursor: grabbing; transform: none; }
    .lp-opt-icon { width: 54px; height: 54px; display: block; border-radius: 50%; pointer-events: none; user-select: none; -webkit-user-drag: none; background: transparent; mix-blend-mode: multiply; }
    .lp-float-badge {
      position: absolute;
      top: 1px; right: 1px;
      width: 14px; height: 14px;
      border-radius: 50%;
      background: #ef4444;
      border: 2.5px solid white;
      box-shadow: 0 1px 4px rgba(0,0,0,0.3);
      display: none;
      pointer-events: none;
    }
    .lp-badge-visible { display: block !important; }

    .lp-instruction-shell {
      position: fixed;
      z-index: 2147483645;
      pointer-events: none;
      overflow: hidden;
      border-radius: 12px;
      box-sizing: border-box;
    }
    .lp-instruction-lock-chip {
      position: fixed;
      z-index: 2147483646;
      pointer-events: auto;
      font-size: 10px;
      font-weight: 600;
      font-family: system-ui, sans-serif;
      padding: 4px 10px;
      border-radius: 8px;
      border: 1px solid rgba(124, 58, 237, 0.5);
      background: #f5f3ff;
      color: #5b21b6;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(109, 40, 217, 0.15);
    }
    .lp-instruction-lock-chip:hover { background: #ede9fe; }
    .lp-instruction-caption {
      position: absolute;
      top: -22px;
      left: 0;
      font-size: 10px;
      font-weight: 600;
      color: #7c3aed;
      background: rgba(255, 255, 255, 0.95);
      padding: 2px 8px;
      border-radius: 6px;
      border: 1px solid rgba(139, 92, 246, 0.35);
      box-shadow: 0 2px 8px rgba(109, 40, 217, 0.12);
      white-space: nowrap;
      font-family: system-ui, sans-serif;
    }
    .lp-instruction-mirror {
      width: 100%;
      height: 100%;
      overflow: auto;
      color: transparent;
      background: transparent;
      scrollbar-width: none;
    }
    .lp-instruction-mirror::-webkit-scrollbar { display: none; }
    .lp-instruction-mirror .lp-instruction-mark {
      color: transparent;
      background: rgba(139, 92, 246, 0.28);
      border-radius: 3px;
      box-shadow: inset 0 0 0 1px rgba(124, 58, 237, 0.45);
    }
    .lp-instruction-mirror .lp-instruction-mark-user,
    .lp-instruction-rect.lp-instruction-rect-user {
      background: rgba(124, 58, 237, 0.38);
      box-shadow: inset 0 0 0 1px rgba(109, 40, 217, 0.65);
    }
    .lp-instruction-rect-layer {
      position: fixed;
      inset: 0;
      z-index: 2147483644;
      pointer-events: none;
    }
    .lp-instruction-rect {
      position: fixed;
      background: rgba(139, 92, 246, 0.28);
      border-radius: 3px;
      box-shadow: inset 0 0 0 1px rgba(124, 58, 237, 0.45);
      pointer-events: none;
    }
    .lp-update-banner {
      position: fixed;
      right: 16px;
      bottom: 16px;
      z-index: 2147483647;
      width: min(360px, calc(100vw - 32px));
      padding: 12px;
      border-radius: 14px;
      border: 1px solid rgba(139, 92, 246, 0.35);
      background: rgba(255, 255, 255, 0.98);
      color: #241244;
      box-shadow: 0 12px 34px rgba(24, 12, 48, 0.2);
      font-family: system-ui, sans-serif;
      font-size: 13px;
    }
    .lp-update-title { font-weight: 750; margin-bottom: 4px; color: #5b21b6; }
    .lp-update-body { line-height: 1.35; margin-bottom: 10px; }
    .lp-update-actions { display: flex; gap: 8px; justify-content: flex-end; }
    .lp-update-actions button,
    .lp-update-actions a {
      border-radius: 9px;
      border: 1px solid rgba(124, 58, 237, 0.3);
      padding: 6px 10px;
      font-size: 12px;
      font-weight: 650;
      text-decoration: none;
      cursor: pointer;
      font-family: inherit;
    }
    .lp-update-actions a {
      background: #7c3aed;
      color: white;
      border-color: #7c3aed;
    }
    .lp-update-actions button {
      background: #f5f3ff;
      color: #5b21b6;
    }

    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@600;700&display=swap');
    .lp-overlay {
      position: fixed;
      z-index: 2147483647;
      width: min(340px, calc(100vw - 18px));
      min-width: 290px;
      max-width: min(560px, calc(100vw - 18px));
      min-height: 280px;
      max-height: min(86vh, 760px);
      resize: both;
      color: #e2e8f0;
      border-radius: 20px;
      border: 1px solid rgba(139, 92, 246, 0.18);
      background: linear-gradient(160deg, #0d1117 0%, #0a0f1e 100%);
      box-shadow: 0 24px 64px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(139, 92, 246, 0.15) inset, 0 0 40px rgba(76, 29, 149, 0.18);
      backdrop-filter: blur(12px);
      font-family: 'DM Sans', Inter, system-ui, -apple-system, sans-serif;
      overflow: auto;
    }
    .lp-overlay-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 10px;
      padding: 11px 14px;
      border-bottom: 1px solid rgba(139, 92, 246, 0.12);
      cursor: grab;
      user-select: none;
      background: rgba(10, 15, 30, 0.6);
      border-radius: 20px 20px 0 0;
    }
    .lp-overlay-title { font-size: 15px; font-weight: 700; line-height: 1.2; color: #f8fafc; font-family: 'Outfit', 'DM Sans', sans-serif; }
    .lp-overlay-title span { color: #a78bfa; }
    .lp-overlay-subtitle { font-size: 10px; color: #64748b; line-height: 1.25; margin-top: 1px; }
    .lp-overlay-body { padding: 12px 14px 14px; display: grid; gap: 10px; }
    .lp-summary {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      flex-wrap: wrap;
    }
    .lp-summary-intent {
      font-size: 11px;
      color: #94a3b8;
      line-height: 1.35;
      text-transform: capitalize;
    }
    .lp-summary-badge {
      font-size: 11px;
      font-weight: 600;
      padding: 4px 10px;
      border-radius: 999px;
      color: #ede9fe;
      background: rgba(139, 92, 246, 0.14);
      border: 1px solid rgba(167, 139, 250, 0.28);
      white-space: nowrap;
    }
    .lp-card {
      border: 1px solid rgba(139, 92, 246, 0.1);
      border-radius: 14px;
      padding: 10px 12px;
      background: rgba(15, 23, 42, 0.5);
    }
    .lp-card-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.07em;
      text-transform: uppercase;
      color: #64748b;
    }
    .lp-card-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 8px;
    }
    .lp-card-head .lp-card-label { margin-bottom: 0; }
    .lp-kpi-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }
    .lp-kpi {
      padding: 7px 8px;
      border-radius: 8px;
      background: rgba(2, 6, 23, 0.45);
      border: 1px solid rgba(148, 163, 184, 0.1);
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
    }
    .lp-kpi-val {
      font-size: 14px;
      font-weight: 650;
      color: #f1f5f9;
      font-variant-numeric: tabular-nums;
      line-height: 1.2;
    }
    .lp-kpi-lbl { font-size: 10px; color: #94a3b8; }
    .lp-card-foot {
      margin-top: 10px;
      padding-top: 8px;
      border-top: 1px solid rgba(148, 163, 184, 0.1);
      font-size: 10px;
      color: #64748b;
      line-height: 1.45;
    }
    .lp-select {
      width: 100%;
      padding: 5px 7px;
      border-radius: 8px;
      background: rgba(2, 6, 23, 0.72);
      color: #e5e7eb;
      border: 1px solid rgba(148, 163, 184, 0.22);
      font-size: 11px;
      font-family: inherit;
      cursor: pointer;
    }
    .lp-select:focus {
      outline: none;
      border-color: rgba(167, 139, 250, 0.45);
      box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.18);
    }
    .lp-select-inline { width: auto; min-width: 118px; flex-shrink: 0; }
    .lp-stat-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
    }
    .lp-stat-row.lp-stat-row-3 {
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 8px;
    }
    .lp-stat-num {
      display: block;
      font-size: 13px;
      font-weight: 650;
      font-variant-numeric: tabular-nums;
      color: #f8fafc;
      line-height: 1.25;
    }
    .lp-stat-lbl { font-size: 10px; color: #94a3b8; }
    .lp-hint {
      font-size: 10px;
      color: #64748b;
      line-height: 1.4;
      margin-top: 8px;
    }
    .lp-textarea {
      width: 100%;
      min-height: 96px;
      resize: vertical;
      border: 1px solid rgba(139, 92, 246, 0.2);
      border-radius: 14px;
      background: rgba(2, 6, 23, 0.6);
      color: #f1f5f9;
      padding: 10px 12px;
      font-size: 12.5px;
      line-height: 1.5;
      outline: none;
      font-family: 'DM Sans', system-ui, sans-serif;
    }
    .lp-textarea:focus { border-color: rgba(139, 92, 246, 0.6); box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15); }
    .lp-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .lp-btn {
      border-radius: 12px;
      padding: 9px 10px;
      border: 1px solid rgba(148, 163, 184, 0.18);
      color: #e2e8f0;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: 'DM Sans', system-ui, sans-serif;
    }
    .lp-btn-primary {
      background: linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%);
      border-color: rgba(167, 139, 250, 0.4);
      color: #fff;
      box-shadow: 0 4px 14px rgba(109, 40, 217, 0.4), 0 1px 3px rgba(0,0,0,0.3);
    }
    .lp-btn-primary:hover { background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); box-shadow: 0 6px 20px rgba(109, 40, 217, 0.5); }
    .lp-btn-secondary { background: rgba(30, 41, 59, 0.7); }
    .lp-btn-reject { background: transparent; color: #fca5a5; border-color: rgba(248, 113, 113, 0.25); }
    .lp-btn-reject:hover { background: rgba(248, 113, 113, 0.06); border-color: rgba(248, 113, 113, 0.45); color: #fecaca; }
    .lp-reject-chips { display: flex; flex-wrap: wrap; gap: 6px; padding: 8px 0 2px; }
    .lp-chip { font-size: 11px; font-weight: 500; padding: 5px 10px; border-radius: 99px; border: 1px solid rgba(248,113,113,0.3); background: rgba(248,113,113,0.07); color: #fca5a5; cursor: pointer; transition: background 120ms, border-color 120ms; }
    .lp-chip:hover { background: rgba(248,113,113,0.15); border-color: rgba(248,113,113,0.55); }
    .lp-chip-skip { border-color: rgba(148,163,184,0.2); background: transparent; color: #64748b; }
    .lp-chip-skip:hover { border-color: rgba(148,163,184,0.4); color: #94a3b8; }
    .lp-reject-label { font-size: 11px; color: #94a3b8; font-weight: 500; padding-top: 4px; }
    .lp-btn-back { background: transparent; color: #94a3b8; border-color: rgba(148,163,184,0.18); font-size: 11px; }
    .lp-btn-back:hover { color: #cbd5e1; border-color: rgba(148,163,184,0.35); }
    .lp-btn:hover { transform: translateY(-1px); }
    .lp-btn:active { transform: translateY(0); }
    .lp-btn:focus-visible { outline: 2px solid rgba(167, 139, 250, 0.8); outline-offset: 1px; }

    .lp-reset {
      border: 1px solid rgba(139, 92, 246, 0.2);
      background: transparent;
      color: #94a3b8;
      font-size: 11px;
      border-radius: 10px;
      padding: 5px 9px;
      cursor: pointer;
      font-family: 'DM Sans', system-ui, sans-serif;
    }
    .lp-reset:hover { border-color: rgba(167, 139, 250, 0.5); color: #f1f5f9; }

    .lp-mobile {
      left: 12px !important;
      right: 12px !important;
      top: auto !important;
      bottom: 12px !important;
      width: auto !important;
      max-height: min(78vh, 560px);
    }
    .lp-mobile.lp-overlay {
      resize: none;
      min-width: 0;
      min-height: 0;
    }
    .lp-mobile .lp-overlay-header { cursor: default; }
    .lp-mobile .lp-actions { grid-template-columns: 1fr; }
    .lp-mobile .lp-kpi-grid { grid-template-columns: 1fr; }
    .lp-mobile .lp-card-head { flex-wrap: wrap; align-items: flex-start; }
    .lp-mobile .lp-select-inline { width: 100%; min-width: 0; }
    .lp-mobile .lp-stat-row.lp-stat-row-3 { grid-template-columns: 1fr; }

    .lp-signin-nudge {
      display: flex; align-items: center; justify-content: space-between;
      gap: 8px; padding: 8px 10px; margin-bottom: 2px;
      border-radius: 10px; border: 1px solid rgba(167,139,250,0.25);
      background: rgba(109,40,217,0.1);
      font-size: 11px; color: #c4b5fd;
    }
    .lp-signin-nudge-btn {
      flex-shrink: 0; font-size: 11px; font-weight: 650;
      padding: 4px 10px; border-radius: 8px; cursor: pointer;
      border: 1px solid rgba(167,139,250,0.45);
      background: rgba(124,58,237,0.35); color: #e9d5ff;
      white-space: nowrap;
    }
    .lp-signin-nudge-btn:hover { background: rgba(124,58,237,0.55); }

    .lp-login-tabs { display: flex; gap: 4px; }
    .lp-login-tab {
      flex: 1; padding: 7px; border-radius: 8px;
      border: 1px solid rgba(148,163,184,0.2); background: transparent;
      color: #64748b; font-size: 12px; font-weight: 500;
      cursor: pointer; font-family: inherit; transition: all 120ms ease;
    }
    .lp-login-tab:hover:not(.lp-login-tab-active) { color: #cbd5e1; border-color: rgba(148,163,184,0.35); }
    .lp-login-tab-active {
      background: rgba(124,58,237,0.22);
      border-color: rgba(167,139,250,0.45); color: #e9d5ff;
    }
    .lp-auth-error {
      font-size: 11px; color: #fca5a5;
      background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.22);
      border-radius: 8px; padding: 7px 9px;
    }
    .lp-auth-form { display: grid; gap: 7px; }
    .lp-input {
      width: 100%; padding: 8px 10px; border-radius: 8px;
      background: rgba(2,6,23,0.72); border: 1px solid rgba(148,163,184,0.22);
      color: #f8fafc; font-size: 12px; font-family: inherit;
      outline: none; box-sizing: border-box;
    }
    .lp-input:focus { border-color: rgba(167,139,250,0.45); box-shadow: 0 0 0 2px rgba(139,92,246,0.18); }
    .lp-input::placeholder { color: #475569; }
    .lp-auth-divider {
      display: flex; align-items: center; gap: 8px;
      font-size: 11px; color: #475569;
    }
    .lp-auth-divider::before, .lp-auth-divider::after {
      content: ''; flex: 1; height: 1px; background: rgba(148,163,184,0.15);
    }
    .lp-btn-google {
      display: flex; align-items: center; justify-content: center; gap: 7px;
      width: 100%; padding: 8px; background: rgba(30,41,59,0.8);
      border-color: rgba(148,163,184,0.28); color: #e5e7eb;
    }
    .lp-btn-google:hover { background: rgba(51,65,85,0.8); border-color: rgba(148,163,184,0.45); }

    .lp-concise-toggle {
      position: absolute;
      z-index: 2147483646;
      padding: 3px 9px;
      border-radius: 99px;
      border: 1px solid rgba(148,163,184,0.3);
      background: rgba(7,11,20,0.88);
      color: #64748b;
      font-size: 10px;
      font-weight: 650;
      font-family: Inter, system-ui, -apple-system, sans-serif;
      cursor: pointer;
      transition: all 140ms ease;
      white-space: nowrap;
      backdrop-filter: blur(6px);
      letter-spacing: 0.04em;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      line-height: 1.5;
    }
    .lp-concise-toggle:hover {
      border-color: rgba(167,139,250,0.45);
      color: #c4b5fd;
    }
    .lp-concise-toggle[data-on="1"] {
      background: rgba(109,40,217,0.8);
      border-color: rgba(167,139,250,0.7);
      color: #f3e8ff;
      box-shadow: 0 2px 10px rgba(76,29,149,0.45);
    }
  `;
    document.head.appendChild(style);
  }
  function clamp(value, min, max) {
    return Math.max(min, Math.min(value, max));
  }
  function readStoredOverlayPosition() {
    try {
      const raw = localStorage.getItem(OVERLAY_POS_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!Number.isFinite(parsed.x) || !Number.isFinite(parsed.y)) return null;
      return parsed;
    } catch {
      return null;
    }
  }
  function readStoredOverlaySize() {
    try {
      const raw = localStorage.getItem(OVERLAY_SIZE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!Number.isFinite(parsed.width) || !Number.isFinite(parsed.height)) return null;
      return parsed;
    } catch {
      return null;
    }
  }
  function storeOverlaySize(size) {
    try {
      localStorage.setItem(OVERLAY_SIZE_KEY, JSON.stringify(size));
    } catch {
    }
  }
  function storeOverlayPosition(pos) {
    try {
      localStorage.setItem(OVERLAY_POS_KEY, JSON.stringify(pos));
    } catch {
    }
  }
  function getOptButtonPosKey() {
    return `${OPT_BUTTON_POS_KEY_PREFIX}:${window.location.hostname}`;
  }
  function readStoredOptimizeButtonPosition() {
    try {
      const raw = localStorage.getItem(getOptButtonPosKey());
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!Number.isFinite(parsed.x) || !Number.isFinite(parsed.y)) return null;
      return parsed;
    } catch {
      return null;
    }
  }
  function storeOptimizeButtonPosition(pos) {
    try {
      localStorage.setItem(getOptButtonPosKey(), JSON.stringify(pos));
    } catch {
    }
  }
  function readConciseToggle() {
    try {
      return localStorage.getItem(CONCISE_TOGGLE_KEY) === "1";
    } catch {
      return false;
    }
  }
  function writeConciseToggle(val) {
    try {
      localStorage.setItem(CONCISE_TOGGLE_KEY, val ? "1" : "0");
    } catch {
    }
  }
  function positionButtonForInput(button, input, forced) {
    const margin = 8;
    const rect = input.getBoundingClientRect();
    const fallbackX = window.scrollX + rect.right - 190;
    const fallbackY = window.scrollY + rect.top - 36;
    const targetX = forced?.x ?? fallbackX;
    const targetY = forced?.y ?? fallbackY;
    const maxX = Math.max(margin, window.scrollX + window.innerWidth - button.offsetWidth - margin);
    const maxY = Math.max(margin, window.scrollY + window.innerHeight - button.offsetHeight - margin);
    button.style.left = `${clamp(targetX, margin, maxX)}px`;
    button.style.top = `${clamp(targetY, margin, maxY)}px`;
  }
  function countWordDiffs(before, after) {
    const wordsAfter = new Set(after.toLowerCase().match(/[a-z][a-z']*/gi) ?? []);
    const wordsBefore = before.toLowerCase().match(/[a-z][a-z']*/gi) ?? [];
    let changed = 0;
    for (const w of wordsBefore) {
      if (!wordsAfter.has(w)) changed += 1;
    }
    return changed;
  }
  function readInputValue(input) {
    if (input instanceof HTMLTextAreaElement) return input.value;
    return input.innerText ?? input.textContent ?? "";
  }
  function writeInputValue(input, value) {
    if (input instanceof HTMLTextAreaElement) {
      input.value = value;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    input.textContent = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }
  function applyOptimizedPromptToTextarea(input, optimized) {
    writeInputValue(input, optimized);
  }
  function getResponseStyleKey() {
    return `${RESPONSE_STYLE_KEY_PREFIX}:${window.location.hostname}`;
  }
  function getTokenStatsKey() {
    return `${TOKEN_STATS_KEY_PREFIX}:${window.location.hostname}`;
  }
  function getTokenFilterKey() {
    return `${TOKEN_FILTER_KEY_PREFIX}:${window.location.hostname}`;
  }
  function normalizeStatsBucket(raw) {
    return {
      used: Number.isFinite(Number(raw?.used)) ? Number(raw?.used) : 0,
      saved: Number.isFinite(Number(raw?.saved)) ? Number(raw?.saved) : 0,
      outputEst: Number.isFinite(Number(raw?.outputEst)) ? Number(raw?.outputEst) : 0
    };
  }
  function monthKey(date = /* @__PURE__ */ new Date()) {
    const y = date.getUTCFullYear();
    const m = String(date.getUTCMonth() + 1).padStart(2, "0");
    return `${y}-${m}`;
  }
  function daysInCurrentMonth(date = /* @__PURE__ */ new Date()) {
    return new Date(date.getUTCFullYear(), date.getUTCMonth() + 1, 0).getUTCDate();
  }
  function dayOfMonth(date = /* @__PURE__ */ new Date()) {
    return date.getUTCDate();
  }
  function defaultTokenStatsState() {
    return { allTime: normalizeStatsBucket({}), byMonth: {} };
  }
  function inferDefaultLlmId(hostname) {
    if (hostname.includes("claude.ai")) return "claude-sonnet";
    if (hostname.includes("gemini.google.com")) return "gemini-1.5-pro";
    return "chatgpt-4o";
  }
  function readTokenFilter() {
    try {
      const raw = localStorage.getItem(getTokenFilterKey());
      return raw === "all" ? "all" : "month";
    } catch {
      return "month";
    }
  }
  function writeTokenFilter(filter) {
    try {
      localStorage.setItem(getTokenFilterKey(), filter);
    } catch {
    }
  }
  function readTokenStatsState() {
    try {
      const raw = localStorage.getItem(getTokenStatsKey());
      if (!raw) return defaultTokenStatsState();
      const parsed = JSON.parse(raw);
      if (typeof parsed.used === "number" || typeof parsed.saved === "number") {
        const base = normalizeStatsBucket(parsed);
        const key = monthKey();
        return { allTime: base, byMonth: { [key]: { ...base } } };
      }
      const allTime = normalizeStatsBucket(parsed.allTime);
      const rawMonths = parsed.byMonth ?? {};
      const byMonth = {};
      for (const [k, v] of Object.entries(rawMonths)) {
        byMonth[k] = normalizeStatsBucket(v);
      }
      return {
        allTime,
        byMonth
      };
    } catch {
      return defaultTokenStatsState();
    }
  }
  function writeTokenStatsState(next) {
    try {
      localStorage.setItem(getTokenStatsKey(), JSON.stringify(next));
    } catch {
    }
  }
  function getVisibleTokenStats(state, filter) {
    if (filter === "all") return state.allTime;
    const currentMonth = monthKey();
    return normalizeStatsBucket(state.byMonth[currentMonth]);
  }
  function estimateMonthUsage(bucket) {
    const now = /* @__PURE__ */ new Date();
    const elapsedDays = Math.max(1, dayOfMonth(now));
    const totalDays = daysInCurrentMonth(now);
    const projectedUsed = Math.round(bucket.used / elapsedDays * totalDays);
    const projectedSaved = Math.round(bucket.saved / elapsedDays * totalDays);
    const projectedOutput = Math.round(bucket.outputEst / elapsedDays * totalDays);
    const projectedTotalFootprint = projectedUsed + projectedOutput;
    return { projectedUsed, projectedSaved, projectedOutput, projectedTotalFootprint };
  }
  function updateTokenStats(beforeTokens, afterTokens) {
    const current = readTokenStatsState();
    const key = monthKey();
    const existingMonth = normalizeStatsBucket(current.byMonth[key]);
    const deltaUsed = Math.max(0, afterTokens);
    const deltaSaved = Math.max(0, beforeTokens - afterTokens);
    const next = {
      allTime: {
        used: current.allTime.used + deltaUsed,
        saved: current.allTime.saved + deltaSaved,
        outputEst: current.allTime.outputEst
      },
      byMonth: {
        ...current.byMonth,
        [key]: {
          used: existingMonth.used + deltaUsed,
          saved: existingMonth.saved + deltaSaved,
          outputEst: existingMonth.outputEst
        }
      }
    };
    writeTokenStatsState(next);
    return next;
  }
  function updateOutputEstStats(delta) {
    const d = Math.max(0, Math.round(delta));
    if (!d) return readTokenStatsState();
    const current = readTokenStatsState();
    const key = monthKey();
    const existingMonth = normalizeStatsBucket(current.byMonth[key]);
    const next = {
      allTime: {
        ...current.allTime,
        outputEst: current.allTime.outputEst + d
      },
      byMonth: {
        ...current.byMonth,
        [key]: {
          ...existingMonth,
          outputEst: existingMonth.outputEst + d
        }
      }
    };
    writeTokenStatsState(next);
    return next;
  }
  function threadAssistantBaselineKey() {
    return `leanprompt_thread_asst:${window.location.hostname}:${window.location.pathname}`;
  }
  function applyAssistantOutputDeltaFromTotal(assistantTotalNow) {
    try {
      const key = threadAssistantBaselineKey();
      const raw = sessionStorage.getItem(key);
      if (raw === null) {
        sessionStorage.setItem(key, String(assistantTotalNow));
        return;
      }
      const prev = Number(raw);
      if (!Number.isFinite(prev)) {
        sessionStorage.setItem(key, String(assistantTotalNow));
        return;
      }
      if (assistantTotalNow > prev) {
        updateOutputEstStats(assistantTotalNow - prev);
        sessionStorage.setItem(key, String(assistantTotalNow));
      }
    } catch {
    }
  }
  function collectInnerTexts(nodes) {
    const texts = [];
    for (const el of Array.from(nodes)) {
      const t = el.textContent?.trim();
      if (t && t.length > 0) texts.push(t);
    }
    return texts;
  }
  function scrapeChatTurnTexts(role) {
    const host = window.location.hostname;
    if (host.includes("chatgpt.com") || host.includes("chat.openai.com")) {
      const roots = document.querySelectorAll(`[data-message-author-role="${role}"]`);
      const chunks = [];
      roots.forEach((root) => {
        const prose = root.querySelector(".markdown, .prose");
        const text = (prose ?? root).textContent?.trim() ?? "";
        if (text.length > 0) chunks.push(text);
      });
      return chunks;
    }
    if (host.includes("claude.ai")) {
      const userSelectors = ['[data-testid="user-message"]', '[data-message-role="user"]'];
      const asstSelectors = ['[data-testid="assistant-message"]', '[data-message-role="assistant"]'];
      const selectors = role === "user" ? userSelectors : asstSelectors;
      for (const sel of selectors) {
        const els = document.querySelectorAll(sel);
        if (els.length > 0) return collectInnerTexts(Array.from(els));
      }
      return [];
    }
    if (host.includes("gemini.google.com")) {
      const userSelectors = ["user-query", "[data-node-type='user-query']"];
      const asstSelectors = ["model-response", "message-content", ".model-response-text"];
      const selectors = role === "user" ? userSelectors : asstSelectors;
      for (const sel of selectors) {
        const els = document.querySelectorAll(sel);
        if (els.length > 0) return collectInnerTexts(Array.from(els));
      }
      return [];
    }
    return [];
  }
  function estimateThreadTokensFromDom() {
    const userChunks = scrapeChatTurnTexts("user");
    const asstChunks = scrapeChatTurnTexts("assistant");
    const user = userChunks.reduce((s, t) => s + estimateTokens(t), 0);
    const assistant = asstChunks.reduce((s, t) => s + estimateTokens(t), 0);
    return { user, assistant };
  }
  function sumAssistantTokensEstimate() {
    return estimateThreadTokensFromDom().assistant;
  }
  function detectLlmKeyFromPage() {
    const h = window.location.hostname;
    const hay = `${document.title}
${document.body?.innerText ?? ""}`.slice(0, 12e4);
    if (h.includes("claude.ai")) {
      if (/\bopus\b/i.test(hay)) return "claude-opus";
      if (/\bhaiku\b/i.test(hay)) return "claude-haiku";
      return "claude-sonnet";
    }
    if (h.includes("gemini.google.com")) {
      if (/flash/i.test(hay)) return "gemini-1.5-flash";
      if (/gemini\s*2[\.\s]*0|2\.0\s*flash/i.test(hay)) return "gemini-2.0";
      return "gemini-1.5-pro";
    }
    if (/\bo3\b/i.test(hay)) return "o3";
    if (/\bo1\b/i.test(hay)) return "o1";
    if (/4o-mini/i.test(hay)) return "chatgpt-4o-mini";
    if (/gpt-?4\.5|4\.5/i.test(hay)) return "chatgpt-4o";
    if (/4o/i.test(hay)) return "chatgpt-4o";
    if (/turbo/i.test(hay)) return "chatgpt-4-turbo";
    return inferDefaultLlmId(h);
  }
  function refreshPanelEstimates(panel, result, llmLocked) {
    if (!panel.isConnected) return;
    const detected = detectLlmKeyFromPage();
    const select = panel.querySelector('[data-lp-action="llm-select"]');
    if (select && !llmLocked.current && CONTEXT_WINDOWS[detected]) {
      select.value = detected;
    }
    const llmKey = select?.value ?? detected;
    const ctx = CONTEXT_WINDOWS[llmKey] ?? CONTEXT_WINDOWS[inferDefaultLlmId(window.location.hostname)];
    const promptTok = result.tokenEstimateAfter;
    const fileTok = fileUploadState.tokens;
    const thread = estimateThreadTokensFromDom();
    const threadTotal = thread.user + thread.assistant;
    const totalInputTok = promptTok + fileTok;
    const pctPrompt = Math.min(100, Number((totalInputTok / ctx * 100).toFixed(2)));
    const pctThread = threadTotal > 0 ? Math.min(100, Number((threadTotal / ctx * 100).toFixed(2))) : pctPrompt;
    const note = panel.querySelector("[data-lp-context-note]");
    if (note) {
      const fileSuffix = fileTok > 0 ? ` + ~${fileTok.toLocaleString()} file tokens` : "";
      note.textContent = threadTotal > 0 ? `This message${fileSuffix} ~${pctPrompt}% \xB7 visible thread ~${pctThread}% of ~${ctx.toLocaleString()} context.` : `This message${fileSuffix} ~${pctPrompt}% of ~${ctx.toLocaleString()} context.`;
    }
    const threadEl = panel.querySelector("[data-lp-thread-est]");
    if (threadEl) {
      threadEl.textContent = threadTotal > 0 ? `Visible thread (est.): ${thread.user.toLocaleString()} prompt \xB7 ${thread.assistant.toLocaleString()} reply \xB7 ${threadTotal.toLocaleString()} combined` : "Visible thread (est.): \u2014 (open a chat or refresh after replies load)";
    }
    applyAssistantOutputDeltaFromTotal(thread.assistant);
  }
  function markResponseStyleInjected() {
    sessionStorage.setItem(getResponseStyleKey(), "1");
  }
  var LP_LOGO_SVG = `<img class="lp-opt-icon" src="${chrome.runtime.getURL("icons/icon48.png")}" alt="LeanPrompt" aria-hidden="true" draggable="false" />`;
  function injectConciseToggleButton(mainBtn) {
    ensureLeanPromptStyles();
    const toggle = document.createElement("button");
    toggle.className = "lp-concise-toggle";
    toggle.setAttribute("aria-label", "Toggle concise answer mode");
    const sync = () => {
      const on = readConciseToggle();
      toggle.setAttribute("data-on", on ? "1" : "0");
      toggle.title = on ? 'Concise mode ON \u2014 appends "answer concisely" to prompt' : "Concise mode OFF \u2014 click to enable";
      toggle.textContent = on ? "\u2726 concise" : "\u25C7 concise";
    };
    sync();
    const reposition = () => {
      const left = Number.parseFloat(mainBtn.style.left) || 0;
      const top = Number.parseFloat(mainBtn.style.top) || 0;
      toggle.style.left = `${left}px`;
      toggle.style.top = `${top + 62}px`;
    };
    reposition();
    toggle.addEventListener("click", () => {
      writeConciseToggle(!readConciseToggle());
      sync();
    });
    const observer = new MutationObserver(reposition);
    observer.observe(mainBtn, { attributes: true, attributeFilter: ["style"] });
    document.body.appendChild(toggle);
    return toggle;
  }
  function injectLeanPromptButton(input, storedPosition) {
    ensureLeanPromptStyles();
    const btn = document.createElement("button");
    btn.className = "lp-opt-btn";
    btn.setAttribute("aria-label", "Optimize with LeanPrompt");
    btn.innerHTML = `${LP_LOGO_SVG}<span class="lp-float-badge"></span>`;
    document.body.appendChild(btn);
    positionButtonForInput(btn, input, storedPosition);
    void (async () => {
      try {
        const state = await getAuthStateFromBackground();
        if (state.ok && state.configured && !state.loggedIn) {
          btn.querySelector(".lp-float-badge")?.classList.add("lp-badge-visible");
        }
      } catch {
      }
    })();
    return btn;
  }
  function makeOptimizeButtonDraggable(button, getCurrentInput, onClickIntent) {
    let isDragging = false;
    let dragMoved = false;
    let pointerId = null;
    let offsetX = 0;
    let offsetY = 0;
    const onPointerDown = (event) => {
      pointerId = event.pointerId;
      const rect = button.getBoundingClientRect();
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      dragMoved = false;
      isDragging = true;
      button.classList.add("lp-dragging");
      button.setPointerCapture(event.pointerId);
    };
    const onPointerMove = (event) => {
      if (!isDragging) return;
      const margin = 8;
      const maxX = Math.max(margin, window.scrollX + window.innerWidth - button.offsetWidth - margin);
      const maxY = Math.max(margin, window.scrollY + window.innerHeight - button.offsetHeight - margin);
      const x = clamp(window.scrollX + event.clientX - offsetX, margin, maxX);
      const y = clamp(window.scrollY + event.clientY - offsetY, margin, maxY);
      button.style.left = `${x}px`;
      button.style.top = `${y}px`;
      if (!dragMoved) {
        const movedDistance = Math.abs(event.movementX) + Math.abs(event.movementY);
        if (movedDistance > 2) dragMoved = true;
      }
    };
    const onPointerUp = () => {
      if (!isDragging) return;
      isDragging = false;
      button.classList.remove("lp-dragging");
      if (pointerId !== null) {
        try {
          button.releasePointerCapture(pointerId);
        } catch {
        }
      }
      const x = Number.parseFloat(button.style.left) || 0;
      const y = Number.parseFloat(button.style.top) || 0;
      storeOptimizeButtonPosition({ x, y });
      if (!dragMoved) onClickIntent();
    };
    button.addEventListener("pointerdown", onPointerDown);
    button.addEventListener("pointermove", onPointerMove);
    button.addEventListener("pointerup", onPointerUp);
    button.addEventListener("pointercancel", onPointerUp);
    window.addEventListener(
      "resize",
      () => {
        const input = getCurrentInput();
        if (!input) return;
        const saved = readStoredOptimizeButtonPosition();
        if (saved) positionButtonForInput(button, input, saved);
      },
      { passive: true }
    );
  }
  function openLoginCard(onSuccess) {
    ensureLeanPromptStyles();
    document.querySelectorAll(".lp-overlay").forEach((el) => el.remove());
    const card = document.createElement("div");
    card.className = "lp-overlay";
    card.style.cssText += ";min-height:unset;resize:none;";
    card.innerHTML = `
    <div class="lp-overlay-header" style="cursor:default;">
      <div>
        <div class="lp-overlay-title"><span>Lean</span>Prompt</div>
        <div class="lp-overlay-subtitle" id="lp-login-subtitle">Sign in to compress prompts</div>
      </div>
      <button type="button" class="lp-reset" data-lp-action="close-login">\u2715</button>
    </div>
    <div class="lp-overlay-body" style="gap:8px;">
      <div class="lp-login-tabs">
        <button type="button" class="lp-login-tab lp-login-tab-active" data-lp-login-tab="signin">Sign In</button>
        <button type="button" class="lp-login-tab" data-lp-login-tab="signup">Create Account</button>
      </div>
      <div id="lp-auth-error" class="lp-auth-error" style="display:none;"></div>
      <div class="lp-auth-form">
        <input type="email" class="lp-input" id="lp-email" placeholder="Email" autocomplete="email" />
        <input type="password" class="lp-input" id="lp-password" placeholder="Password" autocomplete="current-password" />
        <button type="button" class="lp-btn lp-btn-primary" id="lp-auth-submit" style="width:100%;">Sign In</button>
        <button type="button" id="lp-forgot-btn" style="background:none;border:none;color:#94a3b8;font-size:11px;cursor:pointer;padding:2px 0;text-align:left;width:100%;">Forgot password?</button>
      </div>
      <div class="lp-auth-divider"><span>or</span></div>
      <button type="button" class="lp-btn lp-btn-google" id="lp-google-btn">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
        </svg>
        Continue with Google
      </button>
    </div>
  `;
    document.body.appendChild(card);
    const margin = 12;
    if (window.innerWidth < 640) {
      card.classList.add("lp-mobile");
    } else {
      requestAnimationFrame(() => {
        const stored = readStoredOverlayPosition();
        const defaultX = window.innerWidth - card.offsetWidth - margin;
        const defaultY = window.innerHeight - card.offsetHeight - margin;
        const pos = stored ?? { x: defaultX, y: defaultY };
        card.style.left = `${clamp(pos.x, margin, Math.max(margin, window.innerWidth - card.offsetWidth - margin))}px`;
        card.style.top = `${clamp(pos.y, margin, Math.max(margin, window.innerHeight - card.offsetHeight - margin))}px`;
      });
    }
    let mode = "signin";
    let isLoading = false;
    const emailInput = card.querySelector("#lp-email");
    const passwordInput = card.querySelector("#lp-password");
    const submitBtn = card.querySelector("#lp-auth-submit");
    const forgotBtn = card.querySelector("#lp-forgot-btn");
    const googleBtn = card.querySelector("#lp-google-btn");
    const errorEl = card.querySelector("#lp-auth-error");
    const subtitleEl = card.querySelector("#lp-login-subtitle");
    const tabs = card.querySelectorAll("[data-lp-login-tab]");
    const showError = (msg) => {
      errorEl.textContent = msg;
      errorEl.style.display = "";
    };
    const showSuccess = (msg) => {
      errorEl.textContent = msg;
      errorEl.style.display = "";
      errorEl.style.color = "#4ade80";
    };
    const clearError = () => {
      errorEl.style.display = "none";
      errorEl.style.color = "";
    };
    const setMode = (next) => {
      mode = next;
      tabs.forEach((t) => t.classList.toggle("lp-login-tab-active", t.getAttribute("data-lp-login-tab") === next));
      subtitleEl.textContent = next === "signin" ? "Sign in to compress prompts" : "Create a free account";
      submitBtn.textContent = next === "signin" ? "Sign In" : "Create Account";
      passwordInput.autocomplete = next === "signin" ? "current-password" : "new-password";
      forgotBtn.style.display = next === "signin" ? "" : "none";
      clearError();
    };
    const setLoading = (loading) => {
      isLoading = loading;
      submitBtn.disabled = loading;
      googleBtn.disabled = loading;
      submitBtn.textContent = loading ? "\u2026" : mode === "signin" ? "Sign In" : "Create Account";
    };
    const handleSubmit = async () => {
      if (isLoading) return;
      const email = emailInput.value.trim();
      const password = passwordInput.value;
      if (!email || !password) {
        showError("Please enter your email and password.");
        return;
      }
      clearError();
      setLoading(true);
      const resp = mode === "signin" ? await loginThroughBackground(email, password) : await signupThroughBackground(email, password);
      setLoading(false);
      if (!resp.ok) {
        showError(resp.error);
        return;
      }
      if (resp.needsVerification) {
        setMode("signin");
        showError("Check your email for a verification link, then sign in here.");
        return;
      }
      card.remove();
      onSuccess();
    };
    const handleForgotPassword = async () => {
      const email = emailInput.value.trim();
      if (!email) {
        showError("Enter your email address above first.");
        emailInput.focus();
        return;
      }
      clearError();
      forgotBtn.disabled = true;
      forgotBtn.textContent = "Sending\u2026";
      const resp = await resetPasswordThroughBackground(email);
      forgotBtn.disabled = false;
      forgotBtn.textContent = "Forgot password?";
      if (!resp.ok) {
        showError(resp.error);
        return;
      }
      showSuccess("Password reset email sent \u2014 check your inbox.");
    };
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => setMode(tab.getAttribute("data-lp-login-tab")));
    });
    submitBtn.addEventListener("click", () => void handleSubmit());
    forgotBtn.addEventListener("click", () => void handleForgotPassword());
    [emailInput, passwordInput].forEach((input) => {
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") void handleSubmit();
      });
    });
    googleBtn.addEventListener("click", async () => {
      if (isLoading) return;
      clearError();
      setLoading(true);
      const resp = await googleSignInThroughBackground();
      setLoading(false);
      if (!resp.ok) {
        if (/cancel|closed by user/i.test(resp.error ?? "")) return;
        const redirectUrl = typeof chrome !== "undefined" && chrome.runtime?.id ? `https://${chrome.runtime.id}.chromiumapp.org/` : "";
        if (/redirect_uri_mismatch|not.*enabled|not.*configured|not.*supported|could not be loaded/i.test(resp.error ?? "")) {
          showError(`Google sign-in needs Supabase setup. Add this redirect URL:
${redirectUrl || "unknown \u2014 check chrome://extensions for your extension ID"}`);
          return;
        }
        showError(resp.error);
        return;
      }
      card.remove();
      onSuccess();
    });
    card.addEventListener("click", (e) => {
      if (e.target.getAttribute("data-lp-action") === "close-login") card.remove();
    });
    requestAnimationFrame(() => emailInput.focus());
  }
  function estimateFileTokens(file) {
    return new Promise((resolve) => {
      const isText = file.type.startsWith("text/") || /^application\/(json|xml|x-yaml)$/.test(file.type) || /\.(json|txt|csv|md|xml|yaml|yml|js|ts|py|html|css|log)$/i.test(file.name);
      if (isText) {
        const reader = new FileReader();
        reader.onload = (e) => resolve(estimateTokens(e.target?.result ?? ""));
        reader.onerror = () => resolve(Math.round(file.size / 4));
        reader.readAsText(file);
      } else if (file.type === "application/pdf" || /\.pdf$/i.test(file.name)) {
        resolve(Math.round(file.size / 6));
      } else {
        resolve(Math.round(file.size / 4));
      }
    });
  }
  function showAlreadyCompressedToast(btn) {
    const existing = document.getElementById("lp-already-compressed-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "lp-already-compressed-toast";
    toast.style.cssText = "position:fixed;z-index:2147483647;background:#1e293b;color:#4ade80;font-size:11px;font-family:system-ui,sans-serif;padding:5px 10px;border-radius:6px;border:1px solid rgba(74,222,128,0.3);pointer-events:none;white-space:nowrap;opacity:1;transition:opacity 0.4s ease;";
    toast.textContent = "\u2713 Already compressed \u2014 edit the prompt to compress again";
    if (btn) {
      const rect = btn.getBoundingClientRect();
      toast.style.left = `${Math.min(rect.right + 8, window.innerWidth - 260)}px`;
      toast.style.top = `${rect.top + rect.height / 2 - 12}px`;
    } else {
      toast.style.left = "50%";
      toast.style.top = "80px";
      toast.style.transform = "translateX(-50%)";
    }
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
    }, 1600);
    setTimeout(() => {
      toast.remove();
    }, 2100);
  }
  async function maybeShowUpdateBanner() {
    const update = await checkUpdateThroughBackground();
    if (!update.ok || !update.configured || !update.available || !update.latestVersion) return;
    const dismissKey = `leanprompt_update_dismissed_${update.latestVersion}`;
    const dismissed = (await chrome.storage.local.get(dismissKey))[dismissKey] === true;
    if (dismissed || document.getElementById("lp-update-banner")) return;
    ensureLeanPromptStyles();
    const banner = document.createElement("div");
    banner.id = "lp-update-banner";
    banner.className = "lp-update-banner";
    banner.innerHTML = `
    <div class="lp-update-title">LeanPrompt update available</div>
    <div class="lp-update-body">
      ${escapeHtml2(update.message ?? `Version ${update.latestVersion} is ready. Download the new beta zip and reload the extension.`)}
    </div>
    <div class="lp-update-actions">
      <button type="button" data-lp-update-dismiss>Later</button>
      ${update.downloadUrl ? `<a href="${escapeHtml2(update.downloadUrl)}" target="_blank" rel="noreferrer">Download v${escapeHtml2(update.latestVersion)}</a>` : ""}
    </div>
  `;
    banner.querySelector("[data-lp-update-dismiss]")?.addEventListener("click", () => {
      void chrome.storage.local.set({ [dismissKey]: true });
      banner.remove();
    });
    document.body.appendChild(banner);
  }
  function openContextWindowWarningPanel(totalTokens, ctxLimit, llmKey, textTokens, fileTokens, fileNames) {
    ensureLeanPromptStyles();
    document.querySelectorAll(".lp-overlay").forEach((el) => el.remove());
    const panel = document.createElement("div");
    panel.className = "lp-overlay";
    const usableCtx = Math.floor(ctxLimit * 0.75);
    const chunks = Math.max(2, Math.ceil(totalTokens / usableCtx));
    const tokensPerChunk = Math.ceil(totalTokens / chunks);
    const modelLabel = LLM_SELECT_LABELS[llmKey] ?? llmKey;
    const overPct = Math.round(totalTokens / ctxLimit * 100);
    const isOver = totalTokens > ctxLimit;
    const hasFiles = fileNames.length > 0;
    const breakdownHtml = hasFiles ? `<div class="lp-card-foot" style="border-top-color:rgba(148,163,184,0.12);margin-top:8px;padding-top:8px;">
        <div style="display:flex;justify-content:space-between;"><span>Text input</span><span>${textTokens.toLocaleString()} tokens</span></div>
        <div style="display:flex;justify-content:space-between;margin-top:4px;"><span>Files (${fileNames.length})</span><span>${fileTokens.toLocaleString()} tokens</span></div>
        <div style="margin-top:4px;color:#64748b;font-size:9.5px;">${fileNames.slice(0, 3).map(escapeHtml2).join(", ")}${fileNames.length > 3 ? ` +${fileNames.length - 3} more` : ""}</div>
      </div>` : "";
    panel.innerHTML = `
    <div class="lp-overlay-header" data-lp-drag-handle="true">
      <div>
        <div class="lp-overlay-title" style="color:#fbbf24;">\u26A0 Context Limit${isOver ? " Exceeded" : " Warning"}</div>
        <div class="lp-overlay-subtitle">${isOver ? "Input exceeds" : "Input approaching"} ${modelLabel} context window</div>
      </div>
      <button type="button" class="lp-reset" data-lp-action="ctx-close">\u2715</button>
    </div>
    <div class="lp-overlay-body">
      <div class="lp-card" style="border-color:rgba(251,191,36,0.3);background:rgba(120,53,15,0.16);">
        <div class="lp-card-label" style="color:#fbbf24;">Input vs. context window</div>
        <div class="lp-kpi-grid" style="margin-top:8px;">
          <div class="lp-kpi">
            <span class="lp-kpi-val" style="color:#fbbf24;">${totalTokens.toLocaleString()}</span>
            <span class="lp-kpi-lbl">Total input (tokens)</span>
          </div>
          <div class="lp-kpi">
            <span class="lp-kpi-val">${ctxLimit.toLocaleString()}</span>
            <span class="lp-kpi-lbl">${modelLabel} limit</span>
          </div>
        </div>
        ${breakdownHtml}
        <div class="lp-card-foot" style="border-top-color:rgba(251,191,36,0.18);color:#fbbf24;${hasFiles ? "margin-top:0;padding-top:6px;" : ""}">
          ~${overPct}% of context \u2014 ${isOver ? "will be cut off by the API" : "leaves little room for replies"}
        </div>
      </div>

      <div class="lp-card">
        <div class="lp-card-label">Suggested split strategy</div>
        <div class="lp-kpi-grid" style="margin-top:8px;">
          <div class="lp-kpi">
            <span class="lp-kpi-val" style="color:#a78bfa;">${chunks}</span>
            <span class="lp-kpi-lbl">separate queries</span>
          </div>
          <div class="lp-kpi">
            <span class="lp-kpi-val">~${tokensPerChunk.toLocaleString()}</span>
            <span class="lp-kpi-lbl">tokens per query</span>
          </div>
        </div>
        <div class="lp-hint" style="margin-top:8px;">
          Split your data into ${chunks} separate queries of ~${tokensPerChunk.toLocaleString()} tokens each.
          Ask the same question in every query, then combine the results.
        </div>
      </div>

      <div class="lp-actions" style="grid-template-columns:1fr;">
        <button type="button" class="lp-btn lp-btn-primary" data-lp-action="ctx-close">Got it</button>
      </div>
    </div>
  `;
    document.body.appendChild(panel);
    if (window.innerWidth >= 640) {
      const margin = 12;
      const maxX = Math.max(margin, window.innerWidth - panel.offsetWidth - margin);
      const maxY = Math.max(margin, window.innerHeight - panel.offsetHeight - margin);
      const pos = readStoredOverlayPosition() ?? { x: maxX, y: maxY };
      panel.style.left = `${clamp(pos.x, margin, maxX)}px`;
      panel.style.top = `${clamp(pos.y, margin, maxY)}px`;
      const dragHandle = panel.querySelector("[data-lp-drag-handle='true']");
      if (dragHandle) {
        let dragging = false;
        let ox = 0, oy = 0;
        dragHandle.addEventListener("pointerdown", (e) => {
          if (e.target.closest("[data-lp-action='ctx-close']")) return;
          dragging = true;
          dragHandle.setPointerCapture(e.pointerId);
          dragHandle.style.cursor = "grabbing";
          const r = panel.getBoundingClientRect();
          ox = e.clientX - r.left;
          oy = e.clientY - r.top;
        });
        dragHandle.addEventListener("pointermove", (e) => {
          if (!dragging) return;
          const m = 12;
          panel.style.left = `${clamp(e.clientX - ox, m, window.innerWidth - panel.offsetWidth - m)}px`;
          panel.style.top = `${clamp(e.clientY - oy, m, window.innerHeight - panel.offsetHeight - m)}px`;
        });
        dragHandle.addEventListener("pointerup", () => {
          dragging = false;
          dragHandle.style.cursor = "grab";
        });
        dragHandle.addEventListener("pointercancel", () => {
          dragging = false;
          dragHandle.style.cursor = "grab";
        });
      }
    } else {
      panel.classList.add("lp-mobile");
    }
    panel.addEventListener("click", (e) => {
      if (e.target.getAttribute("data-lp-action") === "ctx-close") panel.remove();
    });
  }
  function recordTrainingData(result, action, editedPrompt, rejectionCategory) {
    const finalText = action === "applied" ? editedPrompt : result.optimizedText;
    void recordPromptFeedbackThroughBackground({
      action,
      originalText: result.originalText,
      optimizedText: result.optimizedText,
      editedText: editedPrompt,
      intent: result.intent.primary_intent,
      validationScore: result.validation.score,
      reductionPercent: result.reductionPercent,
      site: window.location.hostname,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      matchedRuleId: result.matchedRuleId,
      modelUsed: modelUsedLabel(result),
      rejectionCategory
    }).catch((error) => {
      console.warn(`LeanPrompt failed to record ${action} feedback:`, error);
    });
    void recordTeacherCompressionThroughBackground(
      buildTeacherCompressionRecord(result, action, finalText, editedPrompt)
    ).catch((error) => {
      console.warn(`LeanPrompt failed to record ${action} teacher compression:`, error);
    });
    if (action === "applied") {
      const trace = result.compressionTrace;
      const instruction = result.instructionSourceText?.trim() || result.originalText;
      const label = editedPrompt.trim() !== result.optimizedText.trim() ? editedPrompt.trim() : finalText.trim();
      if (trace?.geminiOutput || trace?.sourceModel === "gemini" || result.matchedRuleId === "gemini_learned") {
        learnFromGeminiCompression(instruction, result.intent.primary_intent, label);
      }
    }
  }
  function openOptimizationPanel(result, input, onApplied, typosFixed = 0) {
    ensureLeanPromptStyles();
    document.querySelectorAll(".lp-overlay").forEach((existing) => existing.remove());
    const panel = document.createElement("div");
    panel.className = "lp-overlay";
    const intentLabel = result.intent.primary_intent.replace(/_/g, " ");
    const targetSpan = resolveCompressionTarget(result.originalText);
    const referenceNote = targetSpan.source === "user" ? `<p class="lp-hint" style="margin:0 0 10px;color:#a78bfa;">Only your selected text was compressed; the rest is unchanged.</p>` : targetSpan.source === "auto" ? `<p class="lp-hint" style="margin:0 0 10px;color:#a78bfa;">Reference block kept as-is \u2014 only the purple-highlighted instruction was compressed.</p>` : "";
    const detectedModelKey = detectLlmKeyFromPage();
    const llmId = CONTEXT_WINDOWS[detectedModelKey] ? detectedModelKey : inferDefaultLlmId(window.location.hostname);
    const statsState = readTokenStatsState();
    const tokenFilter = readTokenFilter();
    const totals = getVisibleTokenStats(statsState, tokenFilter);
    const projected = estimateMonthUsage(normalizeStatsBucket(statsState.byMonth[monthKey()]));
    const savingsTotal = totals.used + totals.saved;
    const savingsPct = savingsTotal > 0 ? Math.round(totals.saved / savingsTotal * 100) : 0;
    const savingsLabel = tokenFilter === "month" ? "Savings this month" : "Savings all time";
    const llmLocked = { current: false };
    panel.innerHTML = `
    <div class="lp-overlay-header" data-lp-drag-handle="true">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
        <div class="lp-overlay-title"><span>Lean</span>Prompt</div>
        <span class="lp-summary-badge" style="font-size:10px;padding:2px 7px;">\u2212${result.reductionPercent}% tokens</span>
      </div>
      <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
        <button type="button" class="lp-reset" data-lp-action="reset-pos">Reset</button>
        <button type="button" class="lp-reset" data-lp-action="close-panel" aria-label="Minimize" title="Minimize (Esc)" style="padding:5px 9px;font-weight:700;line-height:1;">\u2715</button>
      </div>
    </div>
    <div class="lp-overlay-body">
      <div id="lp-signin-nudge-slot"></div>
      ${referenceNote}

      <div style="margin-bottom:6px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;gap:8px;">
          <span style="font-size:10px;font-weight:600;letter-spacing:0.07em;color:#94a3b8;text-transform:uppercase;display:flex;align-items:center;gap:6px;">
            Compressed prompt
            ${typosFixed > 0 ? `<span style="text-transform:none;letter-spacing:0;font-weight:600;color:#4ade80;background:rgba(74,222,128,0.12);border:1px solid rgba(74,222,128,0.3);border-radius:99px;padding:1px 7px;">\u2713 ${typosFixed} typo${typosFixed > 1 ? "s" : ""} fixed</span>` : ""}
          </span>
          <span style="font-size:10px;color:#64748b;white-space:nowrap;">${result.tokenEstimateBefore} \u2192 ${result.tokenEstimateAfter} tokens</span>
        </div>
        <textarea class="lp-textarea" aria-label="Optimized prompt"></textarea>
      </div>

      <div class="lp-actions" style="margin-bottom:14px;">
        <button type="button" class="lp-btn lp-btn-primary" data-lp-action="apply">Apply to prompt</button>
        <button type="button" class="lp-btn lp-btn-reject" data-lp-action="reject">Reject</button>
      </div>

      <div style="height:1px;background:rgba(148,163,184,0.1);margin-bottom:12px;"></div>

      <div class="lp-summary" style="margin-bottom:10px;">
        <span class="lp-summary-intent">${intentLabel}</span>
        <span style="font-size:10px;color:#64748b;">Cost saved ~$${result.costSavingsEstimate} \xB7 ~${result.carbonSavingsEstimate}g CO\u2082e</span>
      </div>

      <div class="lp-card">
        <div class="lp-card-head">
          <span class="lp-card-label">Your usage</span>
          <select class="lp-select lp-select-inline" data-lp-action="token-filter" aria-label="Usage period">
            <option value="month" ${tokenFilter === "month" ? "selected" : ""}>This month</option>
            <option value="all" ${tokenFilter === "all" ? "selected" : ""}>All time</option>
          </select>
        </div>
        <div style="margin:8px 0 4px;">
          <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px;">
            <span style="font-size:10px;color:#94a3b8;" data-lp-savings-label>${savingsLabel}</span>
            <span style="font-size:13px;font-weight:700;background:linear-gradient(90deg,#a78bfa,#8b5cf6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;" data-lp-savings-pct>${savingsPct > 0 ? `${savingsPct}% saved` : "\u2014"}</span>
          </div>
          <div style="height:6px;border-radius:99px;background:rgba(139,92,246,0.1);overflow:hidden;position:relative;">
            <div data-lp-savings-bar style="height:100%;border-radius:99px;background:linear-gradient(90deg,#6d28d9,#8b5cf6,#a78bfa);width:${savingsPct}%;transition:width 0.5s cubic-bezier(0.4,0,0.2,1);box-shadow:0 0 8px rgba(139,92,246,0.5);"></div>
          </div>
        </div>
        <div class="lp-stat-row" style="grid-template-columns:1fr 1fr;margin-top:8px;">
          <div>
            <span class="lp-stat-num" data-lp-stat-used>${totals.used.toLocaleString()}</span>
            <span class="lp-stat-lbl" data-lp-stat-used-label>${tokenFilter === "month" ? "Sent (month)" : "Sent (all)"}</span>
          </div>
          <div>
            <span class="lp-stat-num" style="color:#a78bfa;" data-lp-stat-saved>${totals.saved.toLocaleString()}</span>
            <span class="lp-stat-lbl" data-lp-stat-saved-label>${tokenFilter === "month" ? "Saved (month)" : "Saved (all)"}</span>
          </div>
        </div>
        <div data-lp-month-projection class="lp-hint" ${tokenFilter === "month" ? "" : 'style="display:none;"'}>
          Projected by month-end: ~${projected.projectedSaved.toLocaleString()} tokens saved
        </div>
      </div>

      <div class="lp-card">
        <div class="lp-card-head">
          <span class="lp-card-label">Model context</span>
        </div>
        <select class="lp-select" data-lp-action="llm-select" aria-label="Model context window">
          ${llmSelectOptionsHtml(llmId)}
        </select>
        <div data-lp-thread-est class="lp-hint">\u2026</div>
        <div data-lp-context-note class="lp-hint">\u2026</div>
        ${fileUploadState.tokens > 0 ? `<div data-lp-file-est class="lp-hint" style="color:#a78bfa;">Attached files: ${fileUploadState.names.slice(0, 2).map(escapeHtml2).join(", ")}${fileUploadState.names.length > 2 ? ` +${fileUploadState.names.length - 2} more` : ""} \xB7 ~${fileUploadState.tokens.toLocaleString()} tokens (est.)</div>` : '<div data-lp-file-est class="lp-hint" style="display:none;"></div>'}
      </div>
    </div>
  `;
    const isSmallViewport = window.innerWidth < 640;
    document.body.appendChild(panel);
    const optimizedTextarea = panel.querySelector(".lp-textarea");
    if (optimizedTextarea) optimizedTextarea.value = result.optimizedText;
    const applyPosition = (desired) => {
      if (window.innerWidth < 640) {
        panel.classList.add("lp-mobile");
        panel.style.width = "";
        panel.style.height = "";
        panel.style.removeProperty("left");
        panel.style.removeProperty("top");
        return;
      }
      panel.classList.remove("lp-mobile");
      const margin = 12;
      const maxX = Math.max(margin, window.innerWidth - panel.offsetWidth - margin);
      const maxY = Math.max(margin, window.innerHeight - panel.offsetHeight - margin);
      const defaultPos = { x: maxX, y: maxY };
      const safeDesired = desired && Number.isFinite(desired.x) && Number.isFinite(desired.y) ? desired : void 0;
      const base = safeDesired ?? readStoredOverlayPosition() ?? defaultPos;
      const x = clamp(base.x, margin, maxX);
      const y = clamp(base.y, margin, maxY);
      panel.style.left = `${x}px`;
      panel.style.top = `${y}px`;
    };
    const storedSize = readStoredOverlaySize();
    if (storedSize && window.innerWidth >= 640) {
      const maxWidth = Math.max(290, Math.min(560, window.innerWidth - 18));
      const maxHeight = Math.max(280, Math.min(Math.round(window.innerHeight * 0.86), 760));
      panel.style.width = `${clamp(storedSize.width, 290, maxWidth)}px`;
      panel.style.height = `${clamp(storedSize.height, 280, maxHeight)}px`;
    }
    applyPosition();
    void (async () => {
      try {
        const authResp = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: "LEANPROMPT_GET_AUTH_STATE" }, (r) => {
            void chrome.runtime.lastError;
            resolve(r ?? { ok: false });
          });
        });
        if (!authResp.ok || authResp.loggedIn) return;
        const slot = panel.querySelector("#lp-signin-nudge-slot");
        if (!slot || !panel.isConnected) return;
        slot.innerHTML = `
        <div class="lp-signin-nudge">
          <span>Sign in to save your history &amp; improve compression</span>
          <button type="button" class="lp-signin-nudge-btn" data-lp-action="open-login-card">Sign in \u2192</button>
        </div>`;
      } catch {
      }
    })();
    refreshPanelEstimates(panel, result, llmLocked);
    const panelRefreshId = window.setInterval(() => {
      if (!panel.isConnected) {
        window.clearInterval(panelRefreshId);
        return;
      }
      refreshPanelEstimates(panel, result, llmLocked);
    }, 1600);
    if (!isSmallViewport) {
      const dragHandle = panel.querySelector("[data-lp-drag-handle='true']");
      if (dragHandle) {
        let dragging = false;
        let offsetX = 0;
        let offsetY = 0;
        let pointerId = null;
        const onPointerMove = (event) => {
          if (!dragging) return;
          const margin = 12;
          const maxX = Math.max(margin, window.innerWidth - panel.offsetWidth - margin);
          const maxY = Math.max(margin, window.innerHeight - panel.offsetHeight - margin);
          const x = clamp(event.clientX - offsetX, margin, maxX);
          const y = clamp(event.clientY - offsetY, margin, maxY);
          panel.style.left = `${x}px`;
          panel.style.top = `${y}px`;
        };
        const onPointerUp = () => {
          if (!dragging) return;
          dragging = false;
          dragHandle.style.cursor = "grab";
          if (pointerId !== null) {
            try {
              dragHandle.releasePointerCapture(pointerId);
            } catch {
            }
          }
          const x = Number.parseFloat(panel.style.left) || 12;
          const y = Number.parseFloat(panel.style.top) || 12;
          storeOverlayPosition({ x, y });
        };
        dragHandle.addEventListener("pointerdown", (event) => {
          const target = event.target;
          if (target.closest("[data-lp-action='reset-pos']")) return;
          if (target.closest("[data-lp-action='close-panel']")) return;
          if (window.innerWidth < 640) return;
          dragging = true;
          pointerId = event.pointerId;
          dragHandle.setPointerCapture(event.pointerId);
          dragHandle.style.cursor = "grabbing";
          const rect = panel.getBoundingClientRect();
          offsetX = event.clientX - rect.left;
          offsetY = event.clientY - rect.top;
        });
        dragHandle.addEventListener("pointermove", onPointerMove);
        dragHandle.addEventListener("pointerup", onPointerUp);
        dragHandle.addEventListener("pointercancel", onPointerUp);
      }
    }
    panel.addEventListener("click", async (event) => {
      const target = event.target;
      const action = target.getAttribute("data-lp-action");
      if (!action) return;
      if (action === "open-login-card") {
        panel.remove();
        openLoginCard(() => {
        });
        return;
      }
      if (action === "close-panel") {
        panel.remove();
        return;
      }
      if (action === "reset-pos") {
        localStorage.removeItem(OVERLAY_POS_KEY);
        localStorage.removeItem(OVERLAY_SIZE_KEY);
        panel.style.width = "";
        panel.style.height = "";
        applyPosition({ x: window.innerWidth - panel.offsetWidth - 16, y: window.innerHeight - panel.offsetHeight - 16 });
        return;
      }
      const editedPrompt = panel.querySelector(".lp-textarea")?.value ?? result.optimizedText;
      if (action === "apply") {
        applyOptimizedPromptToTextarea(input, editedPrompt);
        onApplied?.(editedPrompt);
        if (editedPrompt.includes(RESPONSE_STYLE_INSTRUCTION) || editedPrompt.includes("fewest words") || editedPrompt.includes("no preamble")) {
          markResponseStyleInjected();
        }
        panel.remove();
        const editedTokens = estimateTokens(editedPrompt);
        updateTokenStats(result.tokenEstimateBefore, editedTokens);
        let pollTicks = 0;
        const replyPollId = window.setInterval(() => {
          pollTicks += 1;
          applyAssistantOutputDeltaFromTotal(sumAssistantTokensEstimate());
          if (pollTicks >= 28) window.clearInterval(replyPollId);
        }, 1500);
        recordTrainingData(result, "applied", editedPrompt);
        return;
      }
      if (action === "reject") {
        const actionsDiv = panel.querySelector(".lp-actions");
        if (actionsDiv) {
          actionsDiv.innerHTML = `
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:2px;">
            <div class="lp-reject-label">Why did you reject?</div>
            <button type="button" class="lp-btn lp-btn-back" data-lp-action="reject-back" style="padding:3px 10px;font-size:11px;">\u2190 Back</button>
          </div>
          <div class="lp-reject-chips">
            <button type="button" class="lp-chip" data-lp-action="reject-category" data-category="no_reduction">No reduction</button>
            <button type="button" class="lp-chip" data-lp-action="reject-category" data-category="grammar_broken">Grammar broken</button>
            <button type="button" class="lp-chip" data-lp-action="reject-category" data-category="too_aggressive">Too aggressive</button>
            <button type="button" class="lp-chip" data-lp-action="reject-category" data-category="intent_wrong">Intent wrong</button>
            <button type="button" class="lp-chip" data-lp-action="reject-category" data-category="semantic_drift">Meaning changed</button>
            <button type="button" class="lp-chip" data-lp-action="reject-category" data-category="constraint_dropped">Constraint dropped</button>
            <button type="button" class="lp-chip" data-lp-action="reject-category" data-category="too_verbose">Too verbose</button>
            <button type="button" class="lp-chip lp-chip-skip" data-lp-action="reject-category" data-category="other">Skip \u2192</button>
          </div>
        `;
        } else {
          panel.remove();
          recordTrainingData(result, "rejected", editedPrompt, "other");
        }
        return;
      }
      if (action === "reject-back") {
        const actionsDiv = panel.querySelector(".lp-actions");
        if (actionsDiv) {
          actionsDiv.innerHTML = `
          <button type="button" class="lp-btn lp-btn-primary" data-lp-action="apply">Apply to prompt</button>
          <button type="button" class="lp-btn lp-btn-reject" data-lp-action="reject">Reject</button>
        `;
        }
        return;
      }
      if (action === "reject-category") {
        const category = target.getAttribute("data-category") ?? "other";
        panel.remove();
        recordTrainingData(result, "rejected", editedPrompt, category);
      }
    });
    panel.addEventListener("change", (event) => {
      const target = event.target;
      const action = target.getAttribute("data-lp-action");
      if (action === "llm-select") {
        llmLocked.current = true;
        refreshPanelEstimates(panel, result, llmLocked);
        return;
      }
      if (action === "token-filter") {
        const select = target;
        const filter = select.value === "all" ? "all" : "month";
        writeTokenFilter(filter);
        const state = readTokenStatsState();
        const visible = getVisibleTokenStats(state, filter);
        const usedEl = panel.querySelector("[data-lp-stat-used]");
        const savedEl = panel.querySelector("[data-lp-stat-saved]");
        const usedLabelEl = panel.querySelector("[data-lp-stat-used-label]");
        const savedLabelEl = panel.querySelector("[data-lp-stat-saved-label]");
        const barEl = panel.querySelector("[data-lp-savings-bar]");
        const pctEl = panel.querySelector("[data-lp-savings-pct]");
        const savingsLabelEl = panel.querySelector("[data-lp-savings-label]");
        const projectionEl = panel.querySelector("[data-lp-month-projection]");
        const visibleTotal = visible.used + visible.saved;
        const visiblePct = visibleTotal > 0 ? Math.round(visible.saved / visibleTotal * 100) : 0;
        if (usedEl) usedEl.textContent = visible.used.toLocaleString();
        if (savedEl) savedEl.textContent = visible.saved.toLocaleString();
        if (usedLabelEl) usedLabelEl.textContent = filter === "month" ? "Sent (month)" : "Sent (all)";
        if (savedLabelEl) savedLabelEl.textContent = filter === "month" ? "Saved (month)" : "Saved (all)";
        if (barEl) barEl.style.width = `${visiblePct}%`;
        if (pctEl) {
          pctEl.textContent = visibleTotal > 0 ? `${visiblePct}% saved` : "\u2014";
          pctEl.style.cssText = "font-size:13px;font-weight:700;background:linear-gradient(90deg,#a78bfa,#8b5cf6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;";
        }
        if (savingsLabelEl) savingsLabelEl.textContent = filter === "month" ? "Savings this month" : "Savings all time";
        if (projectionEl) {
          if (filter === "month") {
            const proj = estimateMonthUsage(normalizeStatsBucket(state.byMonth[monthKey()]));
            projectionEl.style.display = "";
            projectionEl.textContent = `Projected by month-end: ~${proj.projectedSaved.toLocaleString()} tokens saved`;
          } else {
            projectionEl.style.display = "none";
          }
        }
      }
    });
    if (typeof ResizeObserver !== "undefined") {
      const observer = new ResizeObserver(() => {
        if (window.innerWidth < 640) return;
        storeOverlaySize({ width: panel.offsetWidth, height: panel.offsetHeight });
        applyPosition({ x: Number.parseFloat(panel.style.left), y: Number.parseFloat(panel.style.top) });
      });
      observer.observe(panel);
    }
    window.addEventListener("resize", () => applyPosition({ x: Number.parseFloat(panel.style.left), y: Number.parseFloat(panel.style.top) }));
    const onPanelKeydown = (event) => {
      if (!panel.isConnected) {
        document.removeEventListener("keydown", onPanelKeydown, true);
        return;
      }
      const active = document.activeElement;
      const typingInPanel = active instanceof HTMLElement && panel.contains(active) && active.tagName === "TEXTAREA";
      if (event.key === "Escape" && !typingInPanel) {
        panel.remove();
        document.removeEventListener("keydown", onPanelKeydown, true);
      }
    };
    document.addEventListener("keydown", onPanelKeydown, true);
    return panel;
  }
  async function isSiteDisabled(hostname) {
    const result = await chrome.storage.local.get("leanprompt_disabled_sites");
    const disabled = result["leanprompt_disabled_sites"] ?? [];
    return disabled.includes(hostname);
  }
  async function init() {
    if (await isSiteDisabled(window.location.hostname)) return;
    const site = detectSupportedSite(window.location.hostname);
    const shouldRunOnPage = Boolean(site) || isLikelyAIToolSite(window.location.hostname, window.location.pathname);
    if (!shouldRunOnPage) return;
    void preloadFastCompressionModel();
    void preloadGeminiLearnedStore();
    preloadSpellChecker();
    let settings = await getSettings();
    if (site && !settings.enabledSites[site]) return;
    let highlightBetaEnabled = settings.instructionHighlightBeta === true;
    let currentInput = findPromptInputElement();
    let button = null;
    let conciseToggle = null;
    let instructionHighlight = null;
    let highlightedInput = null;
    let compressedSnapshot = null;
    let snapshotWatcherAbort = null;
    const handleOptimizeClick = async () => {
      try {
        const input = findPromptInputElement() ?? currentInput;
        if (!input || !input.isConnected) {
          alert("LeanPrompt could not find the active prompt input. Click in the prompt box and try again.");
          return;
        }
        const badge = button?.querySelector(".lp-float-badge");
        const authCtx = await getAuthContextFromBackground();
        const authState = authCtx?.state ?? { ok: false, error: "Could not reach extension." };
        const user = authCtx?.user ?? null;
        if (!authState.ok) {
          alert(
            authState.error ?? "LeanPrompt could not verify your session. Reload this page, then open the extension popup once."
          );
          return;
        }
        if (authState.configured && !authState.loggedIn) {
          badge?.classList.add("lp-badge-visible");
          openLoginCard(() => {
            badge?.classList.remove("lp-badge-visible");
            void handleOptimizeClick();
          });
          return;
        }
        badge?.classList.remove("lp-badge-visible");
        if (authState.configured && authState.needsEmailVerification) {
          alert(
            "Verify your email to use LeanPrompt (check your inbox for the confirmation link)."
          );
          return;
        }
        await flushPromptFeedbackThroughBackground();
        await flushTeacherCompressionsThroughBackground();
        const gate = await checkOptimizeGate(user, {
          loggedIn: authState.loggedIn,
          needsEmailVerification: authState.needsEmailVerification
        });
        if (!gate.allowed) {
          alert(gate.reason);
          return;
        }
        let prompt = readInputValue(input);
        if (!prompt.trim()) {
          alert("No prompt text detected yet. Type your prompt, then click Optimize.");
          return;
        }
        if (compressedSnapshot !== null && prompt === compressedSnapshot) {
          showAlreadyCompressedToast(button);
          return;
        }
        const highlightTarget = instructionHighlight?.getCompressionTarget();
        let typosFixed = 0;
        if (settings.autocorrectEnabled !== false && !highlightTarget) {
          try {
            const corrected = await applyAutoCorrect(prompt);
            if (corrected && corrected !== prompt) {
              typosFixed = countWordDiffs(prompt, corrected);
              prompt = corrected;
            }
          } catch {
          }
        }
        const textTokens = estimateTokens(prompt);
        const totalTokens = textTokens + fileUploadState.tokens;
        const detectedModel = detectLlmKeyFromPage();
        const llmKey = CONTEXT_WINDOWS[detectedModel] ? detectedModel : inferDefaultLlmId(window.location.hostname);
        const ctxLimit = CONTEXT_WINDOWS[llmKey];
        if (totalTokens > ctxLimit * 0.85) {
          openContextWindowWarningPanel(totalTokens, ctxLimit, llmKey, textTokens, fileUploadState.tokens, fileUploadState.names);
          return;
        }
        const isConcise = readConciseToggle();
        const compressionTarget = highlightTarget ?? resolveCompressionTarget(prompt);
        const baseResult = optimizePromptWithTarget(
          prompt,
          compressionTarget,
          settings.compressionLevel,
          isConcise
        );
        let working = baseResult;
        const apiAssistOn = settings.apiAssistEnabled !== false;
        if (apiAssistOn) {
          working = await enhanceWithApiAssist(baseResult, true);
        }
        let result;
        if (isConcise) {
          const concisePrefix = "[Reply concisely \u2014 minimum words, no filler] ";
          const optimizedText = (concisePrefix + working.optimizedText.trim()).replace(/\s+/g, " ").trim();
          markResponseStyleInjected();
          const tokenEstimateAfter = estimateTokens(optimizedText);
          const rawReduction = (working.tokenEstimateBefore - tokenEstimateAfter) / working.tokenEstimateBefore * 100;
          result = {
            ...working,
            optimizedText,
            tokenEstimateAfter,
            reductionPercent: Math.max(0, Number(rawReduction.toFixed(1))),
            costSavingsEstimate: Math.max(0, Number((estimateCost(working.tokenEstimateBefore) - estimateCost(tokenEstimateAfter)).toFixed(6))),
            carbonSavingsEstimate: Math.max(0, Number((estimateCarbon(working.tokenEstimateBefore) - estimateCarbon(tokenEstimateAfter)).toFixed(6)))
          };
        } else {
          result = working;
        }
        openOptimizationPanel(result, input, (applied) => {
          compressedSnapshot = applied;
          snapshotWatcherAbort?.abort();
          snapshotWatcherAbort = new AbortController();
          const watchedInput = input;
          watchedInput.addEventListener("input", () => {
            if (compressedSnapshot !== null && readInputValue(watchedInput) !== compressedSnapshot) {
              compressedSnapshot = null;
            }
          }, { passive: true, signal: snapshotWatcherAbort.signal });
        }, typosFixed);
        void incrementUsage(user).catch((error) => {
          console.warn("LeanPrompt failed to increment usage:", error);
        });
      } catch (error) {
        if (error instanceof Error && /extension context invalidated|context invalidated/i.test(error.message)) {
          alert("LeanPrompt was updated \u2014 please refresh this page and try again.");
          return;
        }
        console.error("LeanPrompt optimize click failed:", error);
        alert("LeanPrompt hit an error while optimizing. Open the page once more and try again.");
      }
    };
    const buildButton = (input) => {
      const nextButton = injectLeanPromptButton(input, readStoredOptimizeButtonPosition() ?? void 0);
      makeOptimizeButtonDraggable(nextButton, () => currentInput, handleOptimizeClick);
      return nextButton;
    };
    const teardownInstructionHighlight = () => {
      instructionHighlight?.destroy();
      instructionHighlight = null;
      highlightedInput = null;
    };
    const syncInstructionHighlight = (input) => {
      if (!highlightBetaEnabled) {
        teardownInstructionHighlight();
        return;
      }
      if (highlightedInput === input && instructionHighlight) {
        return;
      }
      teardownInstructionHighlight();
      highlightedInput = input;
      instructionHighlight = attachInstructionHighlight(input, () => readInputValue(input));
    };
    let attachDebounceTimer = null;
    const scheduleAttach = () => {
      if (attachDebounceTimer) clearTimeout(attachDebounceTimer);
      attachDebounceTimer = setTimeout(() => {
        attachDebounceTimer = null;
        attach();
      }, 250);
    };
    let repositionRaf = 0;
    const repositionFloatingUi = () => {
      if (repositionRaf) cancelAnimationFrame(repositionRaf);
      repositionRaf = requestAnimationFrame(() => {
        repositionRaf = 0;
        if (!button || !currentInput?.isConnected) return;
        const savedPos = readStoredOptimizeButtonPosition();
        if (savedPos) {
          positionButtonForInput(button, currentInput, savedPos);
        } else {
          positionButtonForInput(button, currentInput);
        }
      });
    };
    const attach = () => {
      ensureLeanPromptStyles();
      const latestInput = findPromptInputElement();
      if (latestInput) {
        currentInput = latestInput;
        syncInstructionHighlight(currentInput);
        if (!button || !document.body.contains(button)) {
          button = buildButton(currentInput);
          conciseToggle?.remove();
          conciseToggle = injectConciseToggleButton(button);
        } else {
          const savedPos = readStoredOptimizeButtonPosition();
          if (savedPos) {
            positionButtonForInput(button, currentInput, savedPos);
          } else {
            positionButtonForInput(button, currentInput);
          }
        }
      } else {
        teardownInstructionHighlight();
      }
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync" || !changes.leanprompt_settings) return;
      void getSettings().then((next) => {
        settings = next;
        const nextHighlight = next.instructionHighlightBeta === true;
        if (nextHighlight === highlightBetaEnabled) return;
        highlightBetaEnabled = nextHighlight;
        if (!highlightBetaEnabled) {
          teardownInstructionHighlight();
        } else if (currentInput?.isConnected) {
          syncInstructionHighlight(currentInput);
        }
      });
    });
    attach();
    void maybeShowUpdateBanner().catch(() => {
    });
    window.addEventListener("scroll", repositionFloatingUi, { passive: true });
    window.addEventListener("resize", scheduleAttach, { passive: true });
    const observer = new MutationObserver(scheduleAttach);
    observer.observe(document.body, { childList: true, subtree: true });
    window.addEventListener("lp-file-attached", (e) => {
      const detail = e.detail;
      if (!detail || typeof detail !== "object") return;
      const raw = detail;
      if (typeof raw.name !== "string" || typeof raw.size !== "number" || typeof raw.mimeType !== "string") return;
      const name = raw.name.slice(0, 255);
      const size = Math.max(0, Math.floor(raw.size));
      const mimeType = raw.mimeType.slice(0, 100);
      if (fileUploadState.names.includes(name)) return;
      let tokens;
      if (mimeType === "application/pdf" || /\.pdf$/i.test(name)) {
        tokens = Math.round(size / 20);
      } else if (mimeType.startsWith("image/")) {
        tokens = 765;
      } else if (mimeType.startsWith("text/") || /^application\/(json|xml|x-yaml)$/.test(mimeType) || /\.(json|csv|md|xml|yaml|yml|js|ts|py|html|css)$/i.test(name)) {
        tokens = Math.round(size / 4);
      } else {
        tokens = Math.round(size / 8);
      }
      fileUploadState.tokens += tokens;
      fileUploadState.names.push(name);
    });
    const handleFileInputChange = async (e) => {
      const fileInput = e.composedPath().find(
        (el) => el instanceof HTMLInputElement && el.type === "file"
      );
      if (!fileInput?.files?.length) return;
      const files = Array.from(fileInput.files).filter(
        (f) => !fileUploadState.names.includes(f.name)
      );
      if (!files.length) return;
      const counts = await Promise.all(files.map(estimateFileTokens));
      fileUploadState.tokens += counts.reduce((a, b) => a + b, 0);
      fileUploadState.names.push(...files.map((f) => f.name));
    };
    document.addEventListener("change", handleFileInputChange, true);
    window.addEventListener("change", handleFileInputChange, true);
  }
  if (typeof window !== "undefined" && typeof document !== "undefined") {
    attachExtensionInvalidationGuards();
    init().catch((error) => {
      if (error instanceof Error && /extension context invalidated|context invalidated/i.test(error.message)) return;
      console.error("LeanPrompt init failed:", error);
    });
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === "LEANPROMPT_SITE_TOGGLE" && msg.hostname === window.location.hostname) {
        window.location.reload();
      }
    });
  }
})();
/*! Bundled license information:

is-buffer/index.js:
  (*!
   * Determine if an object is a Buffer
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   *)
*/
//# sourceMappingURL=index.js.map
