globalThis.__LEANPROMPT_BUILD__={"supabaseUrl":"https://synuufxjdejpvpbwcypj.supabase.co","supabaseAnonKey":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN5bnV1ZnhqZGVqcHZwYndjeXBqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg2NDc4NTEsImV4cCI6MjA5NDIyMzg1MX0.wwn9NvsCZjCGnJAT6D64XWvBK2vC-IPBcqI2Ki41LZw"};
"use strict";
(() => {
  // src/content/fileIntercept.ts
  (function patchForLeanPromptFileDetection() {
    const EVT = "lp-file-attached";
    function notify(name, size, mimeType) {
      window.dispatchEvent(new CustomEvent(EVT, { detail: { name, size, mimeType } }));
    }
    const origAppend = FormData.prototype.append;
    FormData.prototype.append = function(name, value, filename) {
      if (value instanceof File) {
        notify(value.name, value.size, value.type);
      } else if (value instanceof Blob && filename) {
        notify(filename, value.size, value.type || "application/octet-stream");
      }
      return origAppend.apply(this, arguments);
    };
  })();
})();
//# sourceMappingURL=fileIntercept.js.map
