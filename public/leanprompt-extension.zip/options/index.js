globalThis.__LEANPROMPT_BUILD__={"supabaseUrl":"https://synuufxjdejpvpbwcypj.supabase.co","supabaseAnonKey":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN5bnV1ZnhqZGVqcHZwYndjeXBqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg2NDc4NTEsImV4cCI6MjA5NDIyMzg1MX0.wwn9NvsCZjCGnJAT6D64XWvBK2vC-IPBcqI2Ki41LZw"};
"use strict";
(() => {
  // src/lib/billing/plan.ts
  function getUpgradeUrl() {
    return "https://lean-prompt.vercel.app/";
  }

  // src/lib/storage/settings.ts
  var SETTINGS_KEY = "leanprompt_settings";
  var defaultSettings = {
    compressionLevel: "balanced",
    autoOptimize: false,
    showInlineMetrics: true,
    enabledSites: { chatgpt: true, claude: true, gemini: true },
    historyOptIn: false,
    apiAssistEnabled: true,
    instructionHighlightBeta: false
  };
  function isExtensionContextUnavailable(error) {
    return error instanceof Error && /extension context invalidated|context invalidated/i.test(error.message);
  }
  async function getSettings() {
    try {
      const data = await chrome.storage.sync.get(SETTINGS_KEY);
      const stored = data[SETTINGS_KEY] ?? {};
      return {
        ...defaultSettings,
        ...stored,
        // On by default; only off if user explicitly saved false
        apiAssistEnabled: stored.apiAssistEnabled !== false,
        instructionHighlightBeta: stored.instructionHighlightBeta === true
      };
    } catch (error) {
      if (isExtensionContextUnavailable(error)) return defaultSettings;
      throw error;
    }
  }
  async function saveSettings(settings) {
    try {
      await chrome.storage.sync.set({ [SETTINGS_KEY]: settings });
    } catch (error) {
      if (isExtensionContextUnavailable(error)) return;
      throw error;
    }
  }

  // src/options/index.ts
  async function render() {
    const root = document.getElementById("app");
    if (!root) return;
    const settings = await getSettings();
    root.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:16px;max-width:480px;">
      <h1 style="margin:0;">LeanPrompt Settings</h1>

      <label>Compression level
        <select id="compressionLevel">
          <option value="conservative">Conservative</option>
          <option value="balanced">Balanced</option>
          <option value="aggressive">Aggressive</option>
        </select>
      </label>
      <label><input id="autoOptimize" type="checkbox" /> Auto-optimize (Pro)</label>
      <label><input id="showInlineMetrics" type="checkbox" /> Show inline metrics</label>
      <label><input id="chatgpt" type="checkbox" /> Enable ChatGPT</label>
      <label><input id="claude" type="checkbox" /> Enable Claude</label>
      <label><input id="gemini" type="checkbox" /> Enable Gemini</label>
      <label><input id="historyOptIn" type="checkbox" /> Opt-in prompt history</label>

      <label style="font-size:12px;color:#64748b;">
        <input id="apiAssistDisabled" type="checkbox" />
        Disable Gemini assist (offline-only compression)
      </label>

      <label style="font-size:12px;color:#64748b;">
        <input id="instructionHighlightBeta" type="checkbox" />
        <strong>Beta:</strong> Instruction highlight (purple overlay in prompt box)
      </label>

      <div style="font-size:12px;opacity:.85;border:1px solid #e2e8f0;border-radius:10px;padding:10px;line-height:1.45;">
        Gemini assist is <strong>on by default</strong> \u2014 every optimize uses Gemini (when configured).
        Your offline engine still runs first; Apply/Reject saves both outputs to Supabase so the local model can learn to beat Gemini over time.
      </div>
      <div style="display:flex;gap:8px;">
        <button id="saveBtn">Save settings</button>
        <button id="billingBtn">Open LeanPrompt web</button>
      </div>
    </div>
  `;
    document.getElementById("compressionLevel").value = settings.compressionLevel;
    document.getElementById("autoOptimize").checked = settings.autoOptimize;
    document.getElementById("showInlineMetrics").checked = settings.showInlineMetrics;
    document.getElementById("chatgpt").checked = settings.enabledSites.chatgpt;
    document.getElementById("claude").checked = settings.enabledSites.claude;
    document.getElementById("gemini").checked = settings.enabledSites.gemini;
    document.getElementById("historyOptIn").checked = settings.historyOptIn;
    document.getElementById("apiAssistDisabled").checked = settings.apiAssistEnabled === false;
    document.getElementById("instructionHighlightBeta").checked = settings.instructionHighlightBeta === true;
    document.getElementById("saveBtn")?.addEventListener("click", async () => {
      await saveSettings({
        compressionLevel: document.getElementById("compressionLevel").value,
        autoOptimize: document.getElementById("autoOptimize").checked,
        showInlineMetrics: document.getElementById("showInlineMetrics").checked,
        enabledSites: {
          chatgpt: document.getElementById("chatgpt").checked,
          claude: document.getElementById("claude").checked,
          gemini: document.getElementById("gemini").checked
        },
        historyOptIn: document.getElementById("historyOptIn").checked,
        apiAssistEnabled: !document.getElementById("apiAssistDisabled").checked,
        instructionHighlightBeta: document.getElementById("instructionHighlightBeta").checked
      });
      alert("Settings saved.");
    });
    document.getElementById("billingBtn")?.addEventListener("click", () => {
      chrome.tabs.create({ url: getUpgradeUrl() });
    });
  }
  render();
})();
//# sourceMappingURL=index.js.map
